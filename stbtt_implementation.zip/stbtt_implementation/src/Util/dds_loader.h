#pragma once
#include "defines.h"

namespace Cakez
{
    struct DDSPixelFormat
    {
        uint32_t size; // 32
        uint32_t flags;
        uint32_t fourCC;
        uint32_t RGBBitCount;
        uint32_t RMask, GMask, BMask, AMask;
    };

    struct DDSHeader
    {
        uint32_t Size;
        uint32_t Flags;
        uint32_t Height;
        uint32_t Width;
        uint32_t Pitch;
        uint32_t Depth;
        uint32_t MipLevelCount;
        uint32_t Reserved1[11];
        DDSPixelFormat Format;
        uint32_t SurfaceFlags;
        uint32_t CubemapFlags;
        uint32_t Reserved2[3];
    };

    struct DDSMipLevel
    {
        uint32_t width;
        uint32_t heigth;
        uint32_t byteOffset;
    };

    struct DDSFile
    {
        char magic[4];
        DDSHeader *header;
        DDSMipLevel *levels;
        uint32_t textureSize;
        const char *data;
        const char *textureData;
    };

    bool load_dds_file(const char *fileName, DDSFile &ddsFile);
    void delete_dds_file(DDSFile &ddsFile);
} // namespace Cakez
