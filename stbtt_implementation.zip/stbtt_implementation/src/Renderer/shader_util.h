#pragma once

#include "my_math.h"

//TODO: Remove Standard Library
#include <cstdint>
#include <vector>

namespace Cakez
{
    // Taken from Vulkan, VkShaderStageFlagBits
    typedef enum ShaderStage
    {
        SHADER_STAGE_VERTEX = 0x00000001,
        SHADER_STAGE_FRAGMENT = 0x00000010,
        SHADER_STAGE_COMPUTE = 0x00000020,
    } ShaderStage;

    // Datatypes a .shader can use
    typedef enum ShaderDataType
    {
        TYPE_UNKNOWN = 0,
        TYPE_FLOAT,
        TYPE_VEC2,
        TYPE_VEC3,
        TYPE_VEC4,
        TYPE_MAT3,
        TYPE_MAT4,
        TYPE_INT,
        TYPE_IVEC2,
        TYPE_IVEC3,
        TYPE_IVEC4,
        TYPE_BOOL
    } ShaderDataType;

    // Taken from Vulkan, VkDescriptorType
    typedef enum BindingType
    {
        BINDING_TYPE_SAMPLER = 0,
        BINDING_TYPE_COMBINED_IMAGE_SAMPLER = 1,
        BINDING_TYPE_SAMPLED_IMAGE = 2,
        BINDING_TYPE_STORAGE_IMAGE = 3,
        BINDING_TYPE_UNIFORM_TEXEL_BUFFER = 4,
        BINDING_TYPE_STORAGE_TEXEL_BUFFER = 5,
        BINDING_TYPE_UNIFORM_BUFFER = 6,
        BINDING_TYPE_STORAGE_BUFFER = 7,
        BINDING_TYPE_UNIFORM_BUFFER_DYNAMIC = 8,
        BINDING_TYPE_STORAGE_BUFFER_DYNAMIC = 9,
        BINDING_TYPE_INPUT_ATTACHMENT = 10,
    } BindingType;

    /**
     * Used as Vertex and buffer Attributes. An Attribute
     * has a property, a name and an offset.
     */
    struct Attribute
    {
        ShaderDataType dataType;
        const char *name;
        uint32_t offset;

        Attribute(ShaderDataType dataType, const char *name, uint32_t offset)
            : dataType(dataType), name(name), offset(offset) {}

        uint32_t get_size() const
        {
            switch (dataType)
            {
            case TYPE_FLOAT:
                return sizeof(float);

            case TYPE_VEC2:
                return sizeof(float) * 2;

            case TYPE_VEC3:
                return sizeof(float) * 3;

            case TYPE_VEC4:
                return sizeof(float) * 4;

            case TYPE_INT:
                return sizeof(int);

            case TYPE_IVEC2:
                return sizeof(int) * 2;

            case TYPE_IVEC3:
                return sizeof(int) * 3;

            case TYPE_IVEC4:
                return sizeof(int) * 4;

            case TYPE_MAT3:
                return sizeof(float) * 3 * 3;

            case TYPE_MAT4:
                return sizeof(float) * 4 * 4;

            case TYPE_BOOL:
                return sizeof(bool);

            default:
                return 0;
            }
        }

        bool operator==(const Attribute &other) const
        {
            return dataType == other.dataType && offset == other.offset;
        }
    };

    /**
     * A Binding is part of a Set and can either be a Buffer of a Texture.
     * The Binding has optional Attributes. The order of the attributes 
     * determine the offset into the Buffer. Bindings follow some rules:
     * 
     * @tparam #1 Two bindings are the same if they have the same number and set_number (glsl Rule)
    */
    struct Binding
    {
        const char *name;
        BindingType type;
        uint32_t number;
        uint32_t set_number;
        uint32_t shaderStages;
        std::vector<Attribute> attributes;
    };

    void compile_shader(const char *shaderPath, const char *spirvPath);

    void parse_spirv(
        std::vector<Binding> &bindings,
        std::vector<Attribute> &attributes,
        ShaderStage &shaderStage,
        uint32_t *spirv,
        uint32_t length,
        bool &usePushConstants);
} // namespace Cakez
