#include "util.h"

#include "logger.h"

namespace Cakez
{
    void copy_to_buffer(
        const void *buffer,
        const void *data,
        const uint32_t size,
        const uint32_t offset)
    {
        memcpy((uint8_t *)buffer + offset, data, size);
    }

    bool str_cmp(const char *a, const char *b)
    {
        return strlen(a) == strlen(b) ? strncmp(a, b, strlen(a)) == 0 ? true : false : false;
    }

    void convert_number_to_char(uint32_t number, char *buffer, int *length, int base)
    {
    }

    void convert_number_to_char(int number, char *buffer, int *length, int base)
    {
        if (buffer && base > 0)
        {
            *length = 0;
            int tmpNumber = number;

            if (number < 0)
            {
                buffer[0] = '-';
                tmpNumber *= -1;
                (*length)++;
            }

            int digits = 1;
            *length = 1;
            while (tmpNumber /= base)
            {
                digits *= base;
                (*length)++;
            }

            tmpNumber = number;
            int offset = 0;
            if (number < 0)
            {
                buffer[0] = '-';
                tmpNumber *= -1;
                offset = 1;
                (*length)++;
            }

            for (uint32_t i = offset; digits > 0; i++)
            {
                int firstNumber = tmpNumber / digits;
                char c = (char)firstNumber + '0';
                buffer[i] = c;

                tmpNumber %= digits;
                digits /= base;
            }
        }
    }

    uint32_t count_char(const char c, const char *hay)
    {
        uint32_t i = 0;
        uint32_t count = 0;

        while (hay[i] != 0)
        {
            i++;
            if (hay[i] == c)
                count++;
        }

        return count;
    }

    uint8_t pack_uint8(float value)
    {
        return (uint8_t)(value * 127.0f + 127.5f);
    }
} // namespace Cakez
