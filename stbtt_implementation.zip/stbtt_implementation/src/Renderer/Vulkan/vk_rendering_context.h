#pragma once

#include "vk_types.h"

#include "Renderer/render_types.h"

namespace Cakez
{
} // namespace Cakez
