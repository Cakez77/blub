#pragma once
#include "ui.h"
#include "input.h"
#include "logger.h"

namespace Cakez
{
    //#######################################################################
    //              Internal functions
    //#######################################################################
    internal void set_label(UIEle *e, char *label)
    {
        e->labelLength = 0;
        e->label = label;
        if (label)
        {
            while (char c = *(label++))
            {
                //TODO: Ask glyph cache for size X and add that to labelLength
                e->labelLength++;
            }
        }
    }

    internal UIEle *create_ui_element(UIState *ui, AssetTypeID assetID,
                                      char *label, size_t id, Rect rect)
    {
        UIEle *e = 0;

        if (ui->uiElementCount < MAX_UI_ELEMENTS)
        {
            e = &ui->uiElements[ui->uiElementCount];
            *e = {};
            e->value = INT32_MAX;
            e->ID.id = id;
            e->rect = rect;
            e->assetID = assetID;
            e->ID.layer = ui->global_layer + LAYER_UI;
            set_label(e, label);

            UIEle *owner = ui->currentContainer;
            if (owner)
            {
                // Set and position based on owner
                e->rect.pos = owner->rect.pos + e->rect.pos;
            }

            ui->uiElementCount++;
        }
        else
        {
            CAKEZ_ASSERT(0, "Reched maximum amount of ui elements");
        }

        return e;
    }

    internal bool is_inside(UIState *ui, InputState *input, UIEle *e)
    {
        return point_in_rect({(float)input->mouseX, (float)input->mouseY}, e->rect);
    }

    internal void set_hot(UIState *ui, UIEle *e)
    {
        if (!ui->active.id && (ui->hot_this_frame.layer <= e->ID.layer))
        {
            ui->hot_this_frame = e->ID;
        }
    }

    internal bool is_hot(UIState *ui, InputState *input, UIEle *e)
    {
        return ui->hot_last_frame.id == e->ID.id;
    }

    internal void set_active(UIState *ui, UIEle *e)
    {
        ui->active = e->ID;
    }

    internal bool is_active(UIState *ui, UIEle *e)
    {
        return ui->active.id == e->ID.id;
    }

    internal void set_inactive(UIState *ui, UIEle *e)
    {
        ui->active = {};
    }

    internal void set_owner(UIEle *e, UIEle *owner)
    {
    }

    // #######################################################################
    //              Implementation of exposed functions
    // #######################################################################
    void update_ui(UIState *ui, InputState *input)
    {
        bool foundActive = false;
        if (key_released_this_frame(input, LEFT_MOUSE_KEY))
        {
            for (uint32_t i = 0; i < ui->uiElementCount; i++)
            {
                if (ui->active.id == ui->uiElements[i].ID.id)
                {
                    foundActive = true;
                    break;
                }
            }

            if (!foundActive)
            {
                ui->active = {};
            }
        }

        ui->hot_last_frame = ui->hot_this_frame;
        ui->hot_this_frame = {};
        ui->currentContainer = 0;
        ui->uiElementCount = 0;
    }

    bool is_ui_hot(UIState *ui)
    {
        return ui->hot_last_frame.id;
    }

    float get_label_width(UIEle *e)
    {
        float result = e->labelLength * GLYPH_WIDTH / 2.0f;
        return result;
    }

    //#######################################################################
    //              Actual UI
    //#######################################################################
    bool do_container(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        char *label,
        size_t id,
        Rect rect)
    {
        bool result = false;

        UIEle *e = create_ui_element(ui, assetID, label, id, rect);
        if (e)
        {
            // Increase global Layer
            ui->global_layer++;

            // Set the current owner in the ui
            ui->currentContainer = e;

            if (is_active(ui, e))
            {
                result = true;
                if (key_released_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_inactive(ui, e);
                }
            }
            else if (is_hot(ui, input, e))
            {
                if (key_pressed_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_active(ui, e);
                }
            }

            if (is_inside(ui, input, e))
            {
                set_hot(ui, e);
            }
        }

        return result;
    }

    void end_container(UIState *ui)
    {
        if (ui->currentContainer)
        {
            ui->global_layer--;
            ui->currentContainer = 0;
        }
    }

    bool do_button(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        char *label,
        size_t id,
        Rect rect,
        int value)
    {
        bool result = false;

        UIEle *e = create_ui_element(ui, assetID, label, id, rect);
        e->value = value;
        if (e)
        {

            if (is_active(ui, e))
            {
                if (key_released_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_inactive(ui, e);

                    if (is_inside(ui, input, e))
                        result = true;
                }
            }
            else if (is_hot(ui, input, e))
            {
                if (key_pressed_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_active(ui, e);
                }
            }

            if (is_inside(ui, input, e))
            {
                set_hot(ui, e);
            }
        }

        return result;
    }

    bool do_slide_button(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        char *label,
        size_t id,
        Rect rect)
    {
        bool result = false;

        UIEle *e = create_ui_element(ui, assetID, label, id, rect);
        if (e)
        {
            if (is_active(ui, e))
            {
                if (key_is_down(input, LEFT_MOUSE_KEY) && (input->relMouseX || input->relMouseY))
                {
                    result = true;
                }

                if (key_released_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_inactive(ui, e);
                }
            }
            else if (is_hot(ui, input, e))
            {
                if (key_pressed_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_active(ui, e);
                }
            }

            if (is_inside(ui, input, e))
            {
                set_hot(ui, e);
            }
        }

        return result;
    }

    bool do_following_button(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        size_t id,
        Rect rect)
    {
        bool result = false;

        UIEle *e = create_ui_element(ui, assetID, 0, id, rect);
        if (e)
        {
            if (is_active(ui, e))
            {
                if (key_is_down(input, LEFT_MOUSE_KEY))
                {
                    e->rect.pos.x = input->mouseX;
                    e->rect.pos.y = input->mouseY;
                }

                if (key_released_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_inactive(ui, e);

                    result = true;
                }
            }
            else if (is_hot(ui, input, e))
            {
                if (key_pressed_this_frame(input, LEFT_MOUSE_KEY))
                {
                    set_active(ui, e);
                }
            }

            if (is_inside(ui, input, e))
            {
                set_hot(ui, e);
            }
        }
        return result;
    }

    void do_text(
        UIState *ui,
        char *label,
        size_t id,
        Vec2 pos)
    {
        ui->global_layer++;
        create_ui_element(ui, ASSET_NONE, label, id, {pos.x, pos.y, 0.0f, 0.0f});
        ui->global_layer--;
    }

    void do_number(
        UIState *ui,
        int value,
        size_t id,
        Vec2 pos)
    {
        ui->global_layer++;
        if (UIEle *e = create_ui_element(ui, ASSET_NONE, 0, id, {pos.x, pos.y, 0.0f, 0.0f}))
            e->value = value;
        ui->global_layer--;
    }
}