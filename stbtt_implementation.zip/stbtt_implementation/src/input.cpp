#include "input.h"

namespace Cakez
{
    bool key_pressed_this_frame(InputState *input, KeyType keyType)
    {
        Key *key = &input->keys[keyType];
        bool result = ((key->keyState == S_KEYTATE_DOWN) && (key->halfTransitionCount > 0));
                    //    ((key->keyState == S_KEYTATE_UP) && (key->halfTransitionCount > 1)));
        return result;
    }

    bool key_released_this_frame(InputState *input, KeyType keyType)
    {
        Key *key = &input->keys[keyType];
        bool result = ((key->keyState == S_KEYTATE_UP) && (key->halfTransitionCount > 0));
                    //    ((key->keyState == S_KEYTATE_DOWN) && (key->halfTransitionCount > 1)));
        return result;
    }

    bool key_is_down(InputState *input, KeyType keyType)
    {
        Key *key = &input->keys[keyType];
        return key->keyState & S_KEYTATE_DOWN;
    }
} // namespace Cakez
