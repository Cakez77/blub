# CakezFramework

## Setup

To be used in Games inside a folder called `src`. To use this Framework, take the following steps:
- Clone this repo into a folder called `src`
- Add the `src` Folder as include directory
- Add the define `DEBUG` to use the debug version
- Add the define `CAKEZGINE` to the compiler, this is used in `render_types.h`


## Building

Currently only Windows builds are supported.

### Windows

To build the debug version on windows use this template:
```
@echo off

SetLocal EnableDelayedExpansion
if not defined DevEnvDir (
    call "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvars64.bat"
)

SET includeFlags=/Isrc /I%VULKAN_SDK%/Include /Ivendor
SET linkerFlags=/link /LIBPATH:%VULKAN_SDK%/Lib vulkan-1.lib user32.lib
SET defines=/D CAKEZGINE /D DEBUG

echo "Building Game..."

if not exist build\NUL mkdir build

cl /EHsc /Z7 /std:c++17 /Fe"main" /Fobuild/ %defines% %includeFlags% src/game.cpp %linkerFlags%

```
