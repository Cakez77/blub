#pragma once
#include "instrumentor.h"

namespace Cakez
{
    Instrumentor::Instrumentor(const char *msg_)
    {
        //TODO: Call platform_get_timestamp here
    }

    Instrumentor::~Instrumentor()
    {
        //TODO: Call platform_get_timestamp, subtract above and print msg with time
    }
} // namespace Cakez
