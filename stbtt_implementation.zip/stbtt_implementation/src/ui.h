#pragma once

#include "game_assets.h"
#include "input.h"

namespace Cakez
{
    // Forward declare types
    struct GameState;
    struct Entity;

    //#######################################################################
    //                      Global Variables
    //#######################################################################
    global_variable int32_t MAX_LABELED_VALUE = INT32_MAX;
    global_variable Vec2 constexpr labeledRectSize = {80.0f, 40.0f};
    global_variable float constexpr UI_PADDING = 5.0f;
    global_variable float constexpr GLYPH_WIDTH = 40;
    global_variable uint32_t constexpr MAX_GLYPHS = 2000;
    global_variable uint32_t constexpr MAX_UI_ELEMENTS = 1000;

    //#######################################################################
    //                      Immediate Mode UI TM*
    //#######################################################################
    struct UIID
    {
        size_t id;
        int layer;
    };

    struct UIEle
    {
        UIID ID;
        AssetTypeID assetID;
        char *label;
        uint32_t labelLength;
        int value;
        Rect rect;
    };

    struct UIState
    {
        UIID hot_last_frame;
        UIID hot_this_frame;
        UIID active;

        UIEle *currentContainer;
        int global_layer;

        uint32_t uiElementCount;
        UIEle uiElements[MAX_UI_ELEMENTS];
    };

    // Update State
    void update_ui(UIState *ui, InputState *input);

    // Utility
    bool is_ui_hot(UIState *ui);
    float get_label_width(UIEle *e);

    // Actual UI
    bool do_container(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        char *label,
        size_t id,
        Rect rect);

    void end_container(UIState *ui);

    bool do_button(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        char *text,
        size_t id,
        Rect rect,
        int value = INT32_MAX);

    bool do_slide_button(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        char *label,
        size_t id,
        Rect rect);

    bool do_following_button(
        UIState *ui,
        InputState *input,
        AssetTypeID assetID,
        size_t id,
        Rect rect);

    void do_text(
        UIState *ui,
        char *label,
        size_t id,
        Vec2 pos);

    void do_number(
        UIState *ui,
        int value,
        size_t id,
        Vec2 pos);

} // namespace Cakez
