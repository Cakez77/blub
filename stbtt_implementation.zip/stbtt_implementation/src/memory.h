#pragma once

#include "defines.h"
#include "logger.h"

namespace Cakez
{
    struct GameMemory
    {
        uint8_t *memory;
        uint32_t allocatedBytes;
        uint32_t memorySizeInBytes;
    };

    //TODO: Atm we can only allocate and will run out of memory
    uint8_t *allocate_memory(GameMemory *gameMemory, uint32_t sizeInBytes)
    {
        if (gameMemory->allocatedBytes + sizeInBytes < gameMemory->memorySizeInBytes)
        {
            uint8_t *memory = gameMemory->memory + gameMemory->allocatedBytes;
            gameMemory->allocatedBytes += sizeInBytes;
            return memory;
        }
        else
        {
            CAKEZ_ASSERT(false, "Game is out of memory");
            return 0;
        }
    }
} // namespace Cakez
