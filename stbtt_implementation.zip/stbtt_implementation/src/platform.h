#pragma once

#include "defines.h"
/**
 * This function tests for the existence of a file in
 * a given path. This function has to be implemented 
 * for each platform.
 * @param path The path to the file
 * @return true if the file exists, false otherwise
 */
bool platform_file_exists(const char *path);

/**
 * This function reads an entire file into a buffer 
 * allocated on the heap and returns that buffer. If
 * no file could be found, 0 is returned.
 * @param fileName The path to the file
 * @param length The length of file in bytes; will be written to by the function
 * @return char* buffer or 0 if the file doesn't exist.
 */
char *platform_read_file(const char *fileName, uint32_t &length);

unsigned long platform_write_file(
    const char *path,
    const char *buffer,
    const uint32_t size,
    bool overwrite);

long long platform_last_edit_timestamp(const char *path);

void platform_get_window_size(uint32_t *windowWidth, uint32_t *windowHeight);