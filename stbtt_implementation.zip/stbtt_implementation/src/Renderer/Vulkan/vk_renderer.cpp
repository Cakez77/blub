// External library from Sean Barrett
#define STB_TRUETYPE_IMPLEMENTATION
#include "Util/stb_truetype.h"

//#############################################################
//          Framework includes
//#############################################################
#include "defines.h"
#include "camera.h"
#include "Game/game.h"
#include "Game/game_state.h"
#include "my_math.h"
#include "platform.h"
#include "Util/dds_loader.h"
#include "ui.h"

#include "Renderer/shader_util.cpp"

//#############################################################
//          Vulkan includes
//#############################################################
#include "vk_types.h"

#include "vk_create.cpp"
#include "vk_initializers.cpp"
#include "vk_util.cpp"

// TODO: Remove
#include <algorithm>
#include <vector>
#include <chrono>

namespace Cakez
{
    //#############################################################
    //                  Global variables
    //#############################################################
    global_variable constexpr int FRAME_OVERLAP = 1;
    global_variable constexpr int QUERY_POOL_COUNT = 128;

    global_variable constexpr char *spriteShaders[] = {
        "assets/shaders/compiled/sprites.vert.spv",
        "assets/shaders/compiled/sprites.frag.spv"};

    global_variable constexpr char *textShaders[] = {
        "assets/shaders/compiled/glyphs.vert.spv",
        "assets/shaders/compiled/glyphs.frag.spv"};

    global_variable constexpr char *animationShaders[] = {
        "assets/shaders/compiled/animation.vert.spv",
        "assets/shaders/compiled/animation.frag.spv"};

    //TODO: Put this into #ifdef PROFILE
    global_variable bool firstRun = true;

    //#############################################################
    //                  Internal functions
    //#############################################################
    internal uint32_t vk_calculate_texture_size(
        VkFormat imageFormat,
        uint32_t width,
        uint32_t height,
        uint32_t levels)
    {
        uint32_t size = 0;
        for (uint32_t i = 0; i < levels; i++)
        {
            switch (imageFormat)
            {
            case VK_FORMAT_BC1_RGBA_SRGB_BLOCK:
            {
                uint32_t secureWidth = width >> i >= 1 ? width >> i : 1;
                uint32_t secureHeight = height >> i >= 1 ? height >> i : 1;
                size += secureWidth * secureHeight * 8;
                break;
            }

            case VK_FORMAT_R8_UNORM:
            {
                size += width * height;
                break;
            }

            case VK_FORMAT_R8G8B8A8_UNORM:
            {
                size += width * height * 4;
                break;
            }
            }
        }

        return size;
    }

    internal uint32_t vk_create_texture(
        VkContext *vkcontext,
        TextureFormat textureFormat,
        const void *data,
        uint32_t width,
        uint32_t height,
        MipMapLevel *pLevels = 0,
        uint32_t levelCount = 1u,
        uint32_t size = 0,
        bool blur = false)
    {
        Image image = {};

        vk_allocate_image(
            vkcontext,
            &image.vkImage,
            &image.memory,
            (VkFormat)textureFormat,
            VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT,
            {width, height, 1},
            levelCount);

        //TODO: Use memory arenas(Blocks of memory passed to this function)
        //TODO: Use array of size 10 here
        VkBufferImageCopy *copyRegions = (VkBufferImageCopy *)malloc(sizeof(VkBufferImageCopy) * levelCount);

        for (uint32_t i = 0; i < levelCount; i++)
        {
            VkBufferImageCopy copyRegion = {};
            copyRegion.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            copyRegion.imageSubresource.mipLevel = i;
            copyRegion.imageSubresource.baseArrayLayer = 0;
            copyRegion.imageSubresource.layerCount = 1;
            copyRegion.imageExtent.width = width >> i < 1 ? 1 : width >> i;
            copyRegion.imageExtent.height = height >> i < 1 ? 1 : height >> i;
            copyRegion.imageExtent.depth = 1;
            copyRegion.bufferOffset = pLevels ? pLevels->byteOffset : 0;

            copyRegions[i] = copyRegion;
        }

        uint32_t textureSize = size ? size : vk_calculate_texture_size((VkFormat)textureFormat, width, height, levelCount);

        vk_copy_to_image(
            vkcontext,
            &image.vkImage,
            &image.layout,
            copyRegions,
            levelCount,
            data,
            textureSize,
            levelCount);

        free(copyRegions);

        // Create Image View
        {
            VkImageViewCreateInfo viewInfo = vkinit::image_view_create_info(
                image.vkImage,
                (VkFormat)textureFormat,
                VK_IMAGE_ASPECT_COLOR_BIT,
                VK_IMAGE_VIEW_TYPE_2D,
                1);

            VK_CHECK(vkCreateImageView(
                vkcontext->device,
                &viewInfo,
                0,
                &image.vkImageView));
        }

        // Create sampler
        // TODO: Move the sampler somewhere else, maybe the material(program descriptor)
        {
            VkSamplerCreateInfo samplerInfo = {VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
            samplerInfo.addressModeU = VK_SAMPLER_ADDRESS_MODE_REPEAT;
            samplerInfo.addressModeV = VK_SAMPLER_ADDRESS_MODE_REPEAT;
            samplerInfo.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
            samplerInfo.minLod = 0.0f;
            samplerInfo.maxLod = VK_LOD_CLAMP_NONE;
            samplerInfo.mipLodBias = 0.0f;
            samplerInfo.mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR;
            samplerInfo.compareEnable = VK_FALSE;
            samplerInfo.minFilter = blur ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
            samplerInfo.magFilter = blur ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
            samplerInfo.anisotropyEnable = VK_FALSE;
            samplerInfo.maxAnisotropy = 1.0f;
            samplerInfo.borderColor = VK_BORDER_COLOR_FLOAT_OPAQUE_BLACK;

            VK_CHECK(vkCreateSampler(
                vkcontext->device,
                &samplerInfo,
                0,
                &image.vkSampler));
        }

        vkcontext->images.push_back(image);

        return (uint32_t)vkcontext->images.size() - 1;
    }

    internal Mesh vk_create_mesh(
        VkContext *vkcontext,
        Vertex *pVertices,
        uint32_t vertexCount,
        uint32_t *pIndices,
        uint32_t indexCount)
    {
        //TODO: Review this function
        CAKEZ_ASSERT(indexCount > 0, "Nothing to upload");
        CAKEZ_ASSERT((vkcontext->vertexOffset + vertexCount) * sizeof(Vertex) < vkcontext->vertexStorageBuffer.size,
                     "Reached limit of vertex buffer");
        CAKEZ_ASSERT((vkcontext->indexOffset + indexCount) * sizeof(uint32_t) < vkcontext->indexStorageBuffer.size,
                     "Reached limit of index buffer");
        Mesh m = {};

        m.indexCount = indexCount;
        m.indexOffset = vkcontext->indexOffset;
        m.vertexOffset = vkcontext->vertexOffset;

        if (vertexCount > 0)
        {
            vk_copy_to_buffer(
                vkcontext,
                &vkcontext->vertexStorageBuffer.vkBuffer,
                &vkcontext->vertexStorageBuffer.memory,
                pVertices,
                vertexCount * sizeof(Vertex),
                vkcontext->vertexOffset * sizeof(Vertex));
            vkcontext->vertexOffset += vertexCount;
        }

        if (indexCount > 0)
        {
            vk_copy_to_buffer(
                vkcontext,
                &vkcontext->indexStorageBuffer.vkBuffer,
                &vkcontext->indexStorageBuffer.memory,
                pIndices,
                indexCount * sizeof(uint32_t),
                vkcontext->indexOffset * sizeof(uint32_t));
            vkcontext->indexOffset += indexCount;
        }

        return m;
    }

    internal uint32_t vk_create_program(
        VkContext *vkcontext,
        const char *const *shaders,
        uint32_t shaderCount,
        bool colorBlending = VK_FALSE,
        bool depthWriteEnable = VK_FALSE)
    {
        Program p = {};
        p.colorBlending = colorBlending;
        p.shaders = shaders;

        std::vector<Attribute> attributes;
        std::vector<VkPipelineShaderStageCreateInfo> shaderStages;
        std::vector<VkShaderModule> modules;

        for (uint32_t i = 0; i < shaderCount; i++)
        {
            uint32_t byteLength;
            uint32_t *code = (uint32_t *)platform_read_file(shaders[i], byteLength);
            uint32_t codeSize = byteLength / sizeof(uint32_t);
            if (!code)
            {
                CAKEZ_ASSERT(false, "Shader %s does not exist", shaders[i]);
                // TODO: What should happen if we cannot read the file?
                // NOTE: Maybe a default program can be loaded?
            }

            CAKEZ_ASSERT((byteLength % 4) == 0, "File %s ist not a correct SPIR-V file", shaders[i]);

            ShaderStage shaderStage;

            parse_spirv(
                p.bindings,
                attributes,
                shaderStage,
                code,
                codeSize,
                p.usePushConstants);

            // Create the shader stage
            {
                VkShaderModule module = create_shader_module(
                    vkcontext->device,
                    code,
                    codeSize);

                modules.push_back(module);

                VkShaderStageFlagBits stage;

                switch (shaderStage)
                {
                case SHADER_STAGE_VERTEX:
                {
                    stage = VK_SHADER_STAGE_VERTEX_BIT;
                    break;
                }
                case SHADER_STAGE_FRAGMENT:
                {
                    stage = VK_SHADER_STAGE_FRAGMENT_BIT;
                    break;
                }
                case SHADER_STAGE_COMPUTE:
                {
                    stage = VK_SHADER_STAGE_COMPUTE_BIT;
                    break;
                }
                }
                shaderStages.push_back(
                    vkinit::pipeline_shader_stage_create_info(
                        stage,
                        module));
            }
        }

        // Create descriptor layouts
        {
            // Sort the bindings by set
            std::sort(p.bindings.begin(), p.bindings.end(), [&](Binding a, Binding b)
                      {
                          if (a.set_number == b.set_number)
                              return a.number < b.number;
                          return a.set_number < b.set_number;
                      });

            VkDescriptorSetLayout currentLayout = 0;
            int currentBindingNumber = 0;
            std::vector<VkDescriptorSetLayoutBinding> layoutBindings;
            VkDescriptorSetLayoutCreateInfo layoutInfo;

            for (auto binding : p.bindings)
            {
                if (currentBindingNumber != binding.set_number)
                {
                    currentBindingNumber = binding.set_number;

                    if (layoutBindings.size() == 0)
                        continue;

                    layoutInfo = vkinit::descriptorset_layout_create_info(
                        static_cast<uint32_t>(layoutBindings.size()),
                        layoutBindings.data());

                    //TODO: Test this with using Util::str_cmp and default sets, benchmark

                    VK_CHECK(vkCreateDescriptorSetLayout(
                        vkcontext->device,
                        &layoutInfo,
                        0,
                        &currentLayout));

                    p.setLayouts.push_back(currentLayout);

                    layoutBindings.clear();

                    currentLayout = 0;
                }

                layoutBindings.push_back(
                    vkinit::descriptorset_layout_binding(
                        (VkDescriptorType)binding.type,
                        (VkShaderStageFlags)binding.shaderStages,
                        binding.number,
                        str_cmp(binding.name, "animation") ? 10 : 1));
            }

            layoutInfo = vkinit::descriptorset_layout_create_info(
                static_cast<uint32_t>(layoutBindings.size()),
                layoutBindings.data());

            VK_CHECK(vkCreateDescriptorSetLayout(
                vkcontext->device,
                &layoutInfo,
                0,
                &currentLayout));

            p.setLayouts.push_back(currentLayout);
        }

        // Create the pipeline layout
        {
            VkPipelineLayoutCreateInfo layoutInfo =
                vkinit::pipeline_layout_create_info(p.setLayouts);

            // Push constants
            VkPushConstantRange range;
            if (p.usePushConstants)
            {
                range = vkinit::push_constant_range(
                    VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT,
                    sizeof(PushData),
                    0);

                layoutInfo.pPushConstantRanges = &range;
                layoutInfo.pushConstantRangeCount = 1;
            }

            VK_CHECK(vkCreatePipelineLayout(
                vkcontext->device,
                &layoutInfo,
                0,
                &p.layout));
        }

        // Create the pipeline
        {
            p.pipeline = create_pipeline(
                vkcontext->device,
                vkcontext->renderPass,
                p.layout,
                shaderStages.data(),
                static_cast<uint32_t>(shaderStages.size()),
                colorBlending ? VK_TRUE : VK_FALSE,
                VK_BLEND_OP_ADD,
                VK_BLEND_FACTOR_ONE,
                colorBlending ? VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA : VK_BLEND_FACTOR_ONE,
                depthWriteEnable ? VK_TRUE : VK_FALSE);
        }

        // Destroy the shader modules
        {
            for (auto &module : modules)
                vkDestroyShaderModule(vkcontext->device, module, 0);
        }

        vkcontext->programs.push_back(p);

        return (uint32_t)vkcontext->programs.size() - 1;
    }

    internal void vk_update_descriptor(
        VkContext *vkcontext,
        uint32_t descriptorIdx)
    {
        ProgramDescriptor &desc = vkcontext->programDescriptors[descriptorIdx];
        Program &p = vkcontext->programs[desc.programIdx];

        VkDescriptorSetAllocateInfo allocInfo = {};
        int currentSet = -1;
        std::vector<VkWriteDescriptorSet> writes;
        DescriptorInfo descInfos[32];
        uint32_t descCount = 0;

        for (auto binding : p.bindings)
        {
            if (currentSet != binding.set_number)
            {
                // Track the current set number
                currentSet = binding.set_number;

                if (currentSet >= desc.sets.size())
                {
                    // Allocate a new set
                    {
                        allocInfo = vkinit::descriptorset_allocate_info(
                            vkcontext->descPool,
                            1,
                            &p.setLayouts[binding.set_number]);

                        VkDescriptorSet set;
                        vkAllocateDescriptorSets(
                            vkcontext->device,
                            &allocInfo,
                            &set);

                        desc.sets.push_back(set);
                    }
                }
            }

            if (str_cmp(binding.name, "Vertices"))
            {
                descInfos[descCount] =
                    {vkcontext->vertexStorageBuffer.vkBuffer};
                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount]));

                descCount++;
            }
            else if (str_cmp(binding.name, "GlobalUBO"))
            {
                descInfos[descCount] =
                    {vkcontext->globalUniformBuffer.vkBuffer};
                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount]));

                descCount++;
            }
            else if (str_cmp(binding.name, "Glyphs"))
            {
                descInfos[descCount] =
                    {vkcontext->glyphCache.glpyhUBO.vkBuffer};
                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount]));

                descCount++;
            }
            else if (str_cmp(binding.name, "GlyphTransforms"))
            {

                descInfos[descCount] =
                    {vkcontext->glyphTransformStorageBuffer.vkBuffer};
                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount]));

                descCount++;
            }
            //TODO: Merge the names? Maybe?
            else if (str_cmp(binding.name, "Transforms") ||
                     str_cmp(binding.name, "SpriteTransforms"))
            {
                descInfos[descCount] =
                    {vkcontext->transformStorageBuffer.vkBuffer};
                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount]));

                descCount++;
            }
            else if (str_cmp(binding.name, "animation"))
            {
                CAKEZ_ASSERT(
                    binding.type == BINDING_TYPE_COMBINED_IMAGE_SAMPLER,
                    "animation has to be a combined image sampler");

                Image &white = vkcontext->images[vkcontext->white.imageIdx];
                for (uint32_t i = 0; i < 10; i++)
                {
                    descInfos[descCount + i] = {white.vkSampler,
                                                white.vkImageView,
                                                white.layout};
                }

                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount],
                    10));

                descCount += 10;
            }
            else if (str_cmp(binding.name, "MaterialUBO"))
            {
                CAKEZ_ASSERT(
                    binding.type == BINDING_TYPE_UNIFORM_BUFFER,
                    "MaterialUBO has to be a uniform buffer");

                // Crate Buffer of size matching the size of all attributes
                {
                    uint32_t uboSize = 0;
                    for (auto &attribute : binding.attributes)
                        uboSize += attribute.get_size();

                    if (uboSize != 0 && uboSize != desc.buffer.size)
                    {
                        // Create a new buffer and add to old buffer to the deletion queue
                        if (desc.buffer.size != 0)
                        {
                            //TODO: Delete old buffer
                        }
                        else
                        {
                            desc.buffer.size = uboSize;

                            vk_allocate_buffer(
                                vkcontext,
                                &desc.buffer.vkBuffer,
                                &desc.buffer.memory,
                                desc.buffer.size,
                                VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
                        }
                    }
                }
                descInfos[descCount] =
                    {desc.buffer.vkBuffer};
                writes.push_back(vkinit::write_descriptor_set(
                    (VkDescriptorType)binding.type,
                    desc.sets[currentSet],
                    binding.number,
                    &descInfos[descCount]));

                descCount++;
            }
            else if (binding.type == BINDING_TYPE_COMBINED_IMAGE_SAMPLER)
            {
                bool foundSamplerInDescriptor = false;
                for (auto samplerToTexture : desc.samplerNamesToTextures)
                {
                    //TODO: Use texture ID's
                    if (str_cmp(samplerToTexture.samplerName, binding.name))
                    {
                        foundSamplerInDescriptor = true;

                        uint32_t imageIdx = samplerToTexture.texture.imageIdx;
                        if (imageIdx < vkcontext->images.size())
                        {
                            Image image = vkcontext->images[imageIdx];

                            // NOTE: VkWriteDescriptorSet takes pointers which is why we need an array herer
                            descInfos[descCount] = {
                                image.vkSampler,
                                image.vkImageView,
                                image.layout};

                            writes.push_back(
                                vkinit::write_descriptor_set(
                                    (VkDescriptorType)binding.type,
                                    desc.sets[currentSet],
                                    binding.number,
                                    &descInfos[descCount]));

                            descCount++;
                        }
                        else
                        {
                            CAKEZ_ERROR(
                                "Texture corresponding to Binding: %s does not exists using white",
                                binding.name);

                            Image image = vkcontext->images[vkcontext->white.imageIdx];

                            // NOTE: VkWriteDescriptorSet takes pointers which is why we need an array herer
                            descInfos[descCount] = {
                                image.vkSampler,
                                image.vkImageView,
                                image.layout};

                            VkWriteDescriptorSet write =
                                vkinit::write_descriptor_set(
                                    (VkDescriptorType)binding.type,
                                    desc.sets[currentSet],
                                    binding.number,
                                    &descInfos[descCount]);

                            writes.push_back(vkinit::write_descriptor_set(
                                (VkDescriptorType)binding.type,
                                desc.sets[currentSet],
                                binding.number,
                                &descInfos[descCount]));

                            descCount++;
                        }
                    }
                }

                // If the descriptor didn't have an Entry in the descriptor we add default white
                if (!foundSamplerInDescriptor)
                {
                    desc.samplerNamesToTextures.push_back({binding.name,
                                                           vkcontext->white});

                    Image image = vkcontext->images[vkcontext->white.imageIdx];
                    descInfos[descCount] = {image.vkSampler,
                                            image.vkImageView,
                                            image.layout};

                    writes.push_back(vkinit::write_descriptor_set(
                        (VkDescriptorType)binding.type,
                        desc.sets[currentSet],
                        binding.number,
                        &descInfos[descCount]));

                    descCount++;
                }
            }
            else
            {
                CAKEZ_ASSERT(false, "Unsupported binding type");
            }
        }

        // Update the descriptor sets
        vkUpdateDescriptorSets(
            vkcontext->device,
            (uint32_t)writes.size(),
            writes.data(),
            0, 0);
    }

    internal uint32_t vk_create_descriptor(
        VkContext *vkcontext,
        uint32_t programIdx)
    {
        CAKEZ_ASSERT(programIdx < vkcontext->programs.size(),
                     "ProgramIdx: %d out of bounds", programIdx);

        ProgramDescriptor descriptor = {};
        descriptor.programIdx = programIdx;
        vkcontext->programDescriptors.push_back(descriptor);

        uint32_t descriptorIdx = vkcontext->programDescriptors.size() - 1;
        vk_update_descriptor(vkcontext, descriptorIdx);

        return descriptorIdx;
    }

    internal Material *vk_create_material(
        VkContext *vkcontext,
        const char *const *shaders,
        AssetTypeID assetID,
        bool colorBlending = false)
    {
        Material *m = 0;

        if (vkcontext->materialCount < MAX_MATERIALS)
        {
            m = &vkcontext->materials[vkcontext->materialCount];
            vkcontext->materialCount++;
            m->assetID = assetID;
            m->colorBlending = colorBlending;

            // Search programs first to use an existing one
            for (uint32_t i = 0; i < (uint32_t)vkcontext->programs.size(); i++)
            {
                if (str_cmp(vkcontext->programs[i].shaders[0], shaders[0]) &&
                    str_cmp(vkcontext->programs[i].shaders[1], shaders[1]) &&
                    vkcontext->programs[i].colorBlending == colorBlending)
                {
                    m->descriptorIdx = vk_create_descriptor(vkcontext, i);
                    return m;
                }
            }

            // No compatible program found, create a new one
            uint32_t programIdx = vk_create_program(vkcontext, shaders, 2, colorBlending);
            m->descriptorIdx = vk_create_descriptor(vkcontext, programIdx);
        }
        else
        {
            CAKEZ_ASSERT(0, "Exceded maximum material count");
        }

        return m;
    }

    internal bool vk_set_material_sampler(
        VkContext *vkcontext,
        Material *material,
        const char *samplerName,
        Texture *texture)
    {
        if (material->descriptorIdx < (uint32_t)vkcontext->programDescriptors.size())
        {
            ProgramDescriptor &desc = vkcontext->programDescriptors[material->descriptorIdx];

            for (SamplerToTexture &samplerToTexture : desc.samplerNamesToTextures)
            {
                if (str_cmp(samplerToTexture.samplerName, samplerName))
                {
                    samplerToTexture.texture = *texture;
                    vk_update_descriptor(vkcontext, material->descriptorIdx);
                    return true;
                }
            }

            CAKEZ_ASSERT(false, "Sampler name %s not found in descriptor", samplerName);
            return false;
        }
        else
        {
            CAKEZ_ASSERT(false, "Descriptor index %d out of bounds", material->descriptorIdx);
            return false;
        }
    }

    internal bool vk_set_material_animation(
        VkContext *vkcontext,
        Material *material,
        Texture *pTextures,
        uint32_t textureCount)
    {
        if (textureCount <= 10)
        {
            if (material->descriptorIdx < (uint32_t)vkcontext->programDescriptors.size())
            {
                ProgramDescriptor &desc = vkcontext->programDescriptors[material->descriptorIdx];
                Program &p = vkcontext->programs[desc.programIdx];

                bool foundAnimation = false;

                for (Binding &b : p.bindings)
                {
                    if (str_cmp(b.name, "animation"))
                    {
                        Image &white = vkcontext->images[vkcontext->white.imageIdx];

                        foundAnimation = true;
                        DescriptorInfo textureInfos[10];

                        for (uint32_t i = 0; i < textureCount; i++)
                        {
                            //TODO: This assumes the texutures have correct indices, might have to check
                            if (pTextures[i].imageIdx < (uint32_t)vkcontext->images.size())
                            {
                                Image image = vkcontext->images[pTextures[i].imageIdx];

                                textureInfos[i] = {
                                    image.vkSampler,
                                    image.vkImageView,
                                    image.layout};
                            }
                            else
                            {
                                // Use white, this should never happen I think?
                                textureInfos[i] = {
                                    white.vkSampler,
                                    white.vkImageView,
                                    white.layout};
                            }
                        }

                        for (uint32_t i = textureCount; i < 10; i++)
                        {
                            textureInfos[i] = {
                                white.vkSampler,
                                white.vkImageView,
                                white.layout};
                        }

                        VkWriteDescriptorSet write = vkinit::write_descriptor_set(
                            VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                            desc.sets[b.set_number],
                            b.number,
                            textureInfos,
                            10);

                        vkUpdateDescriptorSets(
                            vkcontext->device,
                            1,
                            &write,
                            0, 0);

                        return true;
                    }
                }

                CAKEZ_ASSERT(foundAnimation, "Program at index %d has no animation sampler", desc.programIdx);
                return false;
            }
            else
            {
                CAKEZ_ASSERT(false, "Descriptor index %d out of bounds", material->descriptorIdx);
                return false;
            }
        }
        else
        {
            CAKEZ_ASSERT(false, "Animations can not exeed 10 textures");
            return false;
        }
    }

    //TODO: This function is not being used atm
    internal bool vk_set_material_attribute(
        VkContext *vkcontext,
        Material *material,
        const char *attributeName,
        void *data,
        uint32_t dataSize)
    {
        if (material->descriptorIdx < (uint32_t)vkcontext->programDescriptors.size())
        {
            ProgramDescriptor &desc = vkcontext->programDescriptors[material->descriptorIdx];

            Program p = vkcontext->programs[desc.programIdx];

            for (Binding &b : p.bindings)
            {
                if (str_cmp(b.name, "MaterialUBO"))
                {
                    //Search the attributes for the correct one
                    for (Attribute &a : b.attributes)
                    {
                        if (str_cmp(a.name, attributeName))
                        {
                            uint32_t attributeSize = a.get_size();
                            if (attributeSize == dataSize)
                            {
                                vk_copy_to_buffer(
                                    vkcontext,
                                    &desc.buffer.vkBuffer,
                                    &desc.buffer.memory,
                                    data,
                                    dataSize,
                                    a.offset);

                                return true;
                            }
                            else
                            {
                                CAKEZ_ASSERT(
                                    false,
                                    "Found Atribute %s but size of Attribute %d did not match incomming size %d",
                                    attributeName,
                                    attributeSize,
                                    dataSize);

                                return false;
                            }
                        }
                    }

                    CAKEZ_ASSERT(false,
                                 "No Attibute of name %s in MaterialUBO", attributeName);
                    return false;
                }
            }

            CAKEZ_ASSERT(false, "Program %d does not have a MaterialUBO", desc.programIdx);
            return false;
        }
        else
        {
            CAKEZ_ASSERT(false, "Descriptor index %d out of bounds", material->descriptorIdx);
            return false;
        }
    }

    internal RenderCommand *add_render_command(VkContext *vkcontext, Material *m, uint32_t layer)
    {
        RenderCommand *rc = 0;
        if (vkcontext->renderCommandCount < ArraySize(vkcontext->renderCommands))
        {
            rc = &vkcontext->renderCommands[vkcontext->renderCommandCount];
            vkcontext->renderCommandCount++;

            // Setting default values
            rc->instanceCount = 1;
            rc->mesh = &vkcontext->quad;
            rc->layer = layer;
            rc->descriptorIdx = m->descriptorIdx;
            rc->pushData.transformIdx = vkcontext->transformCount;
        }
        else
        {
            CAKEZ_ASSERT(0, "Reched maximum amount of render commands");
        }

        return rc;
    }

    internal Transform *add_transform(
        VkContext *vkcontext,
        const Vec4 &position,
        uint32_t animationIdx = 0,
        float u = 0.0f,
        float layer = 0.0f,
        float radius = 0.0f)
    {
        Transform *t = 0;
        if (vkcontext->transformCount < ArraySize(vkcontext->transforms))
        {
            t = &vkcontext->transforms[vkcontext->transformCount];
            vkcontext->transformCount++;

            t->position = position;
            t->animationIdx = animationIdx;
            t->u = u;
            t->layer = 1.0 - (layer / (float)LAYER_COUNT);
            t->radius = radius;
        }
        else
        {
            CAKEZ_ASSERT(0, "Reached maximum amount of transforms");
        }

        return t;
    }

    internal bool vk_resize_swapchain(
        VkContext *vkcontext,
        bool vSync)
    {
        if (vkcontext->device != VK_NULL_HANDLE)
        {
            // Update the screen size
            platform_get_window_size(
                &vkcontext->screenSize.width,
                &vkcontext->screenSize.height);

            // Make sure the device is not working anymore
            vkDeviceWaitIdle(vkcontext->device);

            // Copy new screensize to the global UBO
            {
                Vec2 screenSize = {
                    (float)vkcontext->screenSize.width,
                    (float)vkcontext->screenSize.height};

                vk_copy_to_buffer(
                    vkcontext,
                    &vkcontext->globalUniformBuffer.vkBuffer,
                    &vkcontext->globalUniformBuffer.memory,
                    &screenSize,
                    sizeof(Vec2));
            }

            // Cleanup swapchain
            {
                // Destroy depth image if present
                if (vkcontext->depthImage.vkImageView != VK_NULL_HANDLE &&
                    vkcontext->depthImage.vkImage != VK_NULL_HANDLE)
                {
                    vkDestroyImageView(vkcontext->device, vkcontext->depthImage.vkImageView, 0);
                    vkDestroyImage(vkcontext->device, vkcontext->depthImage.vkImage, 0);
                }

                for (uint32_t i = 0; i < (uint32_t)vkcontext->framebuffers.size(); i++)
                {
                    vkDestroyFramebuffer(vkcontext->device, vkcontext->framebuffers[i], 0);
                }

                for (uint32_t i = 0; i < (uint32_t)vkcontext->swapchainImageViews.size(); i++)
                {
                    vkDestroyImageView(vkcontext->device, vkcontext->swapchainImageViews[i], 0);
                }

                vkcontext->swapchainImages.clear();
                vkDestroySwapchainKHR(vkcontext->device, vkcontext->swapchain, 0);
            }

            // Create a new swapchain
            {
                vkcontext->swapchain =
                    create_swapchain(
                        vkcontext->device,
                        vkcontext->gpu,
                        vkcontext->surface,
                        vkcontext->swapchainImages,
                        vkcontext->swapchainImageViews,
                        vSync);
            }

            // Create a depth image
            {
                vk_allocate_image(
                    vkcontext,
                    &vkcontext->depthImage.vkImage,
                    &vkcontext->depthImage.memory,
                    VK_FORMAT_D32_SFLOAT,
                    VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
                    {vkcontext->screenSize.width, vkcontext->screenSize.height, 1});

                VkImageViewCreateInfo viewInfo = vkinit::image_view_create_info(
                    vkcontext->depthImage.vkImage, VK_FORMAT_D32_SFLOAT,
                    VK_IMAGE_ASPECT_DEPTH_BIT);
                VK_CHECK(vkCreateImageView(
                    vkcontext->device,
                    &viewInfo,
                    nullptr,
                    &vkcontext->depthImage.vkImageView));
            }

            // Creating framebuffers
            {
                vkcontext->framebuffers.resize(vkcontext->swapchainImages.size());

                VkFramebufferCreateInfo fbInfo = {};
                fbInfo.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
                fbInfo.renderPass = vkcontext->renderPass;
                fbInfo.attachmentCount = 1;
                fbInfo.width = vkcontext->screenSize.width;
                fbInfo.height = vkcontext->screenSize.height;
                fbInfo.layers = 1;

                for (size_t i = 0; i < vkcontext->framebuffers.size(); i++)
                {
                    std::vector<VkImageView> attachments = {
                        vkcontext->swapchainImageViews[i],
                        vkcontext->depthImage.vkImageView};

                    fbInfo.attachmentCount = static_cast<uint32_t>(attachments.size());
                    fbInfo.pAttachments = attachments.data();

                    VK_CHECK(vkCreateFramebuffer(
                        vkcontext->device,
                        &fbInfo,
                        nullptr,
                        &vkcontext->framebuffers[i]));
                }

                return true;
            }
        }
        else
        {
            return false;
        }
    }

    //TODO: Add correct error checking and return false in case an Error happens
    internal bool vk_init(
        VkContext *vkcontext,
        void *window,
        bool vSync = true)
    {
        platform_get_window_size(
            &vkcontext->screenSize.width,
            &vkcontext->screenSize.height);

        vkcontext->vSync = vSync;

        compile_shader("assets/shaders/animation.vert",
                       "assets/shaders/compiled/animation.vert.spv");
        compile_shader("assets/shaders/animation.frag",
                       "assets/shaders/compiled/animation.frag.spv");

        compile_shader("assets/shaders/sprites.vert",
                       "assets/shaders/compiled/sprites.vert.spv");
        compile_shader("assets/shaders/sprites.frag",
                       "assets/shaders/compiled/sprites.frag.spv");

        compile_shader("assets/shaders/glyphs.vert",
                       "assets/shaders/compiled/glyphs.vert.spv");
        compile_shader("assets/shaders/glyphs.frag",
                       "assets/shaders/compiled/glyphs.frag.spv");

        // Ensure counts are set to 0
        {
            vkcontext->currentFrame = 0;
            vkcontext->imageIndex = 0;
            vkcontext->vertexOffset = 0;
            vkcontext->indexOffset = 0;
        }

        vkcontext->instance = create_instance();

#ifdef DEBUG
        vkcontext->debugMessenger = create_debug_messenger(vkcontext->instance);
#endif //DEBUG

        vkcontext->surface = create_surface(vkcontext->instance, window);

        vkcontext->gpu = pick_gpu(
            vkcontext->instance,
            vkcontext->surface,
            &vkcontext->graphicsIdx,
            &vkcontext->transferIdx);

        VkPhysicalDeviceProperties gpuProps;
        vkGetPhysicalDeviceProperties(vkcontext->gpu, &gpuProps);
        CAKEZ_TRACE("GPU:               %s", gpuProps.deviceName);
        CAKEZ_TRACE("Vendor:            %d", gpuProps.apiVersion);
        CAKEZ_TRACE("Driver Version:    %d", gpuProps.driverVersion);
        CAKEZ_TRACE("Device ID:         %d", gpuProps.deviceID);

        std::vector<const char *> extensions = {
            VK_KHR_SWAPCHAIN_EXTENSION_NAME};

        // Store gpu props for later use
        vkGetPhysicalDeviceProperties(vkcontext->gpu, &vkcontext->gpuProps);

        // TODO: Add extensions here
        // if(device_supports_extension(VkContext::gpu, extensionName))

        vkcontext->device = create_device(
            vkcontext->gpu,
            vkcontext->transferIdx,
            vkcontext->graphicsIdx,
            extensions);

        // Get device queues
        {
            vkGetDeviceQueue(
                vkcontext->device,
                vkcontext->graphicsIdx,
                0, &vkcontext->graphicsQueue);

            vkGetDeviceQueue(
                vkcontext->device,
                vkcontext->transferIdx,
                0, &vkcontext->transferQueue);
        }

        // Create query pool
        {
            vkcontext->queryPool = create_query_pool(
                vkcontext->device,
                QUERY_POOL_COUNT,
                VK_QUERY_TYPE_TIMESTAMP);
        }

        vkcontext->swapchain =
            create_swapchain(
                vkcontext->device,
                vkcontext->gpu,
                vkcontext->surface,
                vkcontext->swapchainImages,
                vkcontext->swapchainImageViews,
                vSync);

        // Create a depth image
        {
            vk_allocate_image(
                vkcontext,
                &vkcontext->depthImage.vkImage,
                &vkcontext->depthImage.memory,
                VK_FORMAT_D32_SFLOAT,
                VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
                {vkcontext->screenSize.width, vkcontext->screenSize.height, 1});

            VkImageViewCreateInfo viewInfo = vkinit::image_view_create_info(
                vkcontext->depthImage.vkImage, VK_FORMAT_D32_SFLOAT,
                VK_IMAGE_ASPECT_DEPTH_BIT);
            VK_CHECK(vkCreateImageView(
                vkcontext->device,
                &viewInfo,
                nullptr,
                &vkcontext->depthImage.vkImageView));
        }

        // Create a render pass
        {
            VkAttachmentDescription colorAttachment =
                vkinit::attachment_description(
                    VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
                    VK_FORMAT_B8G8R8A8_SRGB,
                    VK_ATTACHMENT_STORE_OP_STORE);

            VkAttachmentDescription depthAttachment =
                vkinit::attachment_description(
                    VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
                    VK_FORMAT_D32_SFLOAT,
                    VK_ATTACHMENT_STORE_OP_DONT_CARE);

            VkAttachmentReference colorRef = {};
            colorRef.attachment = 0;
            colorRef.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

            VkAttachmentReference depthRef = {};
            depthRef.attachment = 1;
            depthRef.layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

            VkSubpassDescription subpass = {};
            subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
            subpass.colorAttachmentCount = 1;
            subpass.pColorAttachments = &colorRef;
            subpass.pDepthStencilAttachment = &depthRef;

            std::vector<VkAttachmentDescription> attachments = {colorAttachment, depthAttachment};

            VkRenderPassCreateInfo renderPassInfo = {};
            renderPassInfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
            renderPassInfo.pAttachments = attachments.data();
            renderPassInfo.attachmentCount = static_cast<uint32_t>(attachments.size());
            renderPassInfo.subpassCount = 1;
            renderPassInfo.pSubpasses = &subpass;

            VK_CHECK(vkCreateRenderPass(vkcontext->device, &renderPassInfo, nullptr, &vkcontext->renderPass));
        }

        // Creating framebuffers
        {
            vkcontext->framebuffers.resize(vkcontext->swapchainImages.size());

            VkFramebufferCreateInfo fbInfo = {};
            fbInfo.sType = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
            fbInfo.renderPass = vkcontext->renderPass;
            fbInfo.attachmentCount = 1;
            fbInfo.width = vkcontext->screenSize.width;
            fbInfo.height = vkcontext->screenSize.height;
            fbInfo.layers = 1;

            for (size_t i = 0; i < vkcontext->framebuffers.size(); i++)
            {
                std::vector<VkImageView> attachments = {
                    vkcontext->swapchainImageViews[i],
                    vkcontext->depthImage.vkImageView};

                fbInfo.attachmentCount = static_cast<uint32_t>(attachments.size());
                fbInfo.pAttachments = attachments.data();

                VK_CHECK(vkCreateFramebuffer(
                    vkcontext->device,
                    &fbInfo,
                    nullptr,
                    &vkcontext->framebuffers[i]));
            }
        }

        // Creating command pool
        {
            VkCommandPoolCreateInfo poolInfo =
                vkinit::command_pool_create_info(
                    vkcontext->graphicsIdx,
                    VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT);

            VK_CHECK(vkCreateCommandPool(
                vkcontext->device,
                &poolInfo,
                nullptr,
                &vkcontext->commandPool));
        }

        // Creating descriptor pool
        {
            std::vector<VkDescriptorPoolSize> poolSizes = {
                // Global Data and material Data, so two active at every point in time
                vkinit::desc_pool_size(VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 1000),
                // Transforms, one active over all pipelines
                vkinit::desc_pool_size(VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1000),
                // Textures, one active over all pipelines
                vkinit::desc_pool_size(VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1000)};

            VkDescriptorPoolCreateInfo poolInfo = vkinit::desc_pool_create_info(1000, poolSizes); // maximum 4 active descriptors at a time
            VK_CHECK(vkCreateDescriptorPool(
                vkcontext->device,
                &poolInfo,
                nullptr,
                &vkcontext->descPool));
        }

        // Creating sync object
        {
            vkcontext->frameSync.resize(FRAME_OVERLAP);
            VkSemaphoreCreateInfo semaphoreInfo = vkinit::semaphore_create_info();
            VkFenceCreateInfo fenceInfo = vkinit::fence_create_info(VK_FENCE_CREATE_SIGNALED_BIT);
            VkCommandBufferAllocateInfo allocInfo = vkinit::command_buffer_allocate_info(vkcontext->commandPool, 1);

            for (size_t i = 0; i < FRAME_OVERLAP; i++)
            {
                VK_CHECK(vkCreateSemaphore(
                    vkcontext->device,
                    &semaphoreInfo,
                    nullptr,
                    &vkcontext->frameSync[i].presentSemaphore));

                VK_CHECK(vkCreateSemaphore(
                    vkcontext->device,
                    &semaphoreInfo, nullptr,
                    &vkcontext->frameSync[i].renderSemaphore));

                VK_CHECK(vkCreateFence(
                    vkcontext->device,
                    &fenceInfo, nullptr,
                    &vkcontext->frameSync[i].aquireImageFence));

                VK_CHECK(vkAllocateCommandBuffers(
                    vkcontext->device,
                    &allocInfo,
                    &vkcontext->frameSync[i].cmd));
            }
        }

        // Staging Buffer creation
        {
            vkcontext->stagingBuffer.size = MB(1);
            vk_allocate_buffer(
                vkcontext,
                &vkcontext->stagingBuffer.vkBuffer,
                &vkcontext->stagingBuffer.memory,
                vkcontext->stagingBuffer.size,
                VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
                0,
                &vkcontext->stagingBuffer.mapped);
        }

        // Create default white texture
        {
            unsigned char white[4] = {255, 255, 255, 255};
            vkcontext->white.name = "white";
            vkcontext->white.imageIdx = vk_create_texture(
                vkcontext,
                TEXTURE_FORMAT_R8G8B8A8_UNORM,
                white,
                1,
                1);
        }

        // Create Vertex Buffer
        {
            vkcontext->vertexStorageBuffer.size = MB(8);
            vk_allocate_buffer(
                vkcontext,
                &vkcontext->vertexStorageBuffer.vkBuffer,
                &vkcontext->vertexStorageBuffer.memory,
                vkcontext->vertexStorageBuffer.size,
                VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        }

        // Create Index buffer
        {
            vkcontext->indexStorageBuffer.size = MB(8);
            vk_allocate_buffer(
                vkcontext,
                &vkcontext->indexStorageBuffer.vkBuffer,
                &vkcontext->indexStorageBuffer.memory,
                vkcontext->indexStorageBuffer.size,
                VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        }

        // Create Transform buffer
        {
            vkcontext->transformStorageBuffer.size = sizeof(Transform) * MAX_ENTITIES * 2;
            vk_allocate_buffer(
                vkcontext,
                &vkcontext->transformStorageBuffer.vkBuffer,
                &vkcontext->transformStorageBuffer.memory,
                vkcontext->transformStorageBuffer.size,
                VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
                0,
                &vkcontext->transformStorageBuffer.mapped);
        }

        // Create the quad mesh
        {
            uint32_t indices[] = {0, 1, 2, 2, 3, 0};
            vkcontext->quad = vk_create_mesh(
                vkcontext,
                0, 0,
                indices, 6);
        }

        //Create a UBO containing global data
        {
            vkcontext->globalUniformBuffer.size = sizeof(GlobalData);

            vk_allocate_buffer(
                vkcontext,
                &vkcontext->globalUniformBuffer.vkBuffer,
                &vkcontext->globalUniformBuffer.memory,
                vkcontext->globalUniformBuffer.size,
                VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                0);

            Vec2 floatScreenSize = {
                (float)vkcontext->screenSize.width,
                (float)vkcontext->screenSize.height};
            vk_copy_to_buffer(
                vkcontext,
                &vkcontext->globalUniformBuffer.vkBuffer,
                &vkcontext->globalUniformBuffer.memory,
                &floatScreenSize,
                sizeof(Vec2));
        }

        // Create a UBO containing glyph data
        {
            uint32_t bufferSize;
            //TODO: Get the font file somewhere, best would be from an asset file
            const char *arialTTF = platform_read_file("assets/fonts/arial.ttf", bufferSize);
            stbtt_fontinfo font;
            stbtt_InitFont(&font, (unsigned char *)arialTTF, 0);

            vkcontext->glyphCache.fontSize = GLYPH_WIDTH;
            int glyphPadding = 0;

            int testPadding = 8;

            /* calculate font scaling */
            float scale = stbtt_ScaleForPixelHeight(&font, GLYPH_WIDTH);

            uint32_t imageWidthHeight = 512;

            int imageSize = imageWidthHeight * imageWidthHeight;
            //TODO: Use a big memory block "gameMemory" and store the grayscaleImage there
            std::vector<unsigned char> grayscaleImage(imageSize);

            uint32_t currentRowWidth = 0;
            uint32_t currentRow = 0;

            // Load glyphs from '!' to '~'
            for (char i = 33; i <= 126; i++)
            {
                unsigned char bitmap[30000] = {};
                // int width, height, xOffset, yOffset, advance, leftSideBearing;

                // stbtt_GetCodepointHMetrics(&font, i, &advance, &leftSideBearing);

                int x0, x1, y0, y1;

                stbtt_GetCodepointBitmapBoxSubpixel(&font, i, scale,
                                                    scale, 0, 0, &x0, &y0, &x1, &y1);

                int width = x1 - x0;
                int height = y1 - y0;

                stbtt_MakeCodepointBitmapSubpixel(&font, bitmap, width, height, width,
                                                  scale, scale, 0, 0, i);

                // advance *= scale;
                // leftSideBearing *= scale;

                // bitmap = stbtt_GetCodepointSDF(&font, scale, i, testPadding, 90, 10, &width,
                //                                &height, &xOffset, &yOffset);

                // bitmap = stbtt_GetCodepointBitmap(
                //     &font,
                //     0,
                //     scale,
                //     i,
                //     &width,
                //     &height,
                //     &xOffset,
                //     &yOffset);

                // when yOffset is negative glyphs get offset up along the Y - axis,
                // this is what we are interested in
                // int yOffsetPositive = (yOffset * (-1));
                // if (vkcontext->glyphCache.largestYOffset < yOffsetPositive)
                // {
                //     vkcontext->glyphCache.largestYOffset = yOffsetPositive;
                // }

                // Begin next row if we reached the edge of the image
                if (currentRowWidth + width >= imageWidthHeight)
                {
                    currentRow++;
                    currentRowWidth = glyphPadding;
                }

                // Write the glyph to the grayscale image
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        unsigned char c = bitmap[y * width + x];
                        uint32_t yOff = ((currentRow * (vkcontext->glyphCache.fontSize + 2 * glyphPadding)) + y + glyphPadding) * imageWidthHeight;
                        grayscaleImage[yOff + currentRowWidth + glyphPadding + x] = c;
                        // uint32_t yOff = ((currentRow * (vkcontext->glyphCache.fontSize)) + y) * imageWidthHeight;
                        // grayscaleImage[yOff + currentRowWidth + x] = c;
                    }
                }

                // stbtt_FreeBitmap(bitmap, 0);

                Glyph glyph = {};
                glyph.width = width;
                glyph.height = height;
                // glyph.advance = advance;
                // glyph.leftSideBearing = leftSideBearing;

                // Pack uvs into 8 bytes each
                {
                    float luFloat = (float)currentRowWidth / (float)imageWidthHeight;
                    float ruFloat = (float)(currentRowWidth + width + glyphPadding) / (float)imageWidthHeight;
                    float tvFloat = (float)(currentRow * (vkcontext->glyphCache.fontSize + 2 * glyphPadding)) / (float)imageWidthHeight;
                    float bvFloat = (float)(currentRow * (vkcontext->glyphCache.fontSize + 2 * glyphPadding) + height + 2 * glyphPadding) / (float)imageWidthHeight;

                    glyph.lu = luFloat;
                    glyph.ru = ruFloat;
                    glyph.tv = tvFloat;
                    glyph.bv = bvFloat;

                    uint8_t lu =
                        pack_uint8((float)currentRowWidth / (float)imageWidthHeight);

                    uint8_t ru =
                        pack_uint8((float)(currentRowWidth + width + glyphPadding) / (float)imageWidthHeight);

                    uint8_t tv =
                        pack_uint8((float)(currentRow * (vkcontext->glyphCache.fontSize + glyphPadding)) / (float)imageWidthHeight);

                    //TODO: Might need to add padding here, too
                    uint8_t bv =
                        pack_uint8((float)(currentRow * (vkcontext->glyphCache.fontSize + glyphPadding) + height) / (float)imageWidthHeight);

                    // glyph.uvs = (lu + (ru << 8) + (tv << 16) + (bv << 24));
                }

                // Pack x and y offsets into 16 bytes
                // glyph.xyoff = xOffset + (yOffset << 16);
                // glyph.xOff = xOffset;
                // glyph.yOff = yOffset;
                vkcontext->glyphCache.glyphs.push_back(glyph);

                currentRowWidth += width + glyphPadding * 2;
            }

            vkcontext->glyphCache.glyphAtlas.name = "GlyphAtlas";
            vkcontext->glyphCache.glyphAtlas.imageIdx = vk_create_texture(
                vkcontext,
                TEXTURE_FORMAT_R8_UNORM,
                grayscaleImage.data(),
                imageWidthHeight,
                imageWidthHeight,
                0, 1, 0, true);

            // Copy the glyphs to the buffer
            {
                vk_allocate_buffer(
                    vkcontext,
                    &vkcontext->glyphCache.glpyhUBO.vkBuffer,
                    &vkcontext->glyphCache.glpyhUBO.memory,
                    sizeof(Glyph) * vkcontext->glyphCache.glyphs.size(),
                    VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                    VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                    vkcontext->glyphCache.glyphs.data());
            }
        }

        // Create a storage buffer to use for glyph transforms
        {
            vk_allocate_buffer(
                vkcontext,
                &vkcontext->glyphTransformStorageBuffer.vkBuffer,
                &vkcontext->glyphTransformStorageBuffer.memory,
                sizeof(GlyphTransform) * MAX_GLYPHS,
                VK_BUFFER_USAGE_TRANSFER_DST_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        }

        // Create a material to use in text rendering
        {
            Material *m = vk_create_material(vkcontext, textShaders, ASSET_TEXT, true);
            vk_set_material_sampler(
                vkcontext,
                m,
                "glyphAtlas",
                &vkcontext->glyphCache.glyphAtlas);
        }

        return true;
    }

    internal Material *vk_get_material(
        VkContext *vkcontext,
        Assets *assets,
        AssetTypeID assetID,
        bool colorBlending = false)
    {
        Material *m = 0;
        for (uint32_t i = 0; i < vkcontext->materialCount; i++)
        {
            if (vkcontext->materials[i].assetID == assetID &&
                vkcontext->materials[i].colorBlending == colorBlending)
            {
                m = &vkcontext->materials[i];
                break;
            }
        }

        // Did not find a material, so we create a new one base on the asset type
        if (!m)
        {
            Asset *asset = get_asset(assets, assetID);

            if (asset)
            {

                switch (asset->type)
                {
                case ASSET_TYPE_ANIMATION:
                {

                    m = vk_create_material(vkcontext, animationShaders, assetID, colorBlending);
                    Texture *textures = get_asset_textures(assets, (AssetTypeID)m->assetID);
                    vk_set_material_animation(
                        vkcontext,
                        m,
                        textures,
                        asset->count);
                    break;
                }

                case ASSET_TYPE_SPRITE:
                {
                    m = vk_create_material(vkcontext, spriteShaders, assetID, colorBlending);
                    Texture *textures = get_asset_textures(assets, (AssetTypeID)m->assetID);
                    vk_set_material_sampler(
                        vkcontext,
                        m,
                        "sprite",
                        textures);

                    if (asset->count > 1)
                    {
                        vk_set_material_sampler(
                            vkcontext,
                            m,
                            "mask",
                            textures + 1);
                    }
                    break;
                }
                }
            }
        }

        return m;
    }

    //TODO: Place elsewhere
    internal void render_glyph(VkContext *vkcontext,
                               Assets *assets,
                               char *text,
                               uint32_t textLength,
                               Vec2 origin,
                               int layer,
                               bool leftAlign = true)
    {
        if (text)
        {
            Material *m = vk_get_material(vkcontext, assets, ASSET_TEXT, true);
            RenderCommand *rc = add_render_command(vkcontext, m, layer);
            rc->pushData.transformIdx = vkcontext->glyphTransformCount;
            rc->instanceCount = 0;

            //This will put the anchor for texts to the top left
            origin.y += (float)vkcontext->glyphCache.largestYOffset;

            for (int i = (leftAlign ? 0 : textLength - 1);
                 (leftAlign ? i < textLength : i >= 0);
                 (leftAlign ? i++ : i--))
            {
                char c = text[i];

                if (c == ' ')
                {
                    //TODO: Might want to crate a struct member if glph cache for this
                    origin.x = leftAlign ? origin.x + vkcontext->glyphCache.fontSize / 2
                                         : origin.x - vkcontext->glyphCache.fontSize / 2;
                    continue;
                }

                GlyphTransform transform = {};
                transform.glyphIdx = c - 33;
                rc->instanceCount++;

                //This will put the anchor for texts to the top left
                Glyph g = vkcontext->glyphCache.glyphs[c - 33];

                if (!leftAlign)
                {
                    origin.x -= g.advance + g.leftSideBearing;
                }

                // Calculate glyph position
                transform.pos.x = origin.x + g.xOff;
                transform.pos.y = origin.y + g.yOff;

                // Scoped function add_glyphtransform(transform) would be nice but c++ doesn't allow...
                // Adding a glyphTransform
                if (vkcontext->glyphTransformCount < ArraySize(vkcontext->glyphTransforms))
                {
                    vkcontext->glyphTransforms[vkcontext->glyphTransformCount] = transform;
                    vkcontext->glyphTransformCount++;
                }

                if (leftAlign)
                {
                    origin.x += g.advance - g.leftSideBearing;
                }
            }
        }
    }

    //TODO: Add correct error checking and return false in case an error happens
    internal bool vk_render(
        VkContext *vkcontext,
        UIState *ui,
        GameState *gameState,
        Assets *assets)
    {
        auto start = std::chrono::high_resolution_clock::now();
#ifdef DEBUG
        // Debug hitbox circles
        {
            if (gameState->entityCount)
            {
                Material *m = vk_get_material(vkcontext, assets, ASSET_WHITE, true);
                RenderCommand *rc = add_render_command(vkcontext, m, LAYER_DEBUG_CIRCLE);
                rc->instanceCount = 0;

                for (uint32_t i = 0; i < gameState->entityCount; i++)
                {
                    Entity *e = &gameState->entities[i];

                    if (has_component(e, HERO_COMPONENT) ||
                        has_component(e, ENEMY_COMPONENT))
                    {
                        rc->instanceCount++;

                        Vec2 circleOrigin = get_hitbox_origin(e->rect);

                        // Supply the hitboxradius to the shader
                        if (has_component(e, HERO_COMPONENT))
                        {
                            Transform *t = add_transform(vkcontext,
                                                         {circleOrigin.x - e->attackRadius,
                                                          circleOrigin.y - e->attackRadius,
                                                          e->attackRadius * 2,
                                                          e->attackRadius * 2});
                            t->radius = e->attackRadius;
                        }
                        else
                        {
                            Transform *t = add_transform(vkcontext,
                                                         {circleOrigin.x - e->hitboxRadius,
                                                          circleOrigin.y - e->hitboxRadius,
                                                          e->hitboxRadius * 2,
                                                          e->hitboxRadius * 2});
                            t->radius = e->hitboxRadius;
                        }
                    }
                }
            }
        }
#endif
        // Entity rendering
        {
            Rect screenRect = {0.0f,
                               0.0f,
                               (float)vkcontext->screenSize.width,
                               (float)vkcontext->screenSize.height};

            uint32_t layer = 0;
            Material *currentMaterial = 0;
            RenderCommand *rc = 0;
            for (uint32_t i = 0; i < gameState->entityCount; i++)
            {
                Entity *e = &gameState->entities[i];

                // Screen Culling
                if (rect_collision(e->rect, screenRect))
                {
                    Material *m = vk_get_material(vkcontext, assets, e->assetID);
                    if (m)
                    {
                        if (has_component(e, SPRITE_COMPONENT))
                        {
                            if (m != currentMaterial || layer != e->layer || !rc)
                            {
                                rc = add_render_command(vkcontext, m, e->layer);

                                // Watch the current material
                                currentMaterial = m;

                                // Watch the current layer
                                layer = e->layer;
                            }
                            else
                            {
                                rc->instanceCount++;
                            }

                            add_transform(
                                vkcontext,
                                *((Vec4 *)&e->rect),
                                e->animationIdx,
                                e->u,
                                e->layer);
                        }
                    }
                    else
                    {
                        CAKEZ_TRACE("No material for asset: %d, skipping entity");
                    }
                }
            }
        }

        // UI Rendering
        {
            if (ui->uiElementCount)
            {
                RenderCommand *rc = 0;
                Material *currentMaterial = 0;
                for (uint32_t i = 0; i < ui->uiElementCount; i++)
                {
                    UIEle *e = &ui->uiElements[i];
                    Material *m = vk_get_material(vkcontext, assets, e->assetID);

                    // Renders a Rectangle
                    if (m)
                    {
                        if (m != currentMaterial || !rc)
                        {
                            rc = add_render_command(vkcontext, m, e->ID.layer);
                            currentMaterial = m;
                        }
                        else
                        {
                            rc->instanceCount++;
                        }

                        add_transform(
                            vkcontext,
                            *((Vec4 *)&e->rect));
                    }

                    // Renders Text
                    if (e->label)
                    {
                        render_glyph(vkcontext, assets, e->label, e->labelLength, e->rect.pos, e->ID.layer + 1);
                    }

                    // Renders Number as Text
                    if (e->value != INT32_MAX)
                    {
                        char buffer[20];
                        int length = 0;
                        convert_number_to_char(e->value, buffer, &length);
                        render_glyph(vkcontext, assets, buffer, length, e->rect.pos, e->ID.layer + 1);
                    }
                }
            }
        }

        // Sort the render commands by layer to sort the entities and hitbox circles
        {
            std::sort(
                vkcontext->renderCommands,
                (vkcontext->renderCommands + vkcontext->renderCommandCount),
                [](RenderCommand &a, RenderCommand &b)
                {
                    return a.layer < b.layer;
                });
        }

        // Copy transforms to the buffers
        {
            if (vkcontext->glyphTransformCount)
            {
                // Material *m = vk_get_material(vkcontext, assets, ASSET_TEXT, true);

                // RenderCommand *rc = add_render_command(vkcontext, m, LAYER_TEXT);
                // rc->instanceCount = vkcontext->glyphTransformCount;

                vk_copy_to_buffer(
                    vkcontext,
                    &vkcontext->glyphTransformStorageBuffer.vkBuffer,
                    &vkcontext->glyphTransformStorageBuffer.memory,
                    vkcontext->glyphTransforms,
                    vkcontext->glyphTransformCount * sizeof(GlyphTransform));
            }

            if (vkcontext->transformCount)
            {
                copy_to_buffer(
                    vkcontext->transformStorageBuffer.mapped,
                    &vkcontext->transforms,
                    sizeof(Transform) * vkcontext->transformCount);
            }
            // Reset transfromCount for the next frame
            vkcontext->transformCount = 0;
            // Reset the count for the next frame
            vkcontext->glyphTransformCount = 0;
        }

        auto entityLoop = std::chrono::high_resolution_clock::now();

        auto renderCommandSorting = std::chrono::high_resolution_clock::now();

        VK_CHECK(vkWaitForFences(
            vkcontext->device,
            1,
            &vkcontext->frameSync[vkcontext->currentFrame].aquireImageFence,
            true,
            1000000000));
        auto fenceWaiting = std::chrono::high_resolution_clock::now();

        if (!firstRun)
        {
            uint64_t timestampResults[4] = {};
            VkResult result = vkGetQueryPoolResults(
                vkcontext->device,
                vkcontext->queryPool,
                0,
                4,
                sizeof(uint64_t) * 4,
                timestampResults,
                sizeof(uint64_t),
                VK_QUERY_RESULT_64_BIT | VK_QUERY_RESULT_WAIT_BIT);

            VK_CHECK(result);

            vkcontext->frameGPUBegin = double(timestampResults[0]) * vkcontext->gpuProps.limits.timestampPeriod * 1e-6;
            vkcontext->frameGPUEnd = double(timestampResults[3]) * vkcontext->gpuProps.limits.timestampPeriod * 1e-6;
            vkcontext->gpuTime = vkcontext->frameGPUEnd - vkcontext->frameGPUBegin;
            vkcontext->renderLoopBegin = double(timestampResults[1]) * vkcontext->gpuProps.limits.timestampPeriod * 1e-6;
            vkcontext->renderLoopEnd = double(timestampResults[2]) * vkcontext->gpuProps.limits.timestampPeriod * 1e-6;
        }

        VK_CHECK(vkResetFences(
            vkcontext->device,
            1,
            &vkcontext->frameSync[vkcontext->currentFrame].aquireImageFence));
        auto resetFence = std::chrono::high_resolution_clock::now();

        VkResult result = vkAcquireNextImageKHR(
            vkcontext->device,
            vkcontext->swapchain,
            UINT64_MAX,
            vkcontext->frameSync[vkcontext->currentFrame].presentSemaphore,
            VK_NULL_HANDLE,
            &vkcontext->imageIndex);
        auto acquireImage = std::chrono::high_resolution_clock::now();
        VK_CHECK(result);

        if (result == VK_ERROR_OUT_OF_DATE_KHR) // i.e. we changed the window size
        {
            CAKEZ_WARN("Acquire next Image resulted in VK_ERROR_OUT_OF_DATE_KHR {0}, this happens when the window was resized", VK_ERROR_OUT_OF_DATE_KHR);
            vk_resize_swapchain(vkcontext, vkcontext->vSync);
            return false;
        }

        VkCommandBuffer cmd = vkcontext->frameSync[vkcontext->currentFrame].cmd;

        vkResetCommandBuffer(cmd, 0);
        auto resetCommandBuffer = std::chrono::high_resolution_clock::now();

        VkCommandBufferBeginInfo cmdBeginInfo = {};
        cmdBeginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
        cmdBeginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;

        vkBeginCommandBuffer(cmd, &cmdBeginInfo);
        auto beginCommandBuffer = std::chrono::high_resolution_clock::now();

        vkCmdResetQueryPool(cmd, vkcontext->queryPool, 0, QUERY_POOL_COUNT);
        vkCmdWriteTimestamp(cmd, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, vkcontext->queryPool, 0);

        VkClearValue clearValue;
        clearValue.color = {48.0f / 255.0f, 10.0f / 255.0f, 36.0f / 255.0f, 1.0f};

        VkClearValue depthClear;
        depthClear.depthStencil.depth = 0.0f;

        VkRenderPassBeginInfo rpInfo = vkinit::renderpass_begin_info(
            vkcontext->renderPass,
            vkcontext->screenSize,
            vkcontext->framebuffers[vkcontext->imageIndex]);

        VkClearValue clearValues[] = {clearValue, depthClear};
        rpInfo.clearValueCount = 2;
        rpInfo.pClearValues = clearValues;

        vkCmdBeginRenderPass(cmd, &rpInfo, VK_SUBPASS_CONTENTS_INLINE);
        auto beginRenderPass = std::chrono::high_resolution_clock::now();

        VkViewport viewport = vkinit::viewport(vkcontext->screenSize);

        VkRect2D scissor = vkinit::scissor(vkcontext->screenSize);

        vkCmdSetViewport(
            cmd,
            0,
            1,
            &viewport);

        vkCmdSetScissor(
            cmd,
            0,
            1,
            &scissor);
        auto setupRenderer = std::chrono::high_resolution_clock::now();

        // The render loop begins here
        {
            vkCmdWriteTimestamp(cmd, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, vkcontext->queryPool, 1);
            VkDeviceSize offset = 0;
            vkCmdBindIndexBuffer(cmd, vkcontext->indexStorageBuffer.vkBuffer, offset, VK_INDEX_TYPE_UINT32);

            for (uint32_t i = 0; i < vkcontext->renderCommandCount; i++)
            {
                RenderCommand *rc = &vkcontext->renderCommands[i];
                ProgramDescriptor desc = vkcontext->programDescriptors[rc->descriptorIdx];
                Program &p = vkcontext->programs[desc.programIdx];

                vkCmdBindPipeline(
                    cmd,
                    VK_PIPELINE_BIND_POINT_GRAPHICS,
                    p.pipeline);

                vkCmdBindDescriptorSets(
                    cmd,
                    VK_PIPELINE_BIND_POINT_GRAPHICS,
                    p.layout,
                    0,
                    static_cast<uint32_t>(desc.sets.size()),
                    desc.sets.data(),
                    0, 0);

                if (p.usePushConstants)
                {
                    vkCmdPushConstants(
                        cmd,
                        p.layout,
                        VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT,
                        0,
                        sizeof(PushData),
                        &rc->pushData);
                }

                vkCmdDrawIndexed(
                    cmd,
                    rc->mesh->indexCount,
                    rc->instanceCount,
                    rc->mesh->indexOffset,
                    rc->mesh->vertexOffset,
                    0);
            }

            vkcontext->transformCount = 0;
            vkcontext->renderCommandCount = 0;
            vkCmdWriteTimestamp(cmd, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, vkcontext->queryPool, 2);
        }

        auto renderLoop = std::chrono::high_resolution_clock::now();

        vkCmdEndRenderPass(cmd);
        vkCmdWriteTimestamp(cmd, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, vkcontext->queryPool, 3);
        vkEndCommandBuffer(cmd);
        auto endCommandBuffer = std::chrono::high_resolution_clock::now();

        VkPipelineStageFlags waitStage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;

        VkSubmitInfo submit = {};
        submit.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
        submit.pWaitDstStageMask = &waitStage;
        submit.waitSemaphoreCount = 1;
        submit.pWaitSemaphores = &vkcontext->frameSync[vkcontext->currentFrame].presentSemaphore;
        submit.signalSemaphoreCount = 1;
        submit.pSignalSemaphores = &vkcontext->frameSync[vkcontext->currentFrame].renderSemaphore;
        submit.commandBufferCount = 1;
        submit.pCommandBuffers = &cmd;

        VK_CHECK(vkQueueSubmit(
            vkcontext->graphicsQueue,
            1,
            &submit,
            vkcontext->frameSync[vkcontext->currentFrame].aquireImageFence));
        auto queueSubmit = std::chrono::high_resolution_clock::now();

        VkPresentInfoKHR present = {};
        present.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
        present.pSwapchains = &vkcontext->swapchain;
        present.swapchainCount = 1;
        present.waitSemaphoreCount = 1;
        present.pWaitSemaphores = &vkcontext->frameSync[vkcontext->currentFrame].renderSemaphore;
        present.pImageIndices = &vkcontext->imageIndex;

        result = vkQueuePresentKHR(vkcontext->graphicsQueue, &present);

        if (result == VK_ERROR_OUT_OF_DATE_KHR) // i.e. we changed the window size
        {
            CAKEZ_WARN("Trying to presend resulted in out of date, we need to resize");
            vk_resize_swapchain(vkcontext, vkcontext->vSync);
            return false;
        }
        auto presentTime = std::chrono::high_resolution_clock::now();

        // TODO: Timing

        vkcontext->entityLoop = std::chrono::duration<double, std::milli>(entityLoop - start).count();
        // vkcontext->glyphLoop = std::chrono::duration<double, std::milli>(glyphs - entityLoop).count();
        // vkcontext->sortingRenderCommands = std::chrono::duration<double, std::milli>(renderCommandSorting - glyphs).count();
        vkcontext->fenceWaiting = std::chrono::duration<double, std::milli>(fenceWaiting - renderCommandSorting).count();

        vkcontext->resetFence = std::chrono::duration<double, std::milli>(resetFence - fenceWaiting).count();
        vkcontext->acquireImage = std::chrono::duration<double, std::milli>(acquireImage - resetFence).count();
        vkcontext->restCommandBuffer = std::chrono::duration<double, std::milli>(resetCommandBuffer - acquireImage).count();
        vkcontext->beginCommandBuffer = std::chrono::duration<double, std::milli>(beginCommandBuffer - resetCommandBuffer).count();
        vkcontext->beginRenderPass = std::chrono::duration<double, std::milli>(beginRenderPass - beginCommandBuffer).count();
        vkcontext->setupRender = std::chrono::duration<double, std::milli>(setupRenderer - beginRenderPass).count();

        vkcontext->renderLoop = std::chrono::duration<double, std::milli>(renderLoop - setupRenderer).count();
        vkcontext->endCommandBuffer = std::chrono::duration<double, std::milli>(endCommandBuffer - renderLoop).count();
        vkcontext->queueSubmit = std::chrono::duration<double, std::milli>(queueSubmit - endCommandBuffer).count();
        vkcontext->present = std::chrono::duration<double, std::milli>(presentTime - queueSubmit).count();

        vkcontext->currentFrame += 1;
        vkcontext->currentFrame %= FRAME_OVERLAP;

        firstRun = false;
        return true;
    }

    //##########################################################################
    //                  Implementations from vk_renderer.h
    //##########################################################################
    Texture vk_create_texture(
        VkContext *vkcontext,
        const char *texturePath,
        TextureFormat textureFormat)
    {
        if (str_cmp(texturePath, "white"))
        {
            return vkcontext->white;
        }
        else
        {
            DDSFile ddsFile;
            if (load_dds_file(texturePath, ddsFile))
            {
                Texture t = {};
                t.name = texturePath;

                t.imageIdx = vk_create_texture(
                    vkcontext,
                    textureFormat,
                    ddsFile.textureData,
                    ddsFile.header->Width,
                    ddsFile.header->Height,
                    (MipMapLevel *)ddsFile.levels,
                    ddsFile.header->MipLevelCount,
                    ddsFile.textureSize);

                return t;
            }
            else
            {
                CAKEZ_ASSERT(false, "Could not load texture: %s, using white texture", texturePath);
                return vkcontext->white;
            }
        }
    }
} // namespace Cakez
