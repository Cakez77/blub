#pragma once

#include <vulkan/vulkan.h>

#include "vk_types.h"
#include <vector>

//TODO: Remove vector and use cound everywhere

namespace vkinit
{
	VkApplicationInfo application_info();

	VkInstanceCreateInfo instance_create_info(const VkApplicationInfo &appInfo);

	VkDebugUtilsMessengerCreateInfoEXT debug_utils_create_info(
		const PFN_vkDebugUtilsMessengerCallbackEXT debug_callback,
		const VkDebugUtilsMessageSeverityFlagsEXT messageSeverity,
		const VkDebugUtilsMessageTypeFlagsEXT messageType);

	VkDeviceQueueCreateInfo device_queue_create_info(uint32_t index, float &priority);

	VkPhysicalDeviceFeatures device_features();

	VkDeviceCreateInfo device_info(
		const char *extensions[],
		uint32_t extensionCount,
		VkDeviceQueueCreateInfo *queueInfos,
		uint32_t queueCount,
		VkPhysicalDeviceFeatures& features);

	VkQueryPoolCreateInfo query_pool_info(
		VkQueryType queryType,
		uint32_t queryCount = 128);

	VkImageCreateInfo image_create_info(VkFormat format, VkImageUsageFlags usage, VkExtent3D extent, uint32_t levels = 1u, uint32_t layers = 1u);

	VkImageViewCreateInfo image_view_create_info(VkImage image = VK_NULL_HANDLE, VkFormat format = VK_FORMAT_B8G8R8A8_SRGB, VkImageAspectFlags aspectFlags = VK_IMAGE_ASPECT_COLOR_BIT, VkImageViewType viewType = VK_IMAGE_VIEW_TYPE_2D, uint32_t levelCount = 1u, uint32_t layerCount = 1u);

	VkAttachmentDescription attachment_description(VkImageLayout finalLayout, VkFormat format = VK_FORMAT_B8G8R8A8_SRGB, VkAttachmentStoreOp storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE);

	//-------------------------------------------------------------------------------------------
	// Graphics Pipeline Structures
	VkPipelineShaderStageCreateInfo pipeline_shader_stage_create_info(VkShaderStageFlagBits stage, VkShaderModule shaderModule);

	VkPipelineVertexInputStateCreateInfo vertex_input_state_create_info();

	VkPipelineVertexInputStateCreateInfo vertex_input_state_create_info(std::vector<VkVertexInputAttributeDescription> &attributes, std::vector<VkVertexInputBindingDescription> &bindings);

	VkVertexInputBindingDescription vertex_input_binding_description(uint32_t binding, uint32_t stride, VkVertexInputRate inputRate);

	VkVertexInputAttributeDescription vertex_input_attribute_description(uint32_t binding, uint32_t location, VkFormat format, uint32_t offset);

	VkPipelineInputAssemblyStateCreateInfo input_assembly_create_info(VkPrimitiveTopology topology, VkBool32 restartEnable = VK_FALSE);

	VkViewport viewport(VkExtent2D extent);

	VkRect2D scissor(VkExtent2D extent);

	VkPipelineViewportStateCreateInfo viewport_state_create_info(VkViewport &viewport, VkRect2D &scissor);

	VkPipelineRasterizationStateCreateInfo rasterization_state_create_info(VkPolygonMode polygonMode);

	VkPipelineMultisampleStateCreateInfo multisampling_state_create_info();

	VkPipelineColorBlendStateCreateInfo color_blend_state_crate_info(uint32_t attachmentcount, VkPipelineColorBlendAttachmentState *attachment);

	VkPipelineColorBlendAttachmentState color_blend_attachment_state();

	VkPipelineDepthStencilStateCreateInfo depth_stencil_create_info(bool bDepthTest, bool bDepthWrite, VkCompareOp compareOp);

	VkPipelineDynamicStateCreateInfo dynamic_state_create_info(
		VkDynamicState dynamicStates[],
		uint32_t dynamicStateCount);

	VkPipelineLayoutCreateInfo pipeline_layout_create_info(VkDescriptorSetLayout &setLayout); // will probably change to something else

	VkPipelineLayoutCreateInfo pipeline_layout_create_info(std::vector<VkDescriptorSetLayout> &setLayouts);

	VkComputePipelineCreateInfo compute_pipeline_create_info(VkPipelineShaderStageCreateInfo stageInfo, VkPipelineLayout layout);

	VkPushConstantRange push_constant_range(VkShaderStageFlags flags, uint32_t size, uint32_t offset = 0U);

	VkSpecializationMapEntry specialization_map_entry(uint32_t id, uint32_t offset, size_t size);

	VkSpecializationInfo specialization_info(const std::vector<VkSpecializationMapEntry> &entries, size_t size, const void *data);
	//------------------------------------------------------------------------------------------

	VkSamplerCreateInfo sampler_create_info(float maxLod = VK_LOD_CLAMP_NONE, VkSamplerAddressMode addressMode = VK_SAMPLER_ADDRESS_MODE_REPEAT, VkCompareOp compareOpeartion = VK_COMPARE_OP_NEVER);

	VkCommandPoolCreateInfo command_pool_create_info(uint32_t queueFamilyIdx, VkCommandPoolResetFlags flags);

	VkDescriptorSetLayoutBinding descriptorset_layout_binding(VkDescriptorType type, VkShaderStageFlags stageFlags, uint32_t binding, uint32_t descCount = 1U);

	VkDescriptorSetLayoutCreateInfo descriptorset_layout_create_info(uint32_t bindingCount, VkDescriptorSetLayoutBinding *bindings);

	VkDescriptorPoolSize desc_pool_size(VkDescriptorType type, uint32_t descCount);

	VkDescriptorPoolCreateInfo desc_pool_create_info(uint32_t maxSets, const std::vector<VkDescriptorPoolSize> &poolSizes);

	VkDescriptorSetAllocateInfo descriptorset_allocate_info(VkDescriptorPool pool, uint32_t descCount, VkDescriptorSetLayout *layout);

	VkDescriptorBufferInfo descriptor_buffer_info(VkBuffer buffer, VkDeviceSize range, VkDeviceSize offset = 0);

	VkDescriptorImageInfo descriptor_image_info(VkImageView view, VkSampler sampler);

	VkWriteDescriptorSet write_descriptor_set(
		VkDescriptorType type,
		VkDescriptorSet set,
		uint32_t binding,
		Cakez::DescriptorInfo *descInfos,
		uint32_t count = 1u);

	VkCommandBufferAllocateInfo command_buffer_allocate_info(VkCommandPool pool, uint32_t count = 1, VkCommandBufferLevel level = VK_COMMAND_BUFFER_LEVEL_PRIMARY);

	VkCommandBufferBeginInfo command_buffer_begin_info(VkCommandBufferUsageFlags flags);

	VkSubmitInfo submit_info(VkCommandBuffer &cmd);

	VkFenceCreateInfo fence_create_info(VkFenceCreateFlags flags = 0);

	VkSemaphoreCreateInfo semaphore_create_info();

	VkBufferCreateInfo buffer_create_info(VkBufferUsageFlags flags, VkDeviceSize size);

	VkImageMemoryBarrier image_memory_barrier();

	VkRenderPassBeginInfo renderpass_begin_info(VkRenderPass renderPass, VkExtent2D extent, VkFramebuffer frameBuffer);
} // namespace vkinit