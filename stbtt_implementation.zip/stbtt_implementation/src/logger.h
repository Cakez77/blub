#pragma once

#include <cstdint>
#include <string>

namespace Cakez
{
    typedef enum LogLevel
    {
        LOG_LEVEL_FATAL = 0,
        LOG_LEVEL_ERROR = 1,
        LOG_LEVEL_WARN = 2,
        LOG_LEVEL_INFO = 3,
        LOG_LEVEL_TRACE = 4
    } LogLevel;

    class Logger
    {
    public:
        static void init();
        static void shutdown();

        template <typename... Args>
        static void log(const LogLevel logLevel, const std::string &message, Args... args)
        {
            //TODO: Remove string library
            char outMessage[32000];
            std::string formatted;
            TextColorBits textColor;

            switch (logLevel)
            {
            case LOG_LEVEL_FATAL:
                formatted = "FATAL: ";
                textColor = TEXT_COLOR_RED | TEXT_COLOR_INTENSITY;
                break;

            case LOG_LEVEL_ERROR:
                formatted = "ERROR: ";
                textColor = TEXT_COLOR_RED;
                break;

            case LOG_LEVEL_WARN:
                formatted = "WARN: ";
                textColor = TEXT_COLOR_RED | TEXT_COLOR_GREEN;
                break;

            case LOG_LEVEL_INFO:
                formatted = "INFO: ";
                textColor = TEXT_COLOR_GREEN | TEXT_COLOR_INTENSITY;
                break;

            case LOG_LEVEL_TRACE:
                formatted = "TRACE: ";
                textColor = TEXT_COLOR_BLUE | TEXT_COLOR_RED | TEXT_COLOR_GREEN;
                break;
            }

            formatted += message + "\n";

            sprintf(outMessage, formatted.c_str(), args...);
            console_write(outMessage, textColor);
        }

    private:
        // Taken from consoleapi2.h
        typedef enum TextColor
        {
            TEXT_COLOR_BLUE = 0x0001,      // text color contains blue.
            TEXT_COLOR_GREEN = 0x0002,     // text color contains green.
            TEXT_COLOR_RED = 0x0004,       // text color contains red.
            TEXT_COLOR_INTENSITY = 0x0008, // text color is intensified.
            BG_COLOR_BLUE = 0x0010,        // background color contains blue.
            BG_COLOR_GREEN = 0x0020,       // background color contains green.
            BG_COLOR_RED = 0x0040,         // background color contains red.
            BG_COLOR_INTENSITY = 0x0080    // background color is intensified.
        } TextColor;

        typedef uint32_t TextColorBits;

    private:
        static void console_write(const char *message, const TextColorBits color);
    };

#define CAKEZ_FATAL(message, ...) Logger::log(LOG_LEVEL_FATAL, message, __VA_ARGS__)
#define CAKEZ_ERROR(message, ...) Logger::log(LOG_LEVEL_ERROR, message, __VA_ARGS__)
#define CAKEZ_WARN(message, ...) Logger::log(LOG_LEVEL_WARN, message, __VA_ARGS__)
#define CAKEZ_INFO(message, ...) Logger::log(LOG_LEVEL_INFO, message, __VA_ARGS__)
#define CAKEZ_TRACE(message, ...) Logger::log(LOG_LEVEL_TRACE, message, __VA_ARGS__)

#ifdef DEBUG
#define CAKEZ_ASSERT(x, message, ...)          \
    {                                          \
        if (!(x))                              \
        {                                      \
            CAKEZ_ERROR(message, __VA_ARGS__); \
            __debugbreak();                    \
        }                                      \
    }
#else
#define CAKEZ_ASSERT(x, ...)
#endif
} // namespace Cakez
