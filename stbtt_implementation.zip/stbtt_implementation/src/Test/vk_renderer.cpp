#include <vulkan/vulkan.h>
#ifdef WINDOWS_BUILD
#include <windows.h>
#include <vulkan/vulkan_win32.h>
#endif

#include <iostream>

#define VK_CHECK(result)                                      \
    if (result != VK_SUCCESS)                                 \
    {                                                         \
        std::cout << "Vulkan Error: " << result << std::endl; \
        __debugbreak();                                       \
        return 0;                                             \
    }

#define ArraySize(arr) sizeof(arr) / sizeof(arr[0])

struct VkContext
{
    VkInstance instance;
    VkSurfaceKHR surface;
    VkPhysicalDevice gpu;
    VkDevice device;
    VkSurfaceFormatKHR surfaceFormat;
    VkSwapchainKHR swapchain;
    uint32_t swImageCount;
    VkImage swImages[5];
    VkImageView swImageViews[5];

    VkCommandPool commandPool;
    VkSemaphore aquireSemaphore;
    VkSemaphore submitSemaphore;

    VkDebugUtilsMessengerEXT debugMessenger;
    int graphicsIdx;
    VkQueue graphicsQueue;
};

static VKAPI_ATTR VkBool32 VKAPI_CALL vk_debug_callback(
    VkDebugUtilsMessageSeverityFlagBitsEXT msgSeverity,
    VkDebugUtilsMessageTypeFlagsEXT msgType,
    const VkDebugUtilsMessengerCallbackDataEXT *pCallbackData,
    void *pUserData)
{
    std::cout << pCallbackData->pMessage << std::endl;
    return false;
}

bool vk_init(VkContext *vkcontext, void *window)
{
    VkApplicationInfo appInfo = {};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "Pong";
    appInfo.pEngineName = "Ponggine";
    //TODO: Play around with this
    appInfo.apiVersion = VK_API_VERSION_1_2;

    char *extensions[] = {
#ifdef WINDOWS_BUILD
        VK_KHR_WIN32_SURFACE_EXTENSION_NAME,
#elif // Other OS
#endif
        VK_KHR_SURFACE_EXTENSION_NAME,
        VK_EXT_DEBUG_UTILS_EXTENSION_NAME,
    };

    char *layers[] = {
#ifdef WINDOWS_BUILD
        "VK_LAYER_KHRONOS_validation"
#endif
    };

    VkDebugUtilsMessengerCreateInfoEXT debugInfo = {};
    debugInfo.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
    debugInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT;
    debugInfo.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
    debugInfo.pfnUserCallback = vk_debug_callback;

    // Create Instance
    VkInstanceCreateInfo instanceInfo = {};
    instanceInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    instanceInfo.pApplicationInfo = &appInfo;
    instanceInfo.ppEnabledExtensionNames = extensions;
    instanceInfo.enabledExtensionCount = ArraySize(extensions);

    instanceInfo.ppEnabledLayerNames = layers;
    instanceInfo.enabledLayerCount = ArraySize(layers);
    instanceInfo.pNext = &debugInfo;
    VK_CHECK(vkCreateInstance(&instanceInfo, 0, &vkcontext->instance));

    auto vkCreateDebugUtilsMessengerEXT = (PFN_vkCreateDebugUtilsMessengerEXT)vkGetInstanceProcAddr(vkcontext->instance, "vkCreateDebugUtilsMessengerEXT");

    if (vkCreateDebugUtilsMessengerEXT)
    {
        VK_CHECK(vkCreateDebugUtilsMessengerEXT(vkcontext->instance, &debugInfo, 0, &vkcontext->debugMessenger));
    }
    else
    {
        return false;
    }

    // Create Surface
#ifdef WINDOWS_BUILD
    VkWin32SurfaceCreateInfoKHR surfaceInfo = {};
    surfaceInfo.sType = VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR;
    surfaceInfo.hwnd = (HWND)window;
    surfaceInfo.hinstance = GetModuleHandleA(0);
    VK_CHECK(vkCreateWin32SurfaceKHR(vkcontext->instance, &surfaceInfo, 0, &vkcontext->surface));
#endif

    // Create Physical Device
    {
        // Query all GPUS
        uint32_t gpuCount = 0;
        vkcontext->graphicsIdx = -1;
        // TODO: Suballocation from Main Allocation
        VkPhysicalDevice gpus[10];
        vkEnumeratePhysicalDevices(vkcontext->instance, &gpuCount, 0);
        vkEnumeratePhysicalDevices(vkcontext->instance, &gpuCount, gpus);

        // TODO: Evaluate GPUS to pick the best one
        for (uint32_t i = 0; i < gpuCount; i++)
        {
            // Store gpu on stack
            VkPhysicalDevice gpu = gpus[i];

            // Find queue family so we can do graphics.
            /**
         * in vulkan you have to create commands that tell the gpu
         * what it's supposed to do. like uploading a buffer from cpu to gpu memory
         * or presenting an image to the surface.
         * Queue families can only accept certain command types
         */
            {
                // Query Queue Family Properties
                uint32_t queueCount = 0;
                // TODO: Suballocation from Main Allocation
                VkQueueFamilyProperties queueProps[10];
                vkGetPhysicalDeviceQueueFamilyProperties(gpu, &queueCount, 0);
                vkGetPhysicalDeviceQueueFamilyProperties(gpu, &queueCount, queueProps);

                for (uint32_t i = 0; i < queueCount; i++)
                {
                    if (queueProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)
                    {
                        // Do we support presenting images to the surface we created using this index?
                        VkBool32 presentSupport;
                        VK_CHECK(vkGetPhysicalDeviceSurfaceSupportKHR(gpu, i, vkcontext->surface, &presentSupport));

                        if (presentSupport)
                        {
                            vkcontext->graphicsIdx = i;
                            vkcontext->gpu = gpu;
                            break;
                        }
                    }
                }
            }
        }

        // Check if we go a proper graphicsIdx
        if (vkcontext->graphicsIdx < 0)
        {
            return false;
        }
    }

    // Create Logical Device
    {
        // Queue Info, full priority
        float queuePriority = 1.0f;
        VkDeviceQueueCreateInfo queueInfo = {};
        queueInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        queueInfo.queueFamilyIndex = vkcontext->graphicsIdx;
        queueInfo.queueCount = 1;
        queueInfo.pQueuePriorities = &queuePriority;

        // Device Extensions
        char *extensions[]{
            VK_KHR_SWAPCHAIN_EXTENSION_NAME};

        // Create a logical device, used in almost every vulkan call
        VkDeviceCreateInfo deviceInfo = {};
        deviceInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
        deviceInfo.pQueueCreateInfos = &queueInfo;
        deviceInfo.queueCreateInfoCount = 1;
        deviceInfo.enabledExtensionCount = 1;
        deviceInfo.ppEnabledExtensionNames = extensions;

        VK_CHECK(vkCreateDevice(vkcontext->gpu, &deviceInfo, 0, &vkcontext->device));

        vkGetDeviceQueue(vkcontext->device, vkcontext->graphicsIdx, 0, &vkcontext->graphicsQueue);
    }

    // Create Swapchain
    {
        // Check which Image Format is being supported
        uint32_t formatCount = 0;
        VkSurfaceFormatKHR surfaceFormats[10];
        VK_CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(vkcontext->gpu, vkcontext->surface, &formatCount, 0));
        VK_CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(vkcontext->gpu, vkcontext->surface, &formatCount, surfaceFormats));

        for (uint32_t i = 0; i < formatCount; i++)
        {
            VkSurfaceFormatKHR format = surfaceFormats[i];
            if (format.format == VK_FORMAT_B8G8R8A8_SRGB)
            {
                vkcontext->surfaceFormat = format;
                break;
            }
        }

        // Get Surface capabilities, used to determine size and image count in the swapchain
        VkSurfaceCapabilitiesKHR surfaceCaps;
        VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(vkcontext->gpu, vkcontext->surface, &surfaceCaps));
        uint32_t imageCount = surfaceCaps.minImageCount + 1;
        imageCount = imageCount > surfaceCaps.maxImageCount ? imageCount - 1 : imageCount;

        VkSwapchainCreateInfoKHR scInfo = {};
        scInfo.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
        scInfo.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        scInfo.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        scInfo.imageFormat = vkcontext->surfaceFormat.format;
        scInfo.surface = vkcontext->surface;
        scInfo.minImageCount = imageCount;
        scInfo.imageArrayLayers = 1;
        scInfo.imageExtent = surfaceCaps.currentExtent;
        scInfo.preTransform = surfaceCaps.currentTransform;
        VK_CHECK(vkCreateSwapchainKHR(vkcontext->device, &scInfo, 0, &vkcontext->swapchain));

        // Get Swapchain Images
        VK_CHECK(vkGetSwapchainImagesKHR(vkcontext->device, vkcontext->swapchain,
                                         &vkcontext->swImageCount, 0));
        VK_CHECK(vkGetSwapchainImagesKHR(vkcontext->device, vkcontext->swapchain,
                                         &vkcontext->swImageCount, vkcontext->swImages));

        // Create Image Views for those Images
        VkImageViewCreateInfo viewInfo = {};
        viewInfo.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        viewInfo.format = vkcontext->surfaceFormat.format;
        viewInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        viewInfo.viewType = VK_IMAGE_VIEW_TYPE_2D;
        viewInfo.subresourceRange.layerCount = 1;
        viewInfo.subresourceRange.levelCount = 1;

        for (uint32_t i = 0; i < vkcontext->swImageCount; i++)
        {
            viewInfo.image = vkcontext->swImages[i];

            VkImageView *imageView = &vkcontext->swImageViews[i];

            VK_CHECK(vkCreateImageView(vkcontext->device, &viewInfo, 0, imageView));
        }
    }

    // Create Command Pool
    {
        VkCommandPoolCreateInfo poolInfo = {};
        poolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
        poolInfo.queueFamilyIndex = vkcontext->graphicsIdx;
        VK_CHECK(vkCreateCommandPool(vkcontext->device, &poolInfo, 0, &vkcontext->commandPool));
    }

    // Create GPU Syncronization Semaphores
    {
        VkSemaphoreCreateInfo semaphoreInfo = {};
        semaphoreInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
        VK_CHECK(vkCreateSemaphore(vkcontext->device, &semaphoreInfo, 0, &vkcontext->aquireSemaphore));
        VK_CHECK(vkCreateSemaphore(vkcontext->device, &semaphoreInfo, 0, &vkcontext->submitSemaphore));
    }

    return true;
}

bool vk_render(VkContext *vkcontext)
{
    uint32_t imgIdx;

    //This is waiting on the GPU side 
    VK_CHECK(vkAcquireNextImageKHR(vkcontext->device, vkcontext->swapchain, UINT64_MAX, vkcontext->aquireSemaphore, 0, &imgIdx));

    // Allocate A Command Buffer from the Command Pool
    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo allocInfo = {};
    allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    allocInfo.commandPool = vkcontext->commandPool;
    allocInfo.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(vkcontext->device, &allocInfo, &cmd));

    VkCommandBufferBeginInfo beginInfo = {};
    beginInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    VK_CHECK(vkBeginCommandBuffer(cmd, &beginInfo));

    // Render Loop Goes Here
    {
        VkClearColorValue color = {1, 0, 1, 1};
        VkImageSubresourceRange range = {};
        range.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        range.levelCount = 1;
        range.layerCount = 1;
        vkCmdClearColorImage(cmd, vkcontext->swImages[imgIdx], VK_IMAGE_LAYOUT_GENERAL, &color, 1, &range);
    }

    VK_CHECK(vkEndCommandBuffer(cmd));

    VkSubmitInfo submitInfo = {};
    submitInfo.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submitInfo.commandBufferCount = 1;
    submitInfo.pCommandBuffers = &cmd;
    submitInfo.pWaitSemaphores = &vkcontext->aquireSemaphore;
    submitInfo.waitSemaphoreCount = 1;
    submitInfo.pSignalSemaphores = &vkcontext->submitSemaphore;
    submitInfo.signalSemaphoreCount = 1;
    VK_CHECK(vkQueueSubmit(vkcontext->graphicsQueue, 1, &submitInfo, 0));

    VkPresentInfoKHR presentInfo = {};
    presentInfo.sType = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    presentInfo.pImageIndices = &imgIdx;
    presentInfo.pWaitSemaphores = &vkcontext->submitSemaphore;
    presentInfo.waitSemaphoreCount = 1;
    presentInfo.pSwapchains = &vkcontext->swapchain;
    presentInfo.swapchainCount = 1;
    VK_CHECK(vkQueuePresentKHR(vkcontext->graphicsQueue, &presentInfo));

    VK_CHECK(vkDeviceWaitIdle(vkcontext->device));

    return true;
}
