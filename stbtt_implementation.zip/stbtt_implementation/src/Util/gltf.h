#pragma once

#include "my_math.h"


#include <cstdint>
#include <vector>

namespace Cakez
{
    struct GLTF_Asset
    {
        std::string generator;
        std::string version;
    };

    struct GLTF_Particle
    {
        std::string name;
        uint32_t material;
        uint32_t rows;
        uint32_t cols;
        float maxLifetime;
        float emitRadius;
        uint32_t emitRate;
    };

    struct GLTF_Node //TODO: A node can have "camera", add later
    {
        uint32_t mesh;
        uint32_t paricle;
        std::string name;
        std::vector<uint32_t> children;
        bool hasMesh;
        bool hasParicles;
        bool hasTranslation;
        bool hasRotation;
        bool hasScale;
        bool hasMatrix;
        Vec3 translation;
        Quat rotation;
        Vec3 scale;
        Mat4 matrix;
    };

    struct GLTF_TextureInfo
    {
        uint32_t index;    // Index into accessor or textures directly
        uint32_t texCoord; // Index into accessor I believe
    };

    struct GLTF_MetallicRoughness // TODO: Emissive factor missing
    {
        GLTF_TextureInfo baseColorTexture;
        float metallicFactor;
        float roughnessFactor;
        Vec4 baseColorFactor; // TODO: Try this out in the shader
    };

    struct GLTF_Material
    {
        bool doubleSided;
        std::string alphaMode;
        float alphaCutoff = 0.5f;
        std::string name;
        Vec3 emissiveFactor;
        GLTF_MetallicRoughness pbrMetallicRoughness;
        GLTF_TextureInfo normalTexture;
    };

    struct GLTF_Scene
    {
        std::string name;
        std::vector<uint32_t> nodes; // index into nodes
    };

    typedef enum AttributeType
    {
        POSITION,
        TANGENT,
        TEXCOORD_0,
        NORMAL,
    } AttributeType;

    struct GLTF_Attribute
    {
        uint32_t index;
        AttributeType type;
    };

    struct GLTF_Primitive
    {
        uint32_t indices;
        std::vector<GLTF_Attribute> attributes;
        uint32_t material;
    };

    struct GLTF_Mesh
    {
        std::string name;
        std::vector<GLTF_Primitive> primitives;
    };

    struct GLTF_Image // TODO: I only need the URI, maybe discard the others
    {
        bool isNormal;
        std::string mimeType;
        std::string name;
        std::string uri;
    };

    struct GLTF_BufferView
    {
        uint32_t buffer;
        uint32_t byteLength;
        uint32_t byteOffset;
    };

    struct GLTF_Buffer
    {
        uint32_t byteLength;
        std::string uri;
    };

    struct GLTF_Accessor // TODO: Maybe one exception here, convert componentType into readable enums
    {
        uint32_t count;
        uint32_t bufferView;
        uint32_t byteOffset;
        uint16_t componentType;
        std::string type;
    };

    struct GLTF_Texture
    {
        uint32_t sampler;
        uint32_t source;
    };

    struct GLTF_Metadata
    {
        GLTF_Asset asset;
        uint32_t sceneIdx; // Scene index
        std::vector<GLTF_Scene> scenes;
        std::vector<GLTF_Node> nodes;
        std::vector<GLTF_Material> materials;
        std::vector<GLTF_Particle> particles;
        std::vector<GLTF_Mesh> meshes;
        std::vector<GLTF_Image> images;
        std::vector<GLTF_BufferView> bufferViews;
        std::vector<GLTF_Accessor> accessors;
        std::vector<GLTF_Texture> textures;
        std::vector<GLTF_Buffer> buffers;
    };
} // namespace Cakez
