#pragma once

#include "defines.h"

namespace Cakez
{
    enum KeyType
    {
        A_KEY,
        D_KEY,
        E_KEY,
        L_KEY,
        R_KEY,
        S_KEY,
        T_KEY,
        W_KEY,

        SHIFT_KEY,
        ESC_KEY,
        ENTER_KEY,

        LEFT_MOUSE_KEY,
        RIGHT_MOUSE_KEY,
        MIDDLE_MOUSE_KEY,

        KEY_COUNT
    };

    enum KeyState
    {
        S_KEYTATE_UP,
        S_KEYTATE_DOWN
    };

    struct Key
    {
        uint8_t halfTransitionCount;
        uint8_t keyState;
    };

    struct InputState
    {
        int clickMouseX;
        int clickMouseY;
        int oldMouseX;
        int oldMouseY;
        int mouseX;
        int mouseY;
        int relMouseX;
        int relMouseY;

        Key keys[KEY_COUNT];
    };

    bool key_pressed_this_frame(InputState *input, KeyType keyType);
    bool key_released_this_frame(InputState *input, KeyType keyType);

    bool key_is_down(InputState *input, KeyType keyType);
} // namespace Cakez