#pragma once

#include "Assets/assets.h"
#include "game_assets.h"
#include "ui.h"
#include "input.h"

namespace Cakez
{
    bool init_game(GameState *gameState, Assets *assets);
    bool update_game(
        GameState *gameState,
        UIState *ui,
        Assets *assets,
        InputState *input,
        float dt);

    Vec2 get_hitbox_origin(const Rect &rect);
    bool has_component(Entity *entity, Components component);
}