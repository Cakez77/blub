#pragma once

#include "Renderer/render_types.h"
#include "vk_context.h"

namespace Cakez
{
    Texture vk_create_texture(
        VkContext *vkcontext,
        const char *texturePath,
        TextureFormat = TEXTURE_FORMAT_BC1_RGBA_SRGB_BLOCK);
} // namespace Cakez
