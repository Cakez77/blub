#pragma once

//#############################################################
//              Layers of the Framework
//
// Below can acess anything that exists inside an include
// from above it, even internal functions. The Layers are as
// follows:
// - Math
// - Utility
// - Game Layer
// - Asset System
// - Renderer Layer
// - Platform Layer (this file)
//#############################################################

// Defines
#include "defines.h"

// Logger
#include "logger.h"

// Memory
#include "memory.h"

// Math
#include "my_math.cpp"

// Game layer
#include "Game/game_state.h"
#include "Game/game.cpp"

// Util
#include "Util/util.cpp"
#include "Util/dds_loader.cpp"

// Asset System layer
#include "Assets/assets.cpp"

// Renderer layer
#include "Renderer/Vulkan/vk_renderer.cpp"

// UI Layer
#include "ui.cpp"

// Platform layer
#include <windows.h>
#include <windowsx.h>

//TODO: Remove and use windows api
#include <chrono>

enum WindowsKeyCodes
{
    KEYCODE_SHIFT = 0x10,
    KEYCODE_ENTER = 0x0D,
    KEYCODE_ESC = 0x1B,

    KEYCODE_LBUTTON = 0x01,
    KEYCODE_RBUTTON = 0x02,
    KEYCODE_MBUTTON = 0x04,
    KEYCODE_RETURN = 0x0D,
    KEYCODE_A = 0x41,
    KEYCODE_B = 0x42,
    KEYCODE_C = 0x43,
    KEYCODE_D = 0x44,
    KEYCODE_E = 0x45,
    KEYCODE_F = 0x46,
    KEYCODE_G = 0x47,
    KEYCODE_H = 0x48,
    KEYCODE_I = 0x49,
    KEYCODE_J = 0x4A,
    KEYCODE_K = 0x4B,
    KEYCODE_L = 0x4C,
    KEYCODE_M = 0x4D,
    KEYCODE_N = 0x4E,
    KEYCODE_O = 0x4F,
    KEYCODE_P = 0x50,
    KEYCODE_Q = 0x51,
    KEYCODE_R = 0x52,
    KEYCODE_S = 0x53,
    KEYCODE_T = 0x54,
    KEYCODE_U = 0x55,
    KEYCODE_V = 0x56,
    KEYCODE_W = 0x57,
    KEYCODE_X = 0x58,
    KEYCODE_Y = 0x59,
    KEYCODE_Z = 0x5A
};

global_variable HWND window;
global_variable bool running = true;
global_variable bool minimized = false;

using namespace Cakez;

#include "input.cpp"
global_variable InputState input;

LRESULT CALLBACK window_callback(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_ERASEBKGND:
    {
        // Notify the OS that erasing will be handled by the application to prevent flicker
        return 1;
    }

    case WM_CLOSE:
    {
        running = false;
        return 0;
    }

    case WM_DESTROY:
    {
        PostQuitMessage(0);
        return 0;
    }

    case WM_SIZE:
    {
        if (wParam == SIZE_MINIMIZED)
        {
            minimized = true;
        }
        else
        {
            minimized = false;
        }

        break;
    }

    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
    case WM_KEYUP:
    case WM_SYSKEYUP:
    {
        KeyState newKeyState = (msg == WM_SYSKEYUP || msg == WM_KEYUP) ? S_KEYTATE_UP : S_KEYTATE_DOWN;
        KeyType keyType;

        switch ((int)wParam)
        {
        case KEYCODE_A: // A
        {
            keyType = A_KEY;
            break;
        }
        case KEYCODE_D: // D
        {
            keyType = D_KEY;
            break;
        }
        case KEYCODE_E: // E
        {
            keyType = E_KEY;
            break;
        }
        case KEYCODE_L: // L
        {
            keyType = L_KEY;
            break;
        }
        case KEYCODE_R: // R
        {
            keyType = R_KEY;
            break;
        }
        case KEYCODE_S: // S
        {
            keyType = S_KEY;
            break;
        }
        case KEYCODE_T: // T
        {
            keyType = T_KEY;
            break;
        }
        case KEYCODE_W: // W
        {
            keyType = W_KEY;
            break;
        }
        case KEYCODE_SHIFT: // Shift
        {
            keyType = SHIFT_KEY;
            break;
        }
        case KEYCODE_ESC: // ESC
        {
            keyType = ESC_KEY;
            break;
        }
        case KEYCODE_ENTER: // Enter
        {
            keyType = ENTER_KEY;
            break;
        }
        default:
            return DefWindowProcA(hwnd, msg, wParam, lParam);
        }

        // TODO: This cancels out repeats
        if (newKeyState == S_KEYTATE_UP && input.keys[keyType].keyState == S_KEYTATE_DOWN ||
            newKeyState == S_KEYTATE_DOWN && input.keys[keyType].keyState == S_KEYTATE_UP)
        {
            input.keys[keyType].halfTransitionCount++;
        }

        input.keys[keyType].keyState = newKeyState;

        break;
    }

    case WM_MOUSEMOVE:
    {
        input.oldMouseX = input.mouseX;
        input.oldMouseY = input.mouseY;
        input.mouseX = GET_X_LPARAM(lParam);
        input.mouseY = GET_Y_LPARAM(lParam);
        input.relMouseX = input.mouseX - input.oldMouseX;
        input.relMouseY = input.mouseY - input.oldMouseY;
        return 1;
    }

    case WM_MOUSEWHEEL:
    {
        //TODO: Implement
        int delta = GET_WHEEL_DELTA_WPARAM(wParam);
        if (delta != 0)
        {
            delta = (delta < 0) ? -1 : 1;
        }
        break;
    }

    case WM_LBUTTONDOWN:
    case WM_RBUTTONDOWN:
    case WM_MBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONUP:
    case WM_MBUTTONUP:
    {
        KeyType mouseKey =
            (msg == WM_RBUTTONDOWN || (msg == WM_RBUTTONUP)
                 ? RIGHT_MOUSE_KEY
             : (msg == WM_LBUTTONDOWN) || (msg == WM_LBUTTONUP)
                 ? LEFT_MOUSE_KEY
                 : MIDDLE_MOUSE_KEY);

        KeyState newKeyState = (msg == WM_RBUTTONDOWN || msg == WM_LBUTTONDOWN || msg == WM_MBUTTONDOWN)
                                   ? S_KEYTATE_DOWN
                                   : S_KEYTATE_UP;

        input.clickMouseX = GET_X_LPARAM(lParam);
        input.clickMouseY = GET_Y_LPARAM(lParam);

        if (newKeyState == S_KEYTATE_UP && input.keys[mouseKey].keyState == S_KEYTATE_DOWN ||
            newKeyState == S_KEYTATE_DOWN && input.keys[mouseKey].keyState == S_KEYTATE_UP)
        {
            input.keys[mouseKey].halfTransitionCount++;
        }

        input.keys[mouseKey].keyState = newKeyState;

        return 1;
    }
    }

    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

internal bool platform_create_window(int width, int height, char *title)
{
    HINSTANCE instance = GetModuleHandleA(0);

    // Setup and register window class
    HICON icon = LoadIcon(instance, IDI_APPLICATION);
    WNDCLASS wc = {};
    wc.lpfnWndProc = window_callback;
    wc.hInstance = instance;
    wc.hIcon = icon;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW); // NULL; => Manage the cursor manually
    wc.lpszClassName = "cakez_window_class";

    if (!RegisterClassA(&wc))
    {
        MessageBoxA(0, "Window registration failed", "Error", MB_ICONEXCLAMATION | MB_OK);
        return false;
    }

    // Create window
    uint32_t client_x = 100;
    uint32_t client_y = 100;
    uint32_t client_width = width;
    uint32_t client_height = height;

    uint32_t window_x = client_x;
    uint32_t window_y = client_y;
    uint32_t window_width = client_width;
    uint32_t window_height = client_height;

    uint32_t window_style =
        WS_OVERLAPPED |
        WS_SYSMENU |
        WS_CAPTION |
        WS_THICKFRAME |
        WS_MINIMIZEBOX |
        WS_MAXIMIZEBOX;

    uint32_t window_ex_style = WS_EX_APPWINDOW;

    // Obtain the size of the border
    RECT border_rect = {0, 0, 0, 0};
    AdjustWindowRectEx(
        &border_rect,
        (DWORD)window_style,
        0,
        (DWORD)window_ex_style);

    window_x += border_rect.left;
    window_y += border_rect.top;

    window_width += border_rect.right - border_rect.left;
    window_height += border_rect.bottom - border_rect.top;

    window = CreateWindowExA(
        (DWORD)window_ex_style, "cakez_window_class", title,
        (DWORD)window_style, window_x, window_y, window_width, window_height,
        0, 0, instance, 0);

    if (window == 0)
    {
        MessageBoxA(NULL, "Window creation failed!", "Error", MB_ICONEXCLAMATION | MB_OK);
        return false;
    }

    // Show the window
    ShowWindow(window, SW_SHOW);

    return true;
}

internal void platform_update_window()
{
    MSG msg;

    while (PeekMessageA(&msg, window, 0, 0, PM_REMOVE))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
}

// Entry point
int main()
{
    GameMemory gameMemory = {};
    gameMemory.memory = (uint8_t *)malloc(MB(256));
    gameMemory.memorySizeInBytes = MB(256);

    //TODO: Actually write a sound mixer
    // PlaySound(TEXT("gothic3_geldern_night.wav"), 0, SND_LOOP | SND_FILENAME | SND_ASYNC);

    //TODO: Watch Handmade hero on how he creates a window
    // Create the window
    {
        // Using 16/9 Aspect ration FIXED!
        platform_create_window(1600, 900, "Cakez");
    }
    UIState *ui = (UIState *)allocate_memory(&gameMemory, sizeof(UIState));

    // Init the renderer
    VkContext *vkcontext = (VkContext *)allocate_memory(&gameMemory, sizeof(VkContext));
    vk_init(vkcontext, &window, false);

    // Init the asset system
    Assets *assets = (Assets *)allocate_memory(&gameMemory, sizeof(Assets));
    load_assets(&gameMemory, assets, vkcontext);

    // Init the game
    uint32_t gameStateSize = sizeof(GameState);
    GameState *gameState = (GameState *)allocate_memory(&gameMemory, sizeof(GameState));
    init_game(gameState, assets);

    std::chrono::steady_clock::time_point lastTimePoint;
    float dt = 0;

    // Main loop
    while (running)
    {
        // Clear the transitionCount for every key
        {
            for (uint32_t i = 0; i < KEY_COUNT; i++)
            {
                input.keys[i].halfTransitionCount = 0;
            }
        }

        // Update the window
        //TODO: Find a better place for this
        input.relMouseX = 0;
        input.relMouseY = 0;
        platform_update_window();

        if (key_pressed_this_frame(&input, A_KEY))
        {
            CAKEZ_TRACE("A Key was pressed");
        }

        if (!minimized)
        {
            update_ui(ui, &input);
            update_game(gameState, ui, assets, &input, dt);
            vk_render(vkcontext, ui, gameState, assets);
        }

        // Take the time it took to update the program
        auto now = std::chrono::high_resolution_clock::now();
        dt = std::chrono::duration<double, std::milli>(now - lastTimePoint).count();

        // dt *= 20.0f;

        // Lock dt to 50ms
        if (dt > 50.0f)
            dt = 50.0f;
        lastTimePoint = now;

        if (dt > 5.0f)
        {
            CAKEZ_TRACE("%f", dt);
        }
    }

    return 0;
}

//#############################################################
//          Implementations from exposed functions
//#############################################################
void Logger::console_write(const char *message, TextColorBits color)
{
    HANDLE console_handle = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(console_handle, color);

    OutputDebugStringA(message);
    uint32_t length = strlen(message);
    LPDWORD number_written = 0;
    WriteConsoleA(console_handle, message, length, number_written, 0);
}

bool platform_file_exists(const char *path)
{
    DWORD attributes = GetFileAttributes(path);

    return (attributes != INVALID_FILE_ATTRIBUTES &&
            !(attributes & FILE_ATTRIBUTE_DIRECTORY));
}

char *platform_read_file(const char *path, uint32_t &length)
{
    char *buffer = 0;
    HANDLE file = CreateFile(
        path,
        GENERIC_READ,
        FILE_SHARE_READ,
        0,
        OPEN_EXISTING,
        0, 0);

    if (file != INVALID_HANDLE_VALUE)
    {
        LARGE_INTEGER fileSize;
        if (GetFileSizeEx(file, &fileSize))
        {
            length = (uint32_t)fileSize.QuadPart;

            //TODO: Allocate memory from gameMemory
            buffer = new char[length];

            DWORD bytesRead;
            if (ReadFile(file, buffer, length, &bytesRead, 0) &&
                length == bytesRead)
            {
                //TODO: What can I do here?
            }
            else
            {
                CAKEZ_WARN("Failed reading file %s", path);
                delete buffer;
                buffer = 0;
            }
        }
        else
        {
            CAKEZ_WARN("Failed getting size of file %s", path);
        }

        CloseHandle(file);
    }
    else
    {
        CAKEZ_WARN("Failed opening file %s", path);
    }

    return buffer;
}

unsigned long platform_write_file(
    const char *path,
    const char *buffer,
    const uint32_t size,
    bool overwrite)
{
    DWORD bytesWritten = 0;

    HANDLE file = CreateFile(
        path,
        overwrite ? GENERIC_WRITE : FILE_APPEND_DATA,
        FILE_SHARE_WRITE,
        0,
        OPEN_ALWAYS,
        0, 0);

    if (file != INVALID_HANDLE_VALUE)
    {
        if (!overwrite)
        {
            DWORD result = SetFilePointer(file, 0, 0, FILE_END);
            if (result == INVALID_SET_FILE_POINTER)
            {
                CAKEZ_WARN("Failed to set file pointer to the end");
            }
        }

        BOOL result = WriteFile(file, buffer, size, &bytesWritten, 0);
        if (result && size == bytesWritten)
        {
            //Success
        }
        else
        {
            CAKEZ_WARN("Failed writing file %s", path);
        }

        CloseHandle(file);
    }
    else
    {
        CAKEZ_WARN("Failed opening file %s", path);
    }

    return bytesWritten;
}

long long platform_last_edit_timestamp(const char *path)
{
    long long time;
    HANDLE file = CreateFile(path, GENERIC_READ, FILE_SHARE_WRITE,
                             0, OPEN_EXISTING, 0, 0);

    if (file != INVALID_HANDLE_VALUE)
    {
        FILETIME writeTime;
        if (GetFileTime(file, 0, 0, &writeTime))
        {
            ULARGE_INTEGER tmp = {writeTime.dwLowDateTime, writeTime.dwHighDateTime};
            time = tmp.QuadPart;
            CloseHandle(file);
        }
        else
        {
            CAKEZ_WARN("Failed getting file time of file %s ", path);
            return 0;
        }
    }
    else
    {
        CAKEZ_WARN("Failed opening file %s", path);
        return 0;
    }

    return time;
}

void platform_get_window_size(uint32_t *windowWidth, uint32_t *windowHeight)
{
    RECT r;
    GetClientRect(window, &r);

    *windowWidth = r.right - r.left;
    *windowHeight = r.bottom - r.top;
}