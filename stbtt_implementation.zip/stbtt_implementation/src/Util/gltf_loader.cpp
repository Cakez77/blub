#include "gltf_loader.h"

#include "Util/json_parser.h"
#include "Util/util.h"
#include "logger.h"

namespace Cakez
{
	namespace Util
	{
		internal bool str_comp(const char *buffer, const Util::Token *t, const unsigned int i, const char *string)
		{
			unsigned int start = t[i].start;
			unsigned int end = t[i].end;
			return strlen(string) == end - start ? strncmp(&buffer[start], string, end - start) == 0 ? true : false : false;
		}

		static float *parse_float_array(const char *buffer, const Util::Token *t, unsigned int &i, const unsigned int length)
		{
			float *result = new float[length];
			for (uint16_t j = 0; j <= length; j++)
			{
				result[j] = atof(&buffer[t[i + j].start]);
			}
			i += length - 1;
			return result;
		}

		static const char *parse_string(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			//TODO: Test if this actually works
			return &buffer[t[i].start];
			// return std::string(&buffer[t[i].start], t[i].end - t[i].start);
		}

		static unsigned int parse_int(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			return atoi(&buffer[t[i].start]);
		}

		static float parse_float(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			return atof(&buffer[t[i].start]);
		}

		static void parse_gltf_scenes(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Scene scene;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "scenes, array should be followed by an object");
			unsigned int sceneEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (sceneEnd < t[i].end)
						metadata.scenes.push_back(scene);
					scene = {};
					sceneEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "name"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "scenes, name should be followed by a string");
					scene.name = parse_string(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "nodes"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "scenes, nodes should be followed by an array");
					CAKEZ_ASSERT(t[i + 1].type == Util::TOKEN_TYPE_PRIMITIVE, "scene, nodes array should contain primitives");
					for (; t[i + 1].type == Util::TOKEN_TYPE_PRIMITIVE; i++)
					{
						scene.nodes.push_back(atoi(&buffer[t[i + 1].start]));
					}
				}
			}
			metadata.scenes.push_back(scene);
			i--;
		}

		static void parse_gltf_nodes(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Node node;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "nodes, array should be followed by an object");
			unsigned int nodeEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (nodeEnd < t[i].end)
						metadata.nodes.push_back(node);
					node = {};
					nodeEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "translation"))
				{
					CAKEZ_ASSERT(t[i + 1].type == Util::TOKEN_TYPE_ARRAY, "nodes, translation should be followed by an array");
					CAKEZ_ASSERT(t[i + 2].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, translation array should be followed by a primitive");
					i += 2; // array, first entry
					node.translation = create_vec3(parse_float_array(buffer, t, i, 3));
					node.hasTranslation = true;
				}

				if (str_comp(buffer, t, i, "rotation"))
				{
					CAKEZ_ASSERT(t[i + 1].type == Util::TOKEN_TYPE_ARRAY, "nodes, rotation should be followed by an array");
					CAKEZ_ASSERT(t[i + 2].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, rotation array should be followed by a primitive");
					i += 2; // array, first entry
					node.rotation = create_quat(parse_float_array(buffer, t, i, 4));
					node.hasRotation = true;
				}

				if (str_comp(buffer, t, i, "scale"))
				{
					CAKEZ_ASSERT(t[i + 1].type == Util::TOKEN_TYPE_ARRAY, "nodes, scale should be followed by an array");
					CAKEZ_ASSERT(t[i + 2].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, scale array should be followed by a primitive");
					i += 2;
					node.scale = create_vec3(parse_float_array(buffer, t, i, 3));
					node.hasScale = true;
				}

				if (str_comp(buffer, t, i, "matrix"))
				{
					CAKEZ_ASSERT(t[i + 1].type == Util::TOKEN_TYPE_ARRAY, "nodes, matrix should be followed by an array");
					CAKEZ_ASSERT(t[i + 2].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, matrix array should be followed by a primitive");
					i += 2;
					node.matrix = create_mat4(parse_float_array(buffer, t, i, 16));
					node.hasMatrix = true;
				}

				if (str_comp(buffer, t, i, "name"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "nodes, name should be followed by a string");
					node.name = parse_string(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "mesh"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, mesh should be followed by a primitive");
					node.mesh = parse_int(buffer, t, i);
					node.hasMesh = true;
				}

				if (str_comp(buffer, t, i, "particle"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, particle should be followed by a primitive");
					node.paricle = parse_int(buffer, t, i);
					node.hasParicles = true;
				}

				if (str_comp(buffer, t, i, "children"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "nodes, children should be followed by an array");
					CAKEZ_ASSERT(t[i + 1].type == Util::TOKEN_TYPE_PRIMITIVE, "nodes, children array should contain primitives");
					for (; t[i + 1].type == Util::TOKEN_TYPE_PRIMITIVE; i++)
					{
						node.children.push_back(atoi(&buffer[t[i + 1].start]));
					}
				}
			}
			metadata.nodes.push_back(node);
			i--;
		}

		static GLTF_TextureInfo parse_texture_info(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			GLTF_TextureInfo textureInfo = {};
			unsigned int objectEnd = t[i].end;

			for (; t[i].end <= objectEnd; i++)
			{
				if (str_comp(buffer, t, i, "index"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "materials, texture, index should be followed by a primitive");
					textureInfo.index = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "texCoord"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "materials, texture, texCoord should be followed by a primitive");
					textureInfo.texCoord = parse_int(buffer, t, i);
				}
			}
			i--;
			return textureInfo;
		}

		static GLTF_MetallicRoughness parse_metallic_roughness(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			GLTF_MetallicRoughness roughness = {};
			unsigned int objectEnd = t[i].end;

			for (; t[i].end <= objectEnd; i++)
			{
				if (str_comp(buffer, t, i, "roughnessFactor"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "roughnessFactor should be followed by a primitive");
					roughness.roughnessFactor = parse_float(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "baseColorTexture"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "baseColorTexture should be followed by an object");
					roughness.baseColorTexture = parse_texture_info(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "metallicFactor"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "metallicFactor should be followed by a primitive");
					roughness.metallicFactor = parse_float(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "baseColorFactor"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "baseColorFactor should be followed by an array");
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "baseColorFactor, array should be followed by a primitive");
					roughness.baseColorFactor = create_vec4(parse_float_array(buffer, t, i, 4));
				}
			}
			i--;
			return roughness;
		}

		static void parse_gltf_materials(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Material material;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "materials, array should be followed by an object");
			unsigned int materialEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (materialEnd < t[i].end)
						metadata.materials.push_back(material);
					material = {};
					materialEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "normalTexture"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "materials, texture should be followed by an object");
					material.normalTexture = parse_texture_info(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "name"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "materials, name should be followed by a string");
					material.name = parse_string(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "doubleSided"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "materials, doubleSided should be followed by a primitive");
					material.doubleSided = true;
				}

				if (str_comp(buffer, t, i, "alphaMode"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "materials, alphaMode should be followed by a string");
					material.alphaMode = parse_string(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "alphaCutoff"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "materials, alphaCutoff should be followed by a primitive");
					material.alphaCutoff = parse_float(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "pbrMetallicRoughness"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "materials, pbrMetallicRoughness should be followed by an object");
					material.pbrMetallicRoughness = parse_metallic_roughness(buffer, t, i);
				}
			}
			metadata.materials.push_back(material);
			i--;
		}

		static void parse_gltf_particles(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Particle particle;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "particles, array should be followed by an object");
			unsigned int particlesEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (particlesEnd < t[i].end)
						metadata.particles.push_back(particle);
					particle = {};
					particlesEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "material"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "particles, material should be followed by a primitive");
					particle.material = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "rows"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "particles, rows should be followed by a primitive");
					particle.rows = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "cols"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "particles, cols should be followed by a primitive");
					particle.cols = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "maxLifetime"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "particles, maxLifetime should be followed by a primitive");
					particle.maxLifetime = parse_float(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "emitRadius"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "particles, emitRadius should be followed by a primitive");
					particle.emitRadius = parse_float(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "emitRate"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "particles, emitRate should be followed by a primitive");
					particle.emitRate = parse_int(buffer, t, i);
				}
			}
			metadata.particles.push_back(particle);
			i--;
		}

		static std::vector<GLTF_Attribute> parse_mesh_attributes(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			GLTF_Attribute attribute;
			std::vector<GLTF_Attribute> attributes;

			unsigned int objectEnd = t[i].end;

			for (; t[i].end <= objectEnd; i++)
			{
				if (str_comp(buffer, t, i, "POSITION"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "attributes, POSITION should be followed by a primitive");
					attribute = {parse_int(buffer, t, i), POSITION};
					attributes.push_back(attribute);
				}

				if (str_comp(buffer, t, i, "TANGENT"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "attributes, TANGENT should be followed by a primitive");
					attribute = {parse_int(buffer, t, i), TANGENT};
					attributes.push_back(attribute);
				}

				if (str_comp(buffer, t, i, "TEXCOORD_0"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "attributes, TEXTCOORD_0 should be followed by a primitive");
					attribute = {parse_int(buffer, t, i), TEXCOORD_0};
					attributes.push_back(attribute);
				}

				if (str_comp(buffer, t, i, "NORMAL"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "attributes, NORMAL should be followed by a primitive");
					attribute = {parse_int(buffer, t, i), NORMAL};
					attributes.push_back(attribute);
				}
			}
			i--; // next foor loop will increment again
			return attributes;
		}

		static std::vector<GLTF_Primitive> parse_primitives(const char *buffer, const Util::Token *t, unsigned int &i)
		{
			std::vector<GLTF_Primitive> primitives;
			GLTF_Primitive primitive;

			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "primitives, array should be followed by an object");
			unsigned int primitiveEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (primitiveEnd < t[i].end)
						primitives.push_back(primitive);
					primitive = {};
					primitiveEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "indices"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "primitives, indices should be followed by a primitive");
					primitive.indices = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "attributes"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "primitives, attributes should be followed by an object");
					primitive.attributes = parse_mesh_attributes(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "material"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "primitives, material should be followed by a primitive");
					primitive.material = parse_int(buffer, t, i);
				}
			}
			i--;
			primitives.push_back(primitive);
			return primitives;
		}

		static void parse_gltf_meshes(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Mesh mesh;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "meshes, array should be followed by an object");
			unsigned int meshEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (meshEnd < t[i].end)
						metadata.meshes.push_back(mesh);
					mesh = {};
					meshEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "name"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "meshes, name should be followed by a string");
					mesh.name = parse_string(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "primitives"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "meshes, primitives should be followed by an array");
					mesh.primitives = parse_primitives(buffer, t, i);
				}
			}
			metadata.meshes.push_back(mesh);
			i--; // go back one step
		}

		static void parse_gltf_textures(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Texture texture;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "textures, array should be followed by an object");
			unsigned int textureEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (textureEnd < t[i].end)
						metadata.textures.push_back(texture);
					texture = {};
					textureEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "source"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "textures, source should be followed by a primitive");
					texture.source = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "sampler"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "textures, sampler should be followed by a primitive");
					texture.sampler = parse_int(buffer, t, i);
				}
			}
			metadata.textures.push_back(texture);
			i--; // go back one step
		}

		static void parse_gltf_images(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Image image;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "images, array should be followed by an object");
			unsigned int imageEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (imageEnd < t[i].end)
						metadata.images.push_back(image);
					image = {};
					imageEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "uri"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "images, uri should be followed by a string");
					image.uri = parse_string(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "name"))
				{
					//Implement, if needed
				}

				if (str_comp(buffer, t, i, "bufferView"))
				{
					//Implement, if needed
				}

				if (str_comp(buffer, t, i, "mimeType"))
				{
					//Implement, if needed
				}
			}
			metadata.images.push_back(image);
			i--; // go back one step
		}

		static void parse_gltf_accessors(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Accessor accessor;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "accessors, array should be followed by an object");
			unsigned int accEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (accEnd < t[i].end)
						metadata.accessors.push_back(accessor);
					accessor = {};
					accEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "byteOffset"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "accessors, byteOffset should be followed by a primitive");
					accessor.byteOffset = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "bufferView"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "accessors, bufferView should be followed by a primitive");
					accessor.bufferView = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "componentType"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "accessors, componentType should be followed by a primitive");
					accessor.componentType = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "count"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "accessors, count should be followed by a primitive");
					accessor.count = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "type"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "accessors, type should be followed by a string");
					accessor.type = parse_string(buffer, t, i);
				}
			}
			metadata.accessors.push_back(accessor);
			i--; // go back one step
		}

		static void parse_gltf_buffer_views(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_BufferView bufferView;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "accessors, array should be followed by an object");
			unsigned int bufferViewEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (bufferViewEnd < t[i].end)
						metadata.bufferViews.push_back(bufferView);
					bufferView = {};
					bufferViewEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "buffer"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "bufferViews, buffer should be followed by a primitive");
					bufferView.buffer = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "byteLength"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "bufferViews, byteLength should be followed by a primitive");
					bufferView.byteLength = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "byteOffset"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "bufferViews, byteOffset should be followed by a primitive");
					bufferView.byteOffset = parse_int(buffer, t, i);
				}
			}
			metadata.bufferViews.push_back(bufferView);
			i--; // go back one step
		}

		static void parse_gltf_buffers(const char *buffer, GLTF_Metadata &metadata, const Util::Token *t, unsigned int &i)
		{
			GLTF_Buffer gBuffer;
			unsigned int arrayEnd = t[i].end;
			i++;
			CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_OBJECT, "buffers, array should be followed by an object");
			unsigned int bufferEnd = t[i].end;

			for (; t[i].end <= arrayEnd; i++)
			{
				if (t[i].type == Util::TOKEN_TYPE_OBJECT)
				{
					if (bufferEnd < t[i].end)
						metadata.buffers.push_back(gBuffer);
					gBuffer = {};
					bufferEnd = t[i].end;
				}

				if (str_comp(buffer, t, i, "byteLength"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "buffers, byteLength should be followed by a primitive");
					gBuffer.byteLength = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "uri"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_STRING, "buffers, uri should be followed by a string");
					gBuffer.uri = parse_string(buffer, t, i);
				}
			}
			metadata.buffers.push_back(gBuffer);
			i--; // go back one step
		}

		GLTF_Metadata load_gltf_scene(const char *scenePath)
		{
			uint32_t fileSize;
			const char *content = Util::read_file(scenePath, fileSize);

			std::vector<Util::Token> tokens;
			Util::parse_json(content, fileSize, tokens);

			const char *buffer = content;
			const Util::Token *t = &tokens[0];
			GLTF_Metadata metadata = {};

			for (unsigned int i = 0; i < tokens.size(); i++)
			{

				if (str_comp(buffer, t, i, "scene"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_PRIMITIVE, "scene should be followed by a Primitive");
					metadata.sceneIdx = parse_int(buffer, t, i);
				}

				if (str_comp(buffer, t, i, "scenes"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "scenes should be followed by an array");
					parse_gltf_scenes(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "nodes"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "nodes should be followed by an array");
					parse_gltf_nodes(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "materials"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "materials should be followed by an array");
					parse_gltf_materials(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "particles"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "particles should be followed by an array");
					parse_gltf_particles(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "meshes"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "meshes should be followed by an array");
					parse_gltf_meshes(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "textures"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "textures should be followed by an array");
					parse_gltf_textures(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "images"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "images should be followed by an array");
					parse_gltf_images(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "accessors"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "accessors should be followed by an array");
					parse_gltf_accessors(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "bufferViews"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "bufferViews should be followed by an array");
					parse_gltf_buffer_views(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "buffers"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "buffers should be followed by an array");
					parse_gltf_buffers(buffer, metadata, t, i);
				}
			}

			return metadata;
		}

		GLTF_Metadata load_gltf_mesh(const char *meshPath)
		{
			uint32_t fileSize;
			const char *content = Util::read_file(meshPath, fileSize);

			std::vector<Util::Token> tokens;
			parse_json(content, fileSize, tokens);

			const char *buffer = content;
			const Util::Token *t = &tokens[0];
			GLTF_Metadata metadata = {};

			for (unsigned int i = 0; i < tokens.size(); i++)
			{
				if (str_comp(buffer, t, i, "meshes"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "meshes should be followed by an array");
					parse_gltf_meshes(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "accessors"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "accessors should be followed by an array");
					parse_gltf_accessors(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "bufferViews"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "bufferViews should be followed by an array");
					parse_gltf_buffer_views(buffer, metadata, t, i);
				}

				if (str_comp(buffer, t, i, "buffers"))
				{
					i++;
					CAKEZ_ASSERT(t[i].type == Util::TOKEN_TYPE_ARRAY, "buffers should be followed by an array");
					parse_gltf_buffers(buffer, metadata, t, i);
				}
			}

			return metadata;
		}

		void load_mesh(
			char *meshPath,
			std::vector<Vertex> &vertices,
			std::vector<uint32_t> &indices)
		{
			CAKEZ_ASSERT(meshPath, "No meshPath provided");
			CAKEZ_ASSERT(Util::count_char('.', meshPath) == 1,
						 "No dots '.' allowed in meshPath %s", meshPath);
			GLTF_Metadata metadata = load_gltf_mesh(meshPath);

			// The vertex data is in a file with the extension .bin, the meshPath
			// contains everything we need except the extension .gltf,
			// we have to sptrip this extension and replace it.
			char *bufferPath = meshPath;

			while (meshPath++)
			{
				if (*meshPath == '.')
				{
					meshPath[1] = 'b';
					meshPath[2] = 'i';
					meshPath[3] = 'n';
					meshPath[4] = 0;
				}
			}

			uint32_t bufferSize;
			char *buffer = Util::read_file(bufferPath, bufferSize);

			for (const auto &gltfMesh : metadata.meshes)
			{

				for (const auto &primitive : gltfMesh.primitives)
				{
					uint32_t vertexStart = static_cast<uint32_t>(vertices.size());
					uint32_t indexOffset = static_cast<uint32_t>(indices.size());

					// Loading indices from the buffer
					{
						GLTF_Accessor acc = metadata.accessors[primitive.indices];
						GLTF_BufferView bView = metadata.bufferViews[acc.bufferView];

						//TODO: Imporve, load directly from the buffer, don't create an extra buffer
						switch (acc.componentType)
						{
						case 5125:
						{
							// m.indexCount = acc.count;

							uint32_t *buf = (uint32_t *)&(buffer[acc.byteOffset + bView.byteOffset]);
							for (size_t i = 0; i < acc.count; i++)
							{
								indices.push_back(buf[i] + vertexStart);
							}
							break;
						}
						case 5123:
						{
							// m.indexCount = acc.count;

							uint16_t *buf = (uint16_t *)&(buffer[acc.byteOffset + bView.byteOffset]);
							for (size_t i = 0; i < acc.count; i++)
							{
								indices.push_back(buf[i] + vertexStart);
							}
							break;
						}
						case 5121:
						{
							// m.indexCount = acc.count;

							const unsigned char *uByteBuffer = (const unsigned char *)&buffer[acc.byteOffset + bView.byteOffset];
							for (size_t i = 0; i < acc.count; i++)
							{
								indices.push_back(vertexStart + uByteBuffer[i]);
							}
							break;
						}
						default:
							CAKEZ_ASSERT(false, "Index component type %d not supported!", acc.componentType);
						}
					}

					// Loading vertices from the buffer
					{
						uint32_t vertexCount = 0;

						const float *posBuffer = nullptr;
						const float *norBuffer = nullptr;
						const float *texBuffer = nullptr;
						const float *tanBuffer = nullptr;

						for (const auto &attribute : primitive.attributes)
						{
							GLTF_Accessor acc = metadata.accessors[attribute.index];
							GLTF_BufferView bView = metadata.bufferViews[acc.bufferView];

							switch (attribute.type)
							{
							case POSITION:
								posBuffer = reinterpret_cast<const float *>((&buffer[acc.byteOffset + bView.byteOffset]));
								vertexCount = acc.count;
								break;
							case NORMAL:
								norBuffer = reinterpret_cast<const float *>(&buffer[acc.byteOffset + bView.byteOffset]);
								break;
							case TEXCOORD_0:
								texBuffer = reinterpret_cast<const float *>(&buffer[acc.byteOffset + bView.byteOffset]);
								break;
								break;
							case TANGENT:
								tanBuffer = reinterpret_cast<const float *>(&buffer[acc.byteOffset + bView.byteOffset]);
								break;
							}
						}

						for (size_t i = 0; i < vertexCount; i++)
						{
							Vertex v{};
							v.vx = posBuffer[(i * 3) + 0];
							v.vy = posBuffer[(i * 3) + 1];
							v.vz = posBuffer[(i * 3) + 2];

							v.nx = norBuffer[(i * 3) + 0];
							v.ny = norBuffer[(i * 3) + 1];
							v.nz = norBuffer[(i * 3) + 2];

							v.ux = texBuffer[(i * 2) + 0];
							v.uy = texBuffer[(i * 2) + 1];

							vertices.push_back(v);
						}
					}
				}
			}
		}

	} // namespace Util
} // namespace Cakez