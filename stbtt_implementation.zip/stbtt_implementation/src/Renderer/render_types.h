#ifdef CAKEZGINE

#pragma once
#include "defines.h"
#include "my_math.h"
#include "shader_util.h"

#define MAT4 Cakez::Mat4
#define VEC4 Cakez::Vec4
#define VEC3 Cakez::Vec3
#define VEC2 Cakez::Vec2

namespace Cakez
{
    // taken from Vulkan vkFormat
    typedef enum TextureFormat
    {
        TEXTURE_FORMAT_R8_UNORM = 9,
        TEXTURE_FORMAT_R8G8B8A8_UNORM = 37,
        TEXTURE_FORMAT_BC1_RGBA_SRGB_BLOCK = 134,
    } TextureFormat;

    struct Texture
    {
        const char *name;
        uint32_t imageIdx;
    };

    struct SamplerToTexture
    {
        //TODO: Use an ID instead of a name?
        const char *samplerName;
        Texture texture;
    };

    enum MaterialType
    {
        MATERIAL_TYPE_FLAT,
        MATERIAL_TYPE_TRANSPARENT
    };

    struct Material
    {
        //TODO: Remove
        uint32_t descriptorIdx;
        VEC4 color;
        uint32_t assetID;
        bool colorBlending;

        bool operator==(Material *other)
        {
            return color == other->color && assetID == other->assetID && colorBlending == other->colorBlending;
        }
    };

    struct Descriptor{
        // Vulkan Stuff, desc sets, desc layouts, programIdx, 
        
        Material* mat;
    };

    // use desc to create a draw command

    struct Mesh
    {
        uint32_t vertexOffset;
        uint32_t indexOffset;
        uint32_t indexCount;
    };

    // NOTE: Same structure as DDSMipLevel, this is on purpose
    struct MipMapLevel
    {
        uint32_t width;
        uint32_t height;
        uint32_t byteOffset;
    };

} // namespace Cakez
#else

#define MAT4 mat4
#define VEC4 vec4
#define VEC3 vec3
#define VEC2 vec2
#define uint32_t int
#define constexpr const

#endif

constexpr int MAX_ANIMATION_PICS = 10;

struct Vertex
{
    float vx, vy, vz;
    float nx, ny, nz;
    float ux, uy;
};

struct GlobalData
{
    VEC2 screenSize;
    MAT4 viewProj;
};

struct Transform
{
    VEC4 position;
    uint32_t animationIdx;
    uint32_t u;

    float layer;
    float radius;
};

struct PushData
{
    uint32_t transformIdx;
};

struct Glyph
{
    int width;
    int height;
    float lu;
    float ru;
    float tv;
    float bv;
    int xOff;
    int yOff;
    int advance;
    int leftSideBearing;
};

struct GlyphTransform
{
    VEC2 pos;
    int glyphIdx;
    int padding; //TODO: Could be used for color
};

int pack_color(VEC4 color)
{
    int r = int(color.x * 255.0);
    int g = int(color.y * 255.0);
    int b = int(color.z * 255.0);
    int a = int(color.w * 255.0);

    int packedColor = a + (b << 8) + (g << 16) + (r << 24);
    return packedColor;
}

VEC4 extract_color(int color)
{
    int first8Bytes = (1 << 9) - 1;

    float a = color & first8Bytes;
    float b = (color >> 8) & first8Bytes;
    float g = (color >> 16) & first8Bytes;
    float r = (color >> 24) & first8Bytes;

    VEC4 result;
    result.x = r / 255.0;
    result.y = g / 255.0;
    result.z = b / 255.0;
    result.w = a / 255.0;

    return result;
}
