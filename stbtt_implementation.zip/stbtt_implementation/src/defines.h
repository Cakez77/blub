//TODO: Maybe use my own defines?
#include <cstdint>
#define BIT(x) (1 << x)

#define ArraySize(arr) sizeof((arr)) / sizeof((arr)[0])

#ifdef WINDOWS_BUILD
#define line_id(index) (size_t)((__LINE__ << 16) | (index))
#endif

#define internal static
#define local_persist static
#define global_variable static

#define KB(x) ((uint64_t)1024 * x)
#define MB(x) ((uint64_t)1024 * KB(x))
#define GB(x) ((uint64_t)1024 * MB(x))