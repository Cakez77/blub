#pragma once

#include "vk_types.h"

namespace Cakez
{
    VkInstance create_instance();

    VkDebugUtilsMessengerEXT create_debug_messenger(VkInstance instance);

    VkSurfaceKHR create_surface(
        VkInstance instance,
        const void *window);

    VkPhysicalDevice pick_gpu(
        VkInstance instance,
        VkSurfaceKHR surface,
        int *outGraphicsIdx,
        int *outTransferIdx);

    bool device_supports_extension(
        VkPhysicalDevice gpu,
        const char *extensionName);

    VkDevice create_device(
        VkPhysicalDevice gpu,
        uint32_t transferIdx,
        uint32_t graphicsIdx,
        std::vector<const char *> extensions);

    VkQueryPool create_query_pool(
        VkDevice device,
        uint32_t queryCount,
        VkQueryType queryType);

    VkSwapchainKHR create_swapchain(
        VkDevice device,
        VkPhysicalDevice gpu,
        VkSurfaceKHR surface,
        std::vector<VkImage> &images,
        std::vector<VkImageView> &imageViews,
        bool vSync = false);

    VkPipeline create_pipeline(
        VkDevice device,
        VkRenderPass renderPass,
        VkPipelineLayout layout,
        VkPipelineShaderStageCreateInfo *pShaderStages,
        uint32_t stageCount,
        VkBool32 blendEnable,
        VkBlendOp colorBlendOp,
        VkBlendFactor srcColorBlendFactor,
        VkBlendFactor dstColorBlendFactor,
        VkBool32 depthWriteEnable = VK_TRUE,
        VkPrimitiveTopology topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST);

    //TODO: Maybe remove this function to be called and move it to cpp only
    VkShaderModule create_shader_module(
        VkDevice device,
        uint32_t *code,
        uint32_t size);
} // namespace Cakez
