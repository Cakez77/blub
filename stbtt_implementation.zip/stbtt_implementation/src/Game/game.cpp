#include "game.h"

#include "game_state.h"
#include "platform.h"
#include "ui.h"
#include "Assets/assets.h"

#include <algorithm>

namespace Cakez
{
    //#######################################################################
    //              Internal functions
    //#######################################################################
    internal Entity *create_entity(GameState *gameState)
    {
        if (gameState->entityCount < MAX_ENTITIES)
        {
            Entity *e = &gameState->entities[gameState->entityCount];
            gameState->entityCount++;

            // Zero out values of the entity
            *e = Entity{};

            return e;
        }
        else
        {
            // CAKEZ_ASSERT(0, "Reached maximum amount of entities");
            return 0;
        }
    }

    internal void add_component(
        Entity *entity,
        Components component)
    {
        entity->compMask |= component;
    }

    internal void remove_component(
        Entity *entity,
        Components component)
    {
        entity->compMask &= ~component;
    }

    internal void add_class(
        Entity *entity,
        EntityClass newClass)
    {
        entity->classMask |= newClass;
    }

    internal void remove_class(
        Entity *entity,
        EntityClass removeClass)
    {
        entity->classMask &= ~removeClass;
    }

    internal bool has_class(
        Entity *entity,
        EntityClass hasClass)
    {
        return entity->classMask & hasClass;
    }

    internal Entity *add_animated_sprite(
        GameState *gameState,
        Assets *assets,
        AnimationState animationState = ANIMATION_STATE_IDLE,
        AssetTypeID idleAssetID = ASSET_KNIGHT_IDLE,
        AssetTypeID runAssetID = ASSET_KNIGHT_RUN,
        AssetTypeID attackAssetID = ASSET_KNIGHT_ATTACK,
        Rect rect = {100.0f, 100.0f, 100.0f, 100.0f},
        Layer layer = LAYER_ENTITIES)
    {
        Entity *e = create_entity(gameState);
        if (e)
        {
            Asset *idleAsset = get_asset(assets, idleAssetID);
            Asset *runAsset = get_asset(assets, runAssetID);
            Asset *attackAsset = get_asset(assets, attackAssetID);
            if (idleAsset->type == ASSET_TYPE_ANIMATION &&
                runAsset->type == ASSET_TYPE_ANIMATION &&
                attackAsset->type == ASSET_TYPE_ANIMATION)
            {
                e->assetID = idleAssetID;
                e->animationState = animationState;
                add_component(e, SPRITE_COMPONENT);

                e->animations[ANIMATION_STATE_IDLE] = idleAssetID;
                e->animations[ANIMATION_STATE_RUN] = runAssetID;
                e->animations[ANIMATION_STATE_ATTACK] = attackAssetID;

                e->rect = rect;
                e->layer = layer;
                return e;
            }
            else
            {
                CAKEZ_ASSERT(false,
                             "One of the following asset ID's: %d, %d, %d, is not an animation!",
                             idleAssetID,
                             runAssetID,
                             attackAssetID);
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }

    internal void add_animation_state(
        GameState *gameState,
        Assets *assets,
        Entity *entity,
        AnimationState animationState,
        AssetTypeID assetID)
    {
        Asset *asset = get_asset(assets, assetID);

        if (asset->type == ASSET_TYPE_ANIMATION)
        {
            entity->animations[animationState] = assetID;
        }
    }

    internal Entity *add_sprite(
        GameState *gameState,
        AssetTypeID assetID,
        Rect rect = {100.0f, 100.0f, 100.0f, 100.0f},
        Layer layer = LAYER_ENTITIES)
    {
        Entity *e = create_entity(gameState);
        e->assetID = assetID;
        e->rect = rect;
        e->compMask |= SPRITE_COMPONENT;
        e->layer = layer;
        return e;
    }

    internal void inflict_damage(Entity *e, int damage)
    {
        if (e->health > damage)
        {
            // Inflic damage
            e->health -= damage;
        }
        else
        {
            // Mark as dead
            add_component(e, DEATH_COMPONENT);
        }
    }

    internal void heal_target(Entity *e, uint32_t damage)
    {
        e->health += damage;

        if (e->health > e->maxHealth)
            e->health = e->maxHealth;
    }

    internal float get_animation_duration(Entity *e)
    {
        float animationDuration = 1.0f;
        switch (e->animationState)
        {
        case ANIMATION_STATE_IDLE:
            animationDuration = BASE_ANIMATION_DURATION / 1.0f;
            break;

        case ANIMATION_STATE_ATTACK:
            if (e->attackSpeed > 0)
            {
                animationDuration = BASE_ANIMATION_DURATION / e->attackSpeed;
            }
            break;

        case ANIMATION_STATE_RUN:
            if (e->movementSpeed > 0)
            {
                animationDuration = BASE_ANIMATION_DURATION / e->movementSpeed;
            }
            break;
        }

        return animationDuration;
    }

    internal Components get_target_component(Entity *e, Rule *r)
    {
        uint32_t component = 0;

        if (has_component(e, HERO_COMPONENT))
        {
            switch (r->action)
            {
            case ACTION_ATTACK:
                component = ENEMY_COMPONENT;
                break;

            case ACTION_HEAL:
                component = HERO_COMPONENT;
                break;
            }
        }
        else if (has_component(e, ENEMY_COMPONENT))
        {
            switch (r->action)
            {
            case ACTION_ATTACK:
                component = ENEMY_COMPONENT;
                break;

            case ACTION_HEAL:
                component = HERO_COMPONENT;
                break;
            }
        }

        return (Components)component;
    }

    internal Entity *look_for_target(GameState *gameState, Entity *e)
    {
        Entity *bestTarget = 0;

        // validate rules
        for (uint32_t i = 0; i < e->ruleCount; i++)
        {
            // Break out early, this matters because of rules ordering
            if (bestTarget)
            {
                e->target = bestTarget;
                break;
            }

            Rule *r = &e->rules[i];
            Components targetComponent = get_target_component(e, r);

            for (uint32_t j = 0; j < gameState->entityCount; j++)
            {
                Entity *potentialTarget = &gameState->entities[j];

                if (has_component(potentialTarget, targetComponent) &&
                    circle_collision(e->attackRadius, e->rect.pos,
                                     potentialTarget->hitboxRadius, potentialTarget->rect.pos))
                {
                    bool condition = false;

                    if (!bestTarget)
                    {
                        bestTarget = potentialTarget;
                    }
                    else
                    {
                        switch (r->type)
                        {

                        case RULE_TYPE_STAY_ON_TARGET:
                        {
                            condition = true;
                        }
                        break;

                        case RULE_TYPE_HEALTH_THRESHOLD:
                        {
                            condition = (float)potentialTarget->health / (float)potentialTarget->maxHealth < (float)bestTarget->health / (float)bestTarget->maxHealth;
                        }
                        break;
                        case RULE_TYPE_HIGHEST_MAX_HP:
                        {
                            condition = potentialTarget->maxHealth > bestTarget->maxHealth;
                        }
                        break;
                        case RULE_TYPE_LOWEST_MAX_HP:
                        {
                            condition = potentialTarget->maxHealth < bestTarget->maxHealth;
                        }
                        break;
                        case RULE_TYPE_HIGHEST_HP:
                        {
                            condition = potentialTarget->health > bestTarget->health;
                        }
                        break;
                        case RULE_TYPE_LOWEST_HP:
                        {
                            condition = potentialTarget->health < bestTarget->health;
                        }
                        break;
                        }

                        if (condition)
                        {
                            bestTarget = potentialTarget;
                        }
                    }
                }
            }
        }

        return bestTarget;
    }

    internal Entity *add_hero(GameState *gameState)
    {
        Entity *e = 0;
        if (gameState->team.heroCount < MAX_HEROES)
        {

            e = create_entity(gameState);
            add_component(e, HERO_COMPONENT);
            add_component(e, ANIMATION_COMPONENT);
            add_component(e, SPRITE_COMPONENT);
            add_class(e, CLASS_RANGED);

            Rule r = {};
            r.action = ACTION_ATTACK;
            r.type = RULE_TYPE_STAY_ON_TARGET;
            e->rules[0] = r;
            e->ruleCount++;

            e->layer = LAYER_ENTITIES;
            e->animationState = ANIMATION_STATE_IDLE;
            e->animations[ANIMATION_STATE_IDLE] = ASSET_WHITE;
            e->animations[ANIMATION_STATE_RUN] = ASSET_WHITE;
            e->animations[ANIMATION_STATE_ATTACK] = ASSET_KNIGHT_ATTACK;
            e->rect = {1000.0f, 100.0f, 100.0f, 100.0f};
            e->attackRadius = 900.0f;
            e->assetID = ASSET_WHITE;

            gameState->team.heroes[gameState->team.heroCount] = *e;
            gameState->team.heroCount++;
        }
        return e;
    }

    // Returns a 20 x 20 px Hitbox around the waypoint position
    internal Rect get_waypoint_hitbox(Vec2 *pos)
    {
        return {pos->x - 10.0f, pos->y - 10.0f, 20.0f, 20.0f};
    }

    //#######################################################################
    //              Animation specific functions, might extract later
    //#######################################################################
    internal void transition_animation(Entity *e, AnimationState newState)
    {
        if (e->animationState != newState)
        {
            e->animationTime = 0.0f;
            e->animationState = newState;
            AssetTypeID assetID = e->animations[newState];
            e->assetID = assetID;
        }
    }

    //#######################################################################
    //              Debug functions, will be removed
    //#######################################################################
    internal Entity *debug_add_enemy(GameState *gameState, Assets *assets, Vec2 pos)
    {
        Entity *e = add_animated_sprite(gameState,
                                        assets,
                                        ANIMATION_STATE_IDLE,
                                        ASSET_KNIGHT_IDLE,
                                        ASSET_SKELLY_SHIELD_WALK,
                                        ASSET_SKELLY_SHIELD_ATTACK);

        if (e)
        {
            e->rect.pos = pos;
            e->attack = 20;
            e->health = 500;
            e->maxHealth = 500;
            e->attackSpeed = 2.2f;  // a/s => s 1.2 a/s = 1 second duration | devide /1.2 = > 0.8
            e->movementSpeed = 1.2; // a/s => s 1.2 a/s = 1 second duration | devide /1.2 = > 0.8
            e->hitboxRadius = 50.0f;
            e->attackRadius = 100.0f;
            e->layer = LAYER_ENTITIES;
            Rule r = {};
            r.action = ACTION_ATTACK;
            r.type = RULE_TYPE_STAY_ON_TARGET;
            e->rules[0] = r;
            e->ruleCount++;

            add_class(e, CLASS_MELEE);
            add_component(e, ENEMY_COMPONENT);
            add_component(e, ANIMATION_COMPONENT);
            return e;
        }
        else
        {
            return 0;
        }
    }

    internal Entity *debug_find_enemy(GameState *gameState)
    {
        for (uint32_t i = 0; i < gameState->entityCount; i++)
        {
            Entity *e = &gameState->entities[i];
            if (has_component(e, ENEMY_COMPONENT))
            {
                return e;
            }
        }

        return 0;
    }

    internal Entity *debug_spawn_arrow(GameState *gameState, Vec2 pos, Entity *target)
    {
        // Arrow
        Entity *e = create_entity(gameState);

        e->rect.pos = pos;
        e->rect.sizeX = 50.0f;
        e->rect.sizeY = 50.0f;
        e->attack = 10;

        e->movementSpeed = 1.2f;
        e->animationState = ANIMATION_STATE_RUN;

        add_component(e, SPRITE_COMPONENT);
        add_component(e, PROJECTILE_COMPONENT);
        add_component(e, ANIMATION_COMPONENT);

        //TODO: Fix this, this

        e->assetID = ASSET_ICE_SHOT;

        e->target = target;
        return e;
    }

    //TODO: Remove
    internal Entity *debug_add_hero(GameState *gameState, Assets *assets, Vec2 pos = {700.0f, 100.0f})
    {
        Entity *e = 0;
        if (gameState->team.heroCount < MAX_HEROES)
        {
            e = add_animated_sprite(gameState, assets);
            if (e)
            {
                gameState->team.heroCount++;

                add_component(e, HERO_COMPONENT);
                add_component(e, ANIMATION_COMPONENT);
                add_class(e, CLASS_MELEE);
                Rule r = {};
                r.action = ACTION_ATTACK;
                r.type = RULE_TYPE_LOWEST_HP;
                e->rules[0] = r;
                e->ruleCount++;

                e->animations[ANIMATION_STATE_ATTACK] = ASSET_SKELLY_ATTACK;
                e->rect.pos = pos;
                e->hitboxRadius = e->rect.sizeY / 2;
                e->attackRadius = 100.0f;
                e->attackSpeed = 1.2f;
                e->attack = 5;
                e->health = 300;
                e->maxHealth = 300;
                e->layer = LAYER_ENTITIES;
            }
        }

        return e;
    }

    internal void debug_add_waypoint(GameState *gameState, uint32_t x, uint32_t y)
    {
        if (gameState->waypointCount < MAX_WAYPOINTS)
        {
            gameState->waypoints[gameState->waypointCount] = {(float)x, (float)y};
            gameState->waypointCount++;
        }
        else
        {
            CAKEZ_TRACE("Cannot create more waypoints");
        }
    }

    internal void save_level(GameState *gameState)
    {
        platform_write_file(
            "level.txt",
            (const char *)gameState,
            sizeof(GameState),
            true);
    }

    internal void load_level(GameState *gameState)
    {
        uint32_t bytesRead;
        //TODO: Allocate from game memory later
        GameState *loadedGameState = (GameState *)platform_read_file(
            "level.txt",
            bytesRead);

        *gameState = *loadedGameState;
        CAKEZ_TRACE("GameState Selected Entity %d", loadedGameState->selectedEntity);
        delete loadedGameState;
    }

    internal void save_hero(GameState *gameState, Assets *assets, Entity *e)
    {
        platform_write_file(
            "heroes.txt",
            (const char *)e,
            sizeof(Entity),
            false);

        reload_heroes(assets);
    }

    internal void add_hero_to_team(GameState *gameState, Entity *e)
    {
        if (gameState->team.heroCount < MAX_HEROES)
        {
            gameState->team.heroes[gameState->team.heroCount] = *e;
            gameState->team.heroCount++;
        }
    }

    internal void show_entity_stats(GameState *gameState, UIState *ui, InputState *input, Entity *e)
    {
#ifdef DEBUG
        do_container(ui, input, ASSET_SCROLL, "Entity Stats",
                     (size_t) "Entity Stats",
                     {900.0f, 200.0f, 600.0f, 600.0});

        float yOff = 110.0f;
        float width = 550.0f;
        float xOff = 20.0f;
        float buttonXOff = 450.0f;
        float buttonXSize = 100.0f;
        int row = 1;

        int valueLength = 0;
        convert_number_to_char((int)e->rect.pos.x, gameState->value, &valueLength);
        gameState->value[valueLength] = 0;

        // X - Position
        {
            do_text(ui, "X - Pos:", (size_t) "X - Pos:",
                    {xOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            do_number(ui, (int)e->rect.pos.x, (size_t) "X - Pos Value",
                      {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            if (do_slide_button(ui, input, ASSET_HERO_BAR, 0, (size_t)&e->rect.pos.x,
                                {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING),
                                 buttonXSize, GLYPH_WIDTH}))
            {
                e->rect.pos.x += input->relMouseX;
            }
            row++;
        }

        // Y - Position
        {
            do_text(ui, "Y - Pos:", (size_t) "Y - Pos:",
                    {xOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            do_number(ui, (int)e->rect.pos.y, (size_t) "Y - Pos Value",
                      {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            if (do_slide_button(ui, input, ASSET_HERO_BAR, 0, (size_t)&e->rect.pos.y,
                                {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING),
                                 buttonXSize, GLYPH_WIDTH}))
            {
                e->rect.pos.y += input->relMouseX;
            }
            row++;
        }

        // Attack Radius
        {
            do_text(ui, "Attack Radius", (size_t) "Attack Radius",
                    {xOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            do_number(ui, (int)e->attackRadius, (size_t) "Attack Radius Value",
                      {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            if (do_slide_button(ui, input, ASSET_HERO_BAR, 0, (size_t)&e->attackRadius,
                                {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING),
                                 buttonXSize, GLYPH_WIDTH}))
            {
                e->attackRadius += input->relMouseX;
            }
            row++;
        }

        // Attack
        {
            do_text(ui, "Attack", (size_t) "Attack",
                    {xOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            do_number(ui, (int)e->attack, (size_t) "Attack Value",
                      {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            if (do_slide_button(ui, input, ASSET_HERO_BAR, 0, (size_t)&e->attack,
                                {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING),
                                 buttonXSize, GLYPH_WIDTH}))
            {
                e->attack += input->relMouseX;
            }
            row++;
        }

        // Attack Speed
        {
            do_text(ui, "Attack Speed", (size_t) "Attack Speed",
                    {xOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            do_number(ui, (int)e->attackSpeed, (size_t) "Attack Speed Value",
                      {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING)});

            if (do_slide_button(ui, input, ASSET_HERO_BAR, 0, (size_t)&e->attackSpeed,
                                {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING),
                                 buttonXSize, GLYPH_WIDTH}))
            {
                e->attackSpeed += input->relMouseX;
            }
            row++;
        }

        // Idle Animation
        // TODO: Do Drop down here
        // TODO: Add other animations too
        if (do_slide_button(ui, input, ASSET_HERO_BAR, 0, (size_t)&e->animations[ANIMATION_STATE_IDLE],
                            {buttonXOff, yOff + row * (GLYPH_WIDTH + UI_PADDING),
                             buttonXSize, GLYPH_WIDTH}))
        {
        }

        end_container(ui);
#else

#endif
    }

    internal float debug_ease_in(float x)
    {
        if (x < 1.0)
        {
            return x * x;
        }
        else
        {
            return 1.0;
        }
    }

    internal bool do_labeled_number(UIState *ui, InputState *input, int value, char *label,
                                    size_t numberId, size_t buttonId, Vec2 textPos, Rect buttonRect)
    {
        do_text(ui, label, (size_t)label, textPos);

        do_number(ui, value, numberId, {buttonRect.pos.x + 2 * UI_PADDING, buttonRect.pos.y - UI_PADDING});

        return do_slide_button(ui, input, ASSET_HERO_BAR, 0, buttonId, buttonRect);
    }

    void show_hero_bar(GameState *gameState, InputState *input, UIState *ui)
    {
        // Hero Bar UI
        {
            uint32_t width, height;
            float heroBarHeight = debug_ease_in(gameState->gameTime / gameState->transitionDuration) * 150.0f;

            platform_get_window_size(&width, &height);
            do_container(ui, input, ASSET_HERO_BAR, 0, (size_t) "hero bar",
                         {0.0f, (float)height - heroBarHeight, (float)width, 150.0f});

            // Entity Stats display
            if (gameState->selectedEntity)
            {
                Entity *e = gameState->selectedEntity;

                float yOff = 5.0f;
                float xOff = 20.0f;
                float rectSpacing = 200.0f;
                float rectSize = 80.0f;
                float iconSize = 80.0;

                // Two skills
                do_text(ui, "Skills", (size_t) "Skills", {xOff, yOff});
                yOff += GLYPH_WIDTH + 10.0f;
                do_button(ui, input, ASSET_HEAL_ICON, 0, line_id(1),
                          {xOff, yOff, iconSize, iconSize});
                xOff += iconSize + UI_PADDING;

                do_button(ui, input, ASSET_HEAL_ICON, 0, line_id(1),
                          {xOff, yOff, iconSize, iconSize});

                xOff += iconSize + 200.0f + UI_PADDING;

                yOff = 20.0f;
                do_labeled_number(ui, input, (int)e->maxHealth, "Health",
                                  line_id(1), (size_t)&e->maxHealth,
                                  {xOff, yOff}, {xOff + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                do_labeled_number(ui, input, (int)e->maxMana, "Mana",
                                  line_id(1), (size_t)&e->maxMana,
                                  {xOff, yOff}, {xOff + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                do_labeled_number(ui, input, (int)e->attack, "Attack",
                                  line_id(1), (size_t)&e->attack,
                                  {xOff, yOff}, {xOff + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                yOff = 20.0f;
                xOff += rectSpacing * 2 + 20.0f;
                float extraSpacing = 30.0f;
                do_labeled_number(ui, input, (int)e->attackRadius, "Attack Radius",
                                  line_id(1), (size_t)&e->attackRadius,
                                  {xOff, yOff}, {xOff + extraSpacing + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                do_labeled_number(ui, input, (int)e->attackSpeed, "Attack Speed",
                                  line_id(1), (size_t)&e->attackSpeed,
                                  {xOff, yOff}, {xOff + extraSpacing + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                do_labeled_number(ui, input, (int)e->armour, "Armour",
                                  line_id(1), (size_t)&e->fireResist,
                                  {xOff, yOff}, {xOff + extraSpacing + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                yOff = 20.0f;
                xOff += rectSpacing * 2 + 20.0f;
                do_labeled_number(ui, input, (int)e->fireResist, "Fire Resist",
                                  line_id(1), (size_t)&e->fireResist,
                                  {xOff, yOff}, {xOff + extraSpacing + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                do_labeled_number(ui, input, (int)e->coldResist, "Cold Resist",
                                  line_id(1), (size_t)&e->coldResist,
                                  {xOff, yOff}, {xOff + extraSpacing + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;

                do_labeled_number(ui, input, (int)e->lightningResist, "Light Resist",
                                  line_id(1), (size_t)&e->lightningResist,
                                  {xOff, yOff}, {xOff + extraSpacing + rectSpacing, yOff, rectSize, GLYPH_WIDTH});
                yOff += GLYPH_WIDTH;
            }
            else
            {
                // Team display
                float spriteSize = 100.0f;
                float yOff = UI_PADDING;
                for (uint32_t i = 0; i < gameState->team.heroCount; i++)
                {
                    Entity *hero = &gameState->team.heroes[i];
                    float xPos = i * spriteSize + UI_PADDING;
                    float yPos = yOff;

                    if (do_following_button(ui, input, hero->animations[ANIMATION_STATE_IDLE],
                                            (size_t)&hero->animations[ANIMATION_STATE_IDLE],
                                            {xPos, yPos, spriteSize, spriteSize}))
                    {
                        Entity *e = create_entity(gameState);
                        *e = *hero;
                        e->rect.pos = {(float)input->mouseX, (float)input->mouseY};

                        // Copy all heroes over one place to the left
                        for (uint32_t j = i; j + 1 < gameState->team.heroCount; j++)
                        {
                            gameState->team.heroes[j] = gameState->team.heroes[j + 1];
                        }

                        // Remove hero from team
                        gameState->team.heroCount--;
                    }
                }
                end_container(ui);
            }
        }
    }

    internal void update_entities(GameState *gameState, UIState *ui, InputState *input, Assets *assets, float dt)
    {
        if (!is_ui_hot(ui) && key_pressed_this_frame(input, LEFT_MOUSE_KEY))
        {
            Vec2 mouseClickPos = {(float)input->clickMouseX,
                                  (float)input->clickMouseY};

            gameState->selectedEntity = 0;

            for (uint32_t i = 0; i < gameState->entityCount; i++)
            {
                Entity *e = &gameState->entities[i];

                if (has_component(e, HERO_COMPONENT) ||
                    has_component(e, ENEMY_COMPONENT))
                {
                    if (point_in_rect(mouseClickPos, e->rect))
                    {
                        if (gameState->selectedEntity)
                        {
                            // Check if the found entity is in front
                            if (e->rect.pos.y < gameState->selectedEntity->rect.pos.y)
                            {
                                gameState->selectedEntity = &gameState->entities[i];
                                gameState->selectedEntity = e;
                            }
                        }
                        else
                        {

                            gameState->selectedEntity = e;
                        }
                    }
                }
            }
        }

        //TODO: this is movement speed, remove
        float speed = 0.5f;
        for (uint32_t i = 0; i < gameState->entityCount; i++)
        {
            //Systems
            Entity *e = &gameState->entities[i];
            Asset *asset = get_asset(assets, e->assetID);

            // Remove selected dead entities
            if (gameState->selectedEntity && has_component(gameState->selectedEntity, DEATH_COMPONENT))
            {
                gameState->selectedEntity = 0;
            }

            // Death system
            if (has_component(e, DEATH_COMPONENT))
            {
                // Updating pointers of targets
                Entity *lastEntity = &gameState->entities[gameState->entityCount - 1];
                for (uint32_t j = 0; j < gameState->entityCount; j++)
                {
                    Entity *en = &gameState->entities[j];

                    if (en->target == e)
                    {
                        en->target = 0;
                    }

                    // Check if any entity references the last entity
                    if (en->target == lastEntity)
                    {
                        en->target = e;
                    }
                }

                // Destroy the entity
                gameState->entityCount--;

                if (e == gameState->selectedEntity)
                {
                    gameState->selectedEntity = 0;
                }

                // Swap last entity to spot of dead entity
                *e = *lastEntity;

                if (lastEntity == gameState->selectedEntity)
                {
                    gameState->selectedEntity = e;
                }

                // Zero out the last entity
                *lastEntity = Entity{};
                break;
            }

            // Animation System
            {
                if (has_component(e, ANIMATION_COMPONENT) && asset->type == ASSET_TYPE_ANIMATION)
                {
                    // Add animation time
                    e->animationTime += dt / 1000.0f;

                    // Calculate Animation duration
                    float animationDuration = get_animation_duration(e);

                    // Loop the animation by resetting the animation time
                    while (e->animationTime > animationDuration)
                    {
                        e->animationTime -= animationDuration;
                    }

                    // Change spriteIndex based on animation time
                    e->animationIdx = (uint8_t)((float)asset->count * (e->animationTime / animationDuration));
                    if (e->animationIdx >= asset->count)
                    {
                        e->animationIdx = asset->count - 1;
                    }

                    // Change direction of entity based on velocity
                    if (e->vel.x < 0.0f)
                    {
                        e->u = 1;
                    }
                    if (e->vel.x > 0.0f)
                    {
                        e->u = 0;
                    }
                }
                else
                {
                    e->animationIdx = 0;
                }
            }

            // Projectile behaviour
            if (has_component(e, PROJECTILE_COMPONENT))
            {
                if (e->target)
                {
                    if (circle_collision(e->attackRadius, get_hitbox_origin(e->rect),
                                         e->target->hitboxRadius, get_hitbox_origin(e->target->rect)))
                    {
                        Entity *lostTarget = 0;
                        Entity *lostTarget2 = 0;
                        Entity *lostTarget3 = 0;
                        // Inflic damage
                        inflict_damage(e->target, e->attack);

                        for (uint32_t k = 0; k < gameState->entityCount; k++)
                        {
                            Entity *dumb = &gameState->entities[k];
                            if (dumb == e->target)
                            {
                                lostTarget = dumb;
                            }
                        }

                        // Dissapear on impact
                        add_component(e, DEATH_COMPONENT);
                        for (uint32_t k = 0; k < gameState->entityCount; k++)
                        {
                            Entity *dumb = &gameState->entities[k];
                            if (dumb == e->target)
                            {
                                lostTarget2 = dumb;
                            }
                        }

                        // //TODO: Future me, trigger an explosion
                        // if (has_component(e, TRIGGER_ENTITY_COMPONENT))
                        // {
                        // trigger the entity to spawn
                        Entity *triggeredEntity = create_entity(gameState);
                        float explosionRadius = 400.0f;
                        for (uint32_t k = 0; k < gameState->entityCount; k++)
                        {
                            Entity *dumb = &gameState->entities[k];
                            if (dumb == e->target)
                            {
                                lostTarget3 = dumb;
                            }
                        }

                        // Set explosion middle
                        Vec2 targetMiddle = {e->target->rect.pos.x + e->target->rect.sizeX / 2.0f,
                                             e->target->rect.pos.y + e->target->rect.sizeY / 2.0f};

                        triggeredEntity->rect.pos.x = targetMiddle.x - explosionRadius / 2.0f;
                        triggeredEntity->rect.pos.y = targetMiddle.y - explosionRadius / 2.0f;

                        triggeredEntity->layer = LAYER_ENTITIES;

                        // Set epxlosion size
                        triggeredEntity->rect.size = {explosionRadius, explosionRadius};
                        triggeredEntity->attackRadius = explosionRadius;

                        for (uint32_t j = 0; j < gameState->entityCount; j++)
                        {
                            Entity *queryE = &gameState->entities[j];
                            if (has_component(queryE, ENEMY_COMPONENT) &&
                                circle_collision(triggeredEntity->attackRadius, get_hitbox_origin(triggeredEntity->rect),
                                                 queryE->hitboxRadius, get_hitbox_origin(queryE->rect)))
                            {
                                // Inflic damage
                                inflict_damage(queryE, 100.0f);
                            }
                        }

                        // NOTE: This assumes to have no more than 255 AssetID's
                        triggeredEntity->assetID = ASSET_EXPLOSION;
                        add_component(triggeredEntity, EXPLOSION_COMPONENT);
                        add_component(triggeredEntity, SPRITE_COMPONENT);
                        // }
                    }
                    else
                    {
                        // Chase
                        Vec2 targetPos = get_hitbox_origin(e->target->rect);
                        Vec2 projPos = get_hitbox_origin(e->rect);

                        Vec2 projToTarget = targetPos - projPos;
                        Vec2 direction = normalize(projToTarget);

                        e->vel = direction;
                        e->rect.pos += e->vel * speed * dt;
                    }
                }
                else
                {
                    // Dissapear
                    add_component(e, DEATH_COMPONENT);
                }
            }

            if (has_component(e, EXPLOSION_COMPONENT))
            {
                // Add animation time
                e->animationTime += dt / 1000.0f;

                // Calculate Animation duration
                float animationDuration = 0.3f;

                // Loop the animation by resetting the animation time
                if (e->animationTime > animationDuration)
                {
                    add_component(e, DEATH_COMPONENT);
                }

                // Change spriteIndex based on animation time
                e->animationIdx = (uint8_t)((float)asset->count * (e->animationTime / animationDuration));
                if (e->animationIdx >= asset->count)
                {
                    e->animationIdx = asset->count - 1;
                }
            }

            // if (has_component(e, HERO_COMPONENT) ||
            //     has_component(e, ENEMY_COMPONENT))
            // {
            //     if (e->health > 0)
            //         do_button(ui,
            //                   input,
            //                   ASSET_BUTTON_TEXTURE,
            //                   0,
            //                   (size_t)e,
            //                   {e->rect.pos,
            //                    (float)e->health / (float)e->maxHealth * e->rect.sizeX, 10.0f});
            // }

            if (has_component(e, HERO_COMPONENT))
            {

                // TODO: Remove later, debug only
                // Update the Entities velocity
                {
                    e->vel.x = 0.0f;
                    e->vel.y = 0.0f;

                    if (key_is_down(input, A_KEY))
                    {
                        e->vel.x += -1.0f;
                    }

                    if (key_is_down(input, D_KEY))
                    {
                        e->vel.x += 1.0f;
                    }

                    if (key_is_down(input, W_KEY))
                    {
                        e->vel.y += -1.0f;
                    }

                    if (key_is_down(input, S_KEY))
                    {
                        e->vel.y += 1.0f;
                    }

                    e->rect.pos += e->vel * speed * dt;
                }

                // Makes sure the target is valid
                e->target = look_for_target(gameState, e);

                // Assure the target is still valid (colliding and alive)
                if (e->target)
                {
                    transition_animation(e, ANIMATION_STATE_ATTACK);

                    // Remove time in seconds
                    e->attackCooldown -= dt / 1000.0f;

                    float animationDuration = get_animation_duration(e);
                    float halfDuration = 0.5f * animationDuration;

                    if (e->animationTime > halfDuration &&
                        e->attackCooldown < 0.0f)
                    {
                        if (has_class(e, CLASS_RANGED))
                        {
                            debug_spawn_arrow(gameState, e->rect.pos, e->target);
                        }
                        else if (has_class(e, CLASS_MELEE))
                        {
                            inflict_damage(e->target, e->attack);
                        }
                        else if (has_class(e, CLASS_HEAL))
                        {
                            heal_target(e->target, e->attack);
                        }
                        else
                        {
                            CAKEZ_ASSERT(0, "Entity class %d not recognized!!", e->classMask);
                        }

                        e->attackCooldown = animationDuration - (e->animationTime - halfDuration);
                    }
                }
                else if (e->vel.x != 0 || e->vel.y != 0)
                {
                    transition_animation(e, ANIMATION_STATE_RUN);
                }
                else
                {
                    transition_animation(e, ANIMATION_STATE_IDLE);
                }
            }

            if (has_component(e, ENEMY_COMPONENT))
            {

                look_for_target(gameState, e);

                // Assure the target is still valid (colliding and alive)
                if (e->target)
                {
                    transition_animation(e, ANIMATION_STATE_ATTACK);

                    // Remove time in seconds
                    e->attackCooldown -= dt / 1000.0f;

                    float animationDuration = get_animation_duration(e);
                    float halfDuration = 0.5f * animationDuration;

                    if (e->animationTime > halfDuration &&
                        e->attackCooldown < 0.0f)
                    {
                        inflict_damage(e->target, e->attack);

                        e->attackCooldown = animationDuration - (e->animationTime - halfDuration);
                    }
                }
                else
                {
                    transition_animation(e, ANIMATION_STATE_RUN);

                    if (gameState->waypointCount > 0)
                    {
                        if (e->nextWaypoint < gameState->waypointCount)
                        {
                            Vec2 *waypoint = &gameState->waypoints[e->nextWaypoint];
                            Vec2 direction = *waypoint - e->rect.pos;
                            e->vel = normalize(direction);

                            e->rect.pos += e->vel * speed * 0.5f * dt;

                            Rect waypointHitbox = get_waypoint_hitbox(waypoint);

                            if (point_in_rect(e->rect.pos, waypointHitbox))
                            {
                                e->nextWaypoint++;
                            }
                        }
                        else
                        {
                            // e->nextWaypoint = 0;
                        }
                    }
                }

                // Physics System
                if (has_component(e, PHYSICS_COMPONENT))
                {
                    if (e->target)
                    {
                        if (rect_collision(e->rect, e->target->rect))
                        {
                            // in seconds
                            e->animationTime += dt / 1000.0f;
                            float animationDuration = 0;
                            if (e->attackSpeed)
                            {
                                animationDuration = 1.0f / e->attackSpeed;
                            }

                            if (e->animationTime > animationDuration)
                            {
                                e->animationTime -= animationDuration;

                                // inflict damage
                                inflict_damage(e->target, e->attack);
                            }

                            remove_component(e, SPRITE_COMPONENT);
                            add_component(e, DEATH_COMPONENT);
                        }
                        else
                        {
                            // chase
                        }
                    }
                }
            }
        }
    }

    //#######################################################################
    //              Implementation of exposed game functions
    //#######################################################################

    bool init_game(GameState *gameState, Assets *assets)
    {
        // TODO: Debug only

        // Background
        uint32_t screenWidth, screenHeight;
        platform_get_window_size(&screenWidth, &screenHeight);
        Entity *background = add_sprite(gameState, ASSET_BACKGROUND, {0.0f, 0.0f, (float)screenWidth, (float)screenHeight});
        background->layer = LAYER_BACKGROUND;

        // // Hero
        // Entity *knight = debug_add_hero(gameState, assets);
        // save_hero(gameState, assets, knight);

        // Entity *ranger = debug_add_hero(gameState, assets);
        // remove_class(ranger, CLASS_MELEE);
        // add_class(ranger, CLASS_RANGED);
        // ranger->attackRadius = 300.0f;
        // ranger->animations[ANIMATION_STATE_IDLE] = ASSET_RANGER_IDLE;
        // ranger->animations[ANIMATION_STATE_RUN] = ASSET_RANGER_RUN;
        // ranger->animations[ANIMATION_STATE_ATTACK] = ASSET_RANGER_ATTACK;
        // ranger->assetID = ASSET_RANGER_IDLE;
        // ranger->rect.pos = {500.0f, 300.0f};

        // save_hero(gameState, assets, ranger);

        // Entity *healer = debug_add_hero(gameState, assets);
        // remove_class(healer, CLASS_MELEE);
        // add_class(healer, CLASS_HEAL);
        // healer->attackRadius = 500.0f;
        // healer->attack = 200.0f;
        // healer->animations[ANIMATION_STATE_IDLE] = ASSET_HEALER_IDLE;
        // healer->animations[ANIMATION_STATE_RUN] = ASSET_RANGER_RUN;
        // healer->animations[ANIMATION_STATE_ATTACK] = ASSET_HEALER_HEAL;
        // healer->assetID = ASSET_RANGER_IDLE;
        // healer->rect.pos = {700.0f, 500.0f};
        // save_hero(gameState, assets, healer);

        Entity *e = get_asset_entity(assets, ASSET_HERO_KNIGHT);
        add_hero_to_team(gameState, e);

        e = get_asset_entity(assets, ASSET_HERO_RANGER);
        add_hero_to_team(gameState, e);

        e = get_asset_entity(assets, ASSET_HERO_HEALER);
        add_hero_to_team(gameState, e);

        // Rectangular path
        debug_add_waypoint(gameState, 100.0f, 100.0f);
        debug_add_waypoint(gameState, 800.0f, 100.0f);
        debug_add_waypoint(gameState, 800.0f, 600.0f);
        debug_add_waypoint(gameState, 100.0f, 600.0f);

        gameState->transitionDuration = 5.0f;

#ifdef DEBUG
        save_level(gameState);
#endif

        return true;
    }

    bool update_game(
        GameState *gameState,
        UIState *ui,
        Assets *assets,
        InputState *input,
        float dt)
    {
        // is in seconds
        gameState->gameTime += dt / 1000.0f;

        // TODO: Debug, Remove
        {
            if (!is_ui_hot(ui) && key_pressed_this_frame(input, LEFT_MOUSE_KEY))
            {
                gameState->activeDropDown = 0;
            }

            for (uint32_t i = 0; i < gameState->waypointCount; i++)
            {
                if (do_slide_button(ui, input, ASSET_WHITE, 0, (size_t)&gameState->waypoints[i],
                                    {gameState->waypoints[i].x, gameState->waypoints[i].y, 20.0f, 20.0f}))
                {
                    gameState->waypoints[i].x += input->relMouseX;
                    gameState->waypoints[i].y += input->relMouseY;
                }
            }

            if (do_button(ui, input, ASSET_BUTTON_TEXTURE, "Test", (size_t) "Add Hero", {0.0f, 0.0f, 100.0f, GLYPH_WIDTH}) &&
                !gameState->selectedEntity)
            {
                gameState->selectedEntity = add_hero(gameState);
            }

            // if (gameState->selectedEntity &&
            //     do_button(ui, input, "Save Hero", (size_t) "Save Hero",
            //               LAYOUT_LEFT, {0.0f, 0.0f}, {160.0f, 0.0f}))
            // {
            //     save_hero(gameState, assets, gameState->selectedEntity);

            //     add_component(gameState->selectedEntity, DEATH_COMPONENT);
            //     gameState->selectedEntity = 0;
            // }

            // if (do_button(ui, input, "Load Hero", (size_t) "Load Hero",
            //               LAYOUT_LEFT, {0.0f, 0.0f}, {500.0f, 50.0f}))
            // {
            //     Entity *e = get_asset_entity(assets, (AssetTypeID)gameState->selectedEntity->heroType);
            //     if (e && gameState->team.heroCount < MAX_TEAM_MEMBERS)
            //     {
            //         e->target = 0;
            //         gameState->team.heroes[gameState->team.heroCount] = *e;
            //         gameState->team.heroCount++;
            //     }
            // }

            if (key_pressed_this_frame(input, L_KEY))
            {
                load_level(gameState);
            }

            if (key_pressed_this_frame(input, R_KEY))
            {
                debug_add_waypoint(gameState, input->mouseX, input->mouseY);
            }
        }

        switch (gameState->gameState)
        {
        case GAME_STATE_RUNNING_LEVEL:
        {
            if (key_pressed_this_frame(input, ESC_KEY))
            {
                gameState->gameState = GAME_STATE_MAIN_MENU;
            }

            if (key_pressed_this_frame(input, T_KEY))
            {
                gameState->gameState = GAME_STATE_EDIT_RULES;
            }

            // Spawning System
            {
                float spawnInterval = 1.0f;
                gameState->debugSpawnTimer += dt / 1000.0f;
                while (gameState->debugSpawnTimer > spawnInterval)
                {
                    CAKEZ_TRACE("Spawning Enemy");
                    debug_add_enemy(gameState, assets, {-100.0f, 100.0f});
                    gameState->debugSpawnTimer -= spawnInterval;
                }
            }

            show_hero_bar(gameState, input, ui);
            update_entities(gameState, ui, input, assets, dt);
        }
        break;

        case GAME_STATE_MAIN_MENU:
        {
            if (key_pressed_this_frame(input, ENTER_KEY))
            {
                gameState->gameState = GAME_STATE_RUNNING_LEVEL;
            }
        }
        break;

        case GAME_STATE_EDIT_RULES:
        {
            Entity *e = &gameState->team.heroes[gameState->heroIdx];

            if (key_pressed_this_frame(input, ESC_KEY))
            {
                gameState->gameState = GAME_STATE_RUNNING_LEVEL;
            }

            do_container(ui, input, ASSET_SCROLL, 0, (size_t) "Tactics Window",
                         {360.0f, 80.0f, 900.0f, 600.0f});

            if (gameState->team.heroCount)
            {
                float xOff = 150.0f;
                float headingYOff = 70.0f;

                if (do_button(ui, input, ASSET_BUTTON_TEXTURE, "<", (size_t) "prev hero",
                              {xOff, headingYOff, 50.0f, 50.0f}))
                {
                    if (gameState->heroIdx > 0)
                    {
                        gameState->heroIdx--;
                    }
                    else
                    {
                        gameState->heroIdx = gameState->team.heroCount - 1;
                    }
                }
                xOff += 60.0f;

                do_button(ui, input, e->animations[ANIMATION_STATE_IDLE], 0, (size_t)e,
                          {xOff, headingYOff - GLYPH_WIDTH / 2.0f, 80.0f, 80.0f});
                xOff += 90.0f;

                if (do_button(ui, input, ASSET_BUTTON_TEXTURE, ">", (size_t) "next hero",
                              {xOff, headingYOff, 50.0f, 50.0f}))
                {
                    if (gameState->heroIdx < gameState->team.heroCount - 1)
                    {
                        gameState->heroIdx++;
                    }
                    else
                    {
                        gameState->heroIdx = 0;
                    }
                }
                xOff += 60.0f;

                do_text(ui, "Tactics", (size_t) "Tactics", {xOff, headingYOff});

                std::sort(e->rules, e->rules + e->ruleCount,
                          [](Rule a, Rule b)
                          {
                              return a.priority < b.priority;
                          });

                // Sizes
                float yOff = 180.0f;
                xOff = 50.0f;
                float rulePrioXSize = GLYPH_WIDTH;
                float ruleTypeXSize = 340.0f;
                float ruleActionXSize = 200.0f;
                float spacing = 10.0f;

                // Titles
                {
                    do_text(ui, "Rule Type", line_id(0),
                            {xOff + rulePrioXSize + spacing + ruleTypeXSize / 4.0f, yOff});
                    do_text(ui, "Action", line_id(0),
                            {xOff + spacing + rulePrioXSize + spacing + ruleTypeXSize + spacing + ruleActionXSize / 4.0f, yOff});

                    yOff += GLYPH_WIDTH + spacing;
                }

                for (uint32_t j = 0; j < e->ruleCount; j++)
                {
                    xOff = 50.0f;
                    Rule *r = &e->rules[j];
                    size_t action_id = (size_t)&e->rules[j].action;
                    size_t rule_type_id = (size_t)&e->rules[j].type;

                    // Rule Order
                    {
                        do_text(ui, "#", line_id(j), {xOff, yOff});
                        size_t rule_order_id = line_id(j);
                        xOff += GLYPH_WIDTH;

                        if (do_button(ui, input, ASSET_BUTTON_TEXTURE, 0, rule_order_id,
                                      {xOff, yOff, GLYPH_WIDTH, GLYPH_WIDTH}, r->priority))
                        {
                            gameState->activeDropDown = rule_order_id;
                        }

                        if (gameState->activeDropDown == rule_order_id)
                        {
                            ui->global_layer += 2;
                            float yOffValues = yOff + GLYPH_WIDTH;
                            for (uint32_t i = 0; i < MAX_BEHAVIOUR_RULES; i++)
                            {
                                if (do_button(ui, input, ASSET_HERO_BAR, 0, line_id(i),
                                              {xOff, yOffValues, GLYPH_WIDTH, GLYPH_WIDTH}, i))
                                {
                                    r->priority = i;
                                    gameState->activeDropDown = 0;
                                }
                                yOffValues += GLYPH_WIDTH;
                            }
                            ui->global_layer -= 2;
                        }
                        xOff += rulePrioXSize + spacing;
                    }

                    // Rule Types
                    {
                        if (do_button(ui, input, ASSET_BUTTON_TEXTURE, ruleTypeStrings[r->type],
                                      rule_type_id, {xOff, yOff, ruleTypeXSize, GLYPH_WIDTH}))
                        {
                            gameState->activeDropDown = rule_type_id;
                        }

                        if (gameState->activeDropDown == rule_type_id)
                        {
                            ui->global_layer += 2;
                            float yOffValues = yOff + GLYPH_WIDTH;
                            for (uint32_t i = 0; i < RULE_TYPE_COUNT; i++)
                            {
                                if (do_button(ui, input, ASSET_HERO_BAR, ruleTypeStrings[i],
                                              (size_t)&ruleTypeStrings[i], {xOff, yOffValues, ruleTypeXSize, GLYPH_WIDTH}))
                                {
                                    r->type = (RuleType)i;
                                    gameState->activeDropDown = 0;
                                }
                                yOffValues += GLYPH_WIDTH;
                            }
                            ui->global_layer -= 2;
                        }
                        xOff += ruleTypeXSize + spacing;
                    }

                    // Action Type
                    {
                        if (do_button(ui, input, ASSET_BUTTON_TEXTURE, actionStrings[r->action],
                                      action_id, {xOff, yOff, ruleActionXSize, GLYPH_WIDTH}))
                        {
                            gameState->activeDropDown = action_id;
                        }

                        if (gameState->activeDropDown == action_id)
                        {
                            ui->global_layer = +2;
                            float yOffValue = yOff + GLYPH_WIDTH;
                            for (uint32_t i = 0; i < ACTION_COUNT; i++)
                            {
                                if (do_button(ui, input, ASSET_HERO_BAR, actionStrings[i],
                                              (size_t)&actionStrings[i],
                                              {xOff, yOffValue, ruleActionXSize, GLYPH_WIDTH}))
                                {
                                    r->action = (Action)i;
                                    gameState->activeDropDown = 0;
                                }

                                yOffValue += GLYPH_WIDTH;
                            }
                            ui->global_layer -= 2;
                        }
                    }
                    yOff += GLYPH_WIDTH + spacing;
                }

                xOff = 50.0f;
                if (do_button(ui, input, ASSET_BUTTON_TEXTURE, "Add Rule", (size_t) "addrulebtn",
                              {xOff, 500.0f, 200.0f, GLYPH_WIDTH}))
                {
                    if (e->ruleCount < MAX_BEHAVIOUR_RULES)
                    {
                        e->ruleCount++;
                    }
                }

                end_container(ui);
            }
        }
        break;
        }

        return true;
    }

    Vec2 get_hitbox_origin(const Rect &rect)
    {
        return {rect.pos.x + rect.sizeX / 2, rect.pos.y + rect.sizeY};
    }

    bool has_component(
        Entity *entity,
        Components component)
    {
        return entity->compMask & component;
    }
} // namespace Cakez
