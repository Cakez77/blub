#include "shader_util.h"

#include <spirv-headers/spirv.h>

#include "logger.h"
#include "platform.h"

namespace Cakez
{
    struct Member
    {
        const char *name;
        uint32_t referenceId;

        Member(const char *name_) : name(name_) {}
    };

    struct ID
    {
        const char *name;
        int storageClass = -1;
        uint32_t decoration;
        uint32_t dataType;
        uint32_t binding;
        uint32_t set;
        uint32_t location;
        uint32_t offset;
        uint32_t size;
        uint32_t referenceId;
        uint32_t componentCount;
        std::vector<Member> members;
    };

    static ShaderDataType get_shader_data_type(const uint32_t spvDataType, const uint32_t componentCount)
    {
        switch (spvDataType)
        {
        case SpvOpTypeFloat:
        {
            return componentCount == 0 ? TYPE_FLOAT : componentCount == 2 ? TYPE_VEC2
                                                  : componentCount == 3   ? TYPE_VEC3
                                                  : componentCount == 4   ? TYPE_VEC4
                                                  : componentCount == 9   ? TYPE_MAT3
                                                  : componentCount == 16  ? TYPE_MAT4
                                                                          : TYPE_UNKNOWN;
        }
        case SpvOpTypeBool:
            return TYPE_BOOL;

        case SpvOpTypeInt:
        {
            return componentCount == 0 ? TYPE_INT : componentCount == 2 ? TYPE_IVEC2
                                                : componentCount == 3   ? TYPE_IVEC3
                                                : componentCount == 4   ? TYPE_IVEC4
                                                                        : TYPE_UNKNOWN;
        }
        }

        CAKEZ_ASSERT(false, "Unknown data type");
        return TYPE_UNKNOWN;
    }

    static ShaderStage get_shader_stage(SpvExecutionModel executionModel)
    {
        switch (executionModel)
        {
        case SpvExecutionModelVertex:
            return SHADER_STAGE_VERTEX;
        case SpvExecutionModelFragment:
            return SHADER_STAGE_FRAGMENT;
        case SpvExecutionModelGLCompute:
            return SHADER_STAGE_COMPUTE;
        default:
            CAKEZ_ASSERT(false, "Unsupported execution model");
            return ShaderStage(0);
        }
    }

    static BindingType get_binding_type(SpvDecoration decoration)
    {
        switch (decoration)
        {
        case SpvDecorationBlock:
            return BINDING_TYPE_UNIFORM_BUFFER;
        case SpvDecorationBufferBlock:
            return BINDING_TYPE_STORAGE_BUFFER;
        default:
            CAKEZ_ASSERT(false, "Unsupported decoration");
            return BindingType(0);
        }
    }

    static BindingType get_binding_type(SpvOp_ opType)
    {
        switch (opType)
        {
        case SpvOpTypeImage:
            return BINDING_TYPE_SAMPLED_IMAGE;
            break;
        case SpvOpTypeSampledImage:
            return BINDING_TYPE_COMBINED_IMAGE_SAMPLER;
            break;
        default:
            CAKEZ_ASSERT(false, "Unsopported optype");
            return BindingType(0);
        }
    }

    static void insert_binding(const Binding &b, std::vector<Binding> &bindings, const ShaderStage shaderStage)
    {
        bool foundBinding = false;
        for (auto &binding : bindings)
        {
            if (binding.set_number == b.set_number && binding.number == b.number)
            {
                foundBinding = true;
                binding.shaderStages |= shaderStage;
            }
        }

        if (!foundBinding)
            bindings.push_back(b);
    }

    static void parse_members(std::vector<Attribute> &attributes, const std::vector<ID> &ids, const ID &id, uint32_t &bufferOffset)
    {
        for (const auto &member : id.members)
        {
            if (ids[member.referenceId].members.size() > 0)
            {
                parse_members(attributes, ids, ids[member.referenceId], bufferOffset);
                return;
            }

            ShaderDataType dataType = get_shader_data_type(ids[member.referenceId].dataType, ids[member.referenceId].componentCount);
            Attribute a = {dataType, member.name, bufferOffset};
            attributes.push_back(a);
            bufferOffset += ids[member.referenceId].size / 8;
        }
    }

    void compile_shader(const char *shaderPath, const char *spirvPath)
    {
        const char *shader = shaderPath;
        CAKEZ_ASSERT(platform_file_exists(shaderPath), "Shader not found!");

        // Only compile again if the shader changed or no spirv exists
        if (!platform_file_exists(spirvPath) ||
            (platform_last_edit_timestamp(shaderPath) > platform_last_edit_timestamp(spirvPath)) ||
            (platform_last_edit_timestamp(shaderPath) < platform_last_edit_timestamp("src/Renderer/render_types.h")))
        {
            char command[512];
            char *glslc = "lib\\glslc.exe";

            uint32_t i = 0;
            //Validator path
            while (char c = *glslc++)
                command[i++] = c;

            // Shader path
            command[i++] = ' ';
            while (char c = *shaderPath++)
                command[i++] = c;

            command[i++] = ' ';
            command[i++] = '-';
            command[i++] = 'o';
            command[i++] = ' ';

            // Spirv path
            while (char c = *spirvPath++)
                command[i++] = c;

            command[i++] = 0;

            int result = system(command);
            CAKEZ_ASSERT(!result, "ERROR compiling shader: %s", shader);
        }
    }

    void parse_spirv(
        std::vector<Binding> &bindings,
        std::vector<Attribute> &attributes,
        ShaderStage &shaderStage,
        uint32_t *spirv,
        uint32_t codeSize,
        bool &usePushConstants)
    {
        const uint32_t *spvBuffer = spirv;

        // The first four entries are header information
        CAKEZ_ASSERT(spvBuffer[0] == SpvMagicNumber, "Wrong magic number");
        const uint32_t idBound = spvBuffer[3];

        std::vector<ID> ids(idBound);
        const uint32_t *insn = spvBuffer + 5;

        while (insn != spvBuffer + codeSize)
        {
            uint16_t opcode = uint16_t(insn[0]);
            uint16_t wordCount = uint16_t(insn[0] >> 16);
            uint32_t id = insn[1];

            switch (opcode)
            {
            case SpvOpEntryPoint:
                shaderStage = get_shader_stage((SpvExecutionModel)insn[1]);
                break;

            case SpvOpDecorate:
            {
                uint32_t decoration = insn[2];
                ids[id].decoration = decoration;

                switch (decoration)
                {
                case SpvDecorationBlock:
                case SpvDecorationBufferBlock:
                    ids[id].decoration = decoration;
                    break;

                case SpvDecorationLocation:
                    ids[id].location = insn[3];
                    break;

                case SpvDecorationDescriptorSet:
                    ids[id].set = insn[3];
                    break;

                case SpvDecorationBinding:
                    ids[id].binding = insn[3];
                }
                break;
            }

            case SpvOpMemberName:
            {
                const char *name = (const char *)(&insn[3]);

                ids[id].members.push_back({name});
                break;
            }

            case SpvOpName:
                ids[id].name = (const char *)(&insn[2]);
                break;

            case SpvOpTypeStruct:
            {
                CAKEZ_ASSERT(wordCount - 2 == ids[id].members.size(), "Size missmatch");

                uint32_t index = 2;
                for (auto &member : ids[id].members)
                {
                    member.referenceId = insn[index];
                    index++;
                }
                break;
            }

            case SpvOpVariable:
                id = insn[2];
                ids[id].referenceId = insn[1];
                ids[id].storageClass = insn[3];
                break;

            case SpvOpTypePointer:
                ids[id].referenceId = insn[3];
                break;

            case SpvOpTypeBool:
                ids[id].size = 8;
                ids[id].dataType = opcode;
                break;

            case SpvOpTypeInt:
            case SpvOpTypeFloat:
            {
                ids[id].size = insn[2];
                ids[id].dataType = opcode;
                break;
            }
            case SpvOpTypeVector:
            {
                uint32_t referenceId = insn[2];
                ids[id].componentCount = insn[3];
                ids[id].size = ids[referenceId].size * insn[3];
                ids[id].referenceId = referenceId;
                ids[id].dataType = ids[referenceId].dataType;
                break;
            }
            case SpvOpTypeMatrix:
            {
                uint32_t referenceId = insn[2];
                ids[id].componentCount = insn[3] * ids[referenceId].componentCount;
                ids[id].size = ids[referenceId].size * insn[3];
                ids[id].referenceId = referenceId;
                ids[id].dataType = ids[referenceId].dataType;
                break;
            }

            case SpvOpConstant:
            {
                id = insn[2];
                ids[id].componentCount = insn[3];
                break;
            }

            case SpvOpTypeArray:
            {
                uint32_t typeReference = insn[2];
                uint32_t componentCountReference = insn[3];
                ids[id].componentCount = ids[componentCountReference].componentCount;
                ids[id].dataType = ids[typeReference].dataType;
                break;
            }

            case SpvOpTypeRuntimeArray:
            {
                uint32_t referenceId = insn[2];
                ids[id].componentCount = ids[referenceId].componentCount;
                ids[id].size = ids[referenceId].size;
                ids[id].referenceId = ids[referenceId].referenceId;
                ids[id].dataType = ids[referenceId].dataType;
                ids[id].members = ids[referenceId].members;
                break;
            }
            case SpvOpTypeImage:
            case SpvOpTypeSampledImage:
            {
                ids[id].dataType = opcode;
                break;
            }
            }

            CAKEZ_ASSERT(insn + wordCount <= spvBuffer + codeSize, "Word count of current instruction is too big!");
            insn += wordCount;
        }

        uint32_t vertexOffset = 0;
        for (const auto &id : ids)
        {
            switch (id.storageClass)
            {

            case SpvStorageClassInput:
            {
                if (!(shaderStage & SHADER_STAGE_VERTEX))
                    break;

                ID dataId = ids[ids[id.referenceId].referenceId];

                ShaderDataType type = get_shader_data_type(dataId.dataType, dataId.componentCount);

                Attribute a = {type, id.name, vertexOffset};
                vertexOffset += a.get_size();
                attributes.push_back(a);

                break;
            }

            case SpvStorageClassUniform:
            {
                ID dataId = ids[ids[id.referenceId].referenceId];

                Binding b;
                b.type = get_binding_type((SpvDecoration)dataId.decoration);
                b.number = id.binding;
                b.set_number = id.set;
                b.name = dataId.name;
                b.shaderStages = shaderStage;

                // Parse the members of the uniform and add them to the binding
                {
                    uint32_t offset = 0;
                    parse_members(b.attributes, ids, dataId, offset);
                }

                insert_binding(b, bindings, shaderStage);

                break;
            }

            case SpvStorageClassUniformConstant:
            {
                ID dataId = ids[ids[id.referenceId].referenceId];

                Binding b;
                b.name = id.name;
                b.set_number = id.set;
                b.shaderStages = shaderStage;
                b.number = id.binding;
                b.type = get_binding_type((SpvOp_)dataId.dataType);

                insert_binding(b, bindings, shaderStage);

                break;
            }

            case SpvStorageClassPushConstant:
            {
                usePushConstants = true;
                break;
            }
            }
        }
    }
} // namespace Cakez
