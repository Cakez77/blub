#pragma once
#include "defines.h"
#include "my_math.h"

namespace Cakez
{
    global_variable uint32_t constexpr MAX_BEHAVIOUR_RULES = 5;
    global_variable uint32_t constexpr GLYPH_COUNT = 93;

    // struct GlyphCache
    // {
    //     uint32_t fontSize;
    //     int largestYOffset;
    //     uint32_t glyphPadding;
    //     Glyph glyphs[95];
    //     Texture glyphAtlas;
    //     Buffer glpyhUBO;
    // };

    enum AssetTypeID
    {
        ASSET_NONE,

        // Pictures
        ASSET_WHITE,
        ASSET_HEAL_ICON,
        ASSET_KNIGHT,
        ASSET_SCROLL,
        ASSET_HERO_BAR,
        ASSET_BUTTON_TEXTURE,
        ASSET_BACKGROUND,

        // Animated Sprites
        ASSET_ICE_SHOT,

        // Animated things that run around
        ASSET_KNIGHT_RUN,
        ASSET_KNIGHT_IDLE,
        ASSET_KNIGHT_ATTACK,

        ASSET_SKELLY_ATTACK,
        ASSET_SKELLY_SHIELD_WALK,
        ASSET_SKELLY_SHIELD_ATTACK,

        ASSET_RANGER_IDLE,
        ASSET_RANGER_RUN,
        ASSET_RANGER_ATTACK,

        ASSET_HEALER_IDLE,
        ASSET_HEALER_HEAL,
        // End of Animated things that run around

        ASSET_EXPLOSION,

        // Text
        ASSET_TEXT,

        // Heroes
        ASSET_HERO_KNIGHT,
        ASSET_HERO_RANGER,
        ASSET_HERO_HEALER,

        // Enemies
        ASSET_ENEMY_SKELLY,

        ASSET_COUNT
    };

    enum AssetType
    {
        ASSET_TYPE_SPRITE,
        ASSET_TYPE_ANIMATION,
        ASSET_TYPE_HERO,
        ASSET_TYPE_ENEMY
    };

    struct Asset
    {
        uint8_t type;
        uint32_t count;
        uint32_t startingIndex;
    };

    enum AnimationState
    {
        ANIMATION_STATE_IDLE,
        ANIMATION_STATE_RUN,
        ANIMATION_STATE_ATTACK,

        ANIMATION_STATE_COUNT
    };

    enum AttackType
    {
        ATTACK_TYPE_PHYSICAL,
        ATTACK_TYPE_COLD,
        ATTACK_TYPE_FIRE,
        ATTACK_TYPE_LIGHTNING,
        ATTACK_TYPE_TRUE,
    };

    enum Layer
    {
        LAYER_BACKGROUND,
#ifdef DEBUG
        LAYER_DEBUG_CIRCLE,
#endif
        LAYER_ENTITIES,
        LAYER_UI,

        LAYER_COUNT
    };

    enum RuleType
    {
        RULE_TYPE_HEALTH_THRESHOLD,
        RULE_TYPE_STAY_ON_TARGET,
        RULE_TYPE_HIGHEST_MAX_HP,
        RULE_TYPE_LOWEST_MAX_HP,
        RULE_TYPE_HIGHEST_HP,
        RULE_TYPE_LOWEST_HP,

        RULE_TYPE_COUNT
    };

    enum Action
    {
        ACTION_ATTACK,
        ACTION_HEAL,
        ACTION_PASSIVE,

        ACTION_COUNT
    };

    struct Rule
    {
        Action action;
        RuleType type;
        int priority;
    };

    struct Entity
    {
        // Components
        uint32_t compMask;

        // Classes
        uint32_t classMask;

        // Assets currently in use
        AssetTypeID assetID;
        AssetTypeID heroType;

        // Stats
        uint16_t maxHealth;
        int16_t health;
        uint16_t maxMana;
        int16_t mana;

        // NOTE: Not implemented yet
        AttackType attackType;

        float attackSpeed;
        float attackCooldown;
        float attackRadius;
        uint16_t attack;
        uint16_t armour;
        int8_t coldResist;
        int8_t fireResist;
        int8_t lightningResist;

        float movementSpeed;

        // Animation data
        uint8_t animationIdx;
        float animationTime;
        uint8_t animationState;
        AssetTypeID animations[ANIMATION_STATE_COUNT];

        // Behaviour rules
        uint8_t ruleCount;
        Rule rules[MAX_BEHAVIOUR_RULES];

        // For collision
        float hitboxRadius;

        uint8_t triggerAssetID;

        uint8_t nextWaypoint;
        Entity *target;

        Vec2 vel;
        union
        {
            struct // Used for 3D rendering
            {
                Vec3 scale;
                Vec3 position;
            };
            struct // Used for 2D rendering
            {
                Rect rect;
                Layer layer;
                int u;
            };
        };
    };

} // namespace Cakez
