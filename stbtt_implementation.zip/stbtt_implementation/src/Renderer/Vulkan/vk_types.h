#pragma once

#include <vulkan/vulkan.h>

#include "logger.h"
#include "Renderer/shader_util.h"

#include <vector>

// Error checking macro to inform for error types
#define VK_CHECK(err)                                  \
	if (err)                                           \
	{                                                  \
		CAKEZ_FATAL("Detected Vulkan error: %d", err); \
		abort();                                       \
	}

namespace Cakez
{
	struct Buffer
	{
		VkBuffer vkBuffer;
		VkDeviceMemory memory;
		void *mapped;
		uint32_t size;
	};

	struct Image
	{
		VkImage vkImage;
		VkImageView vkImageView;
		VkSampler vkSampler;
		VkDeviceMemory memory;
		VkImageLayout layout;
	};

	struct Program
	{
		bool usePushConstants = false;
		bool colorBlending;
		const char *const *shaders;
		VkPipeline pipeline;
		VkPipelineLayout layout;
		std::vector<Binding> bindings;
		std::vector<VkDescriptorSetLayout> setLayouts;
	};

	struct CPUAndGPUSync
	{
		VkSemaphore renderSemaphore;
		VkSemaphore presentSemaphore;
		VkFence aquireImageFence;
		VkCommandBuffer cmd;
	};

	struct DescriptorInfo
	{
		union
		{
			VkDescriptorBufferInfo bufferInfo;
			VkDescriptorImageInfo imageInfo;
		};

		DescriptorInfo() = default;

		DescriptorInfo(VkBuffer vkBuffer, VkDeviceSize offset, VkDeviceSize range)
		{
			bufferInfo.buffer = vkBuffer,
			bufferInfo.offset = offset;
			bufferInfo.range = range;
		}

		DescriptorInfo(VkBuffer vkBuffer)
		{
			bufferInfo.buffer = vkBuffer;
			bufferInfo.offset = 0;
			bufferInfo.range = VK_WHOLE_SIZE;
		}

		DescriptorInfo(VkSampler sampler, VkImageView imageView, VkImageLayout imageLayout)
		{
			imageInfo.sampler = sampler;
			imageInfo.imageView = imageView;
			imageInfo.imageLayout = imageLayout;
		}
	};

	struct Sync
	{
		VkSemaphore _presentSeamphore, _renderSemaphore;
		VkFence _fence;
		VkCommandBuffer _cmd;
	};
} // namespace Cakez