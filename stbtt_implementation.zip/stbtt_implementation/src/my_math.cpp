#include "my_math.h"

namespace Cakez
{
    Vec2 Vec2::operator+(Vec2 &other)
    {
        return Vec2{
            x + other.x,
            y + other.y};
    }

    Vec2 &Vec2::operator+=(Vec2 &other)
    {
        x += other.x;
        y += other.y;

        return *this;
    }

    Vec2 Vec2::operator*(float scalar)
    {
        return Vec2{
            x * scalar,
            y * scalar};
    }

    Vec2 Vec2::operator-(Vec2 other)
    {
        return Vec2{
            x - other.x,
            y - other.y};
    }

    float length(Vec2 &v)
    {
        return 1 / Q_rsqrt((v.x * v.x) + (v.y * v.y));
    }

    Vec2 normalize(Vec2 &v)
    {
        float vecLenght = length(v);
        if (vecLenght <= 0)
            return Vec2{0.0f, 0.0f};

        return Vec2{
            v.x / vecLenght,
            v.y / vecLenght};
    }

    float length_squared(Vec2 &v)
    {
        return (v.x * v.x) + (v.y * v.y);
    }

    float Vec3::operator[](int index)
    {
        return values[index];
    }

    Vec3 Vec3::operator+(Vec3 &other)
    {
        return Vec3{
            x + other.x,
            y + other.y,
            z + other.z};
    }

    Vec3 Vec3::operator*(float value)
    {
        return Vec3{
            x * value,
            y * value,
            z * value};
    }

    Vec3 Vec3::operator-(Vec3 &other)
    {
        return Vec3{
            x - other.x,
            y - other.y,
            z - other.z};
    }

    Vec3 create_vec3(float *buffer)
    {
        return {
            *buffer,
            *(buffer + 1),
            *(buffer + 2)};
    }

    float length(Vec3 &v)
    {
        return square_root((v.x * v.x) + (v.y * v.y) + (v.z * v.z));
    }

    Vec3 normalize(Vec3 &v)
    {
        float vecLenght = length(v);
        if (vecLenght <= 0)
            return Vec3{0.0f, 0.0f, 0.0f};

        return Vec3{
            v.x / vecLenght,
            v.y / vecLenght,
            v.z / vecLenght};
    }

    Vec3 cross(Vec3 &a, Vec3 &b)
    {
        return Vec3{
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x};
    }

    float dot(Vec3 &a, Vec3 &b)
    {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }

    bool Vec4::operator==(Vec4 &other)
    {
        return x == other.x && y == other.y && z == other.z && w == other.w;
    }

    Vec4 Vec4::operator+(Vec4 &other)
    {
        return {
            x + other.x,
            y + other.y,
            z + other.z,
            w + other.w};
    }

    Vec4 Vec4::operator*(float value)
    {
        return {
            x * value,
            y * value,
            z * value,
            w * value};
    }

    float &Vec4::operator[](int index)
    {
        return values[index];
    }

    Vec4 create_vec4(float *buffer)
    {
        return {
            *buffer,
            *(buffer + 1),
            *(buffer + 2),
            *(buffer + 3)};
    }

    Quat create_quat(float *buffer)
    {
        return {
            *buffer,
            *(buffer + 1),
            *(buffer + 2),
            *(buffer + 3)};
    }

    Vec4 &Mat4::operator[](int col)
    {
        return cols[col];
    }

    Mat4 Mat4::operator*(Mat4 &other)
    {
        Mat4 result = {};

        //TODO: think about how to do this in a for loop

        // for (int i = 0; i < 4; i++)
        // {
        //     for (int j = 0; j < 4; j++)
        //     {
        //         result[i][j] += cols[j][i] * other[i][j];
        //     }
        // }
        result.ax = ax * other.ax + bx * other.ay + cx * other.az + dx * other.aw;
        result.ay = ay * other.ax + by * other.ay + cy * other.az + dy * other.aw;
        result.az = az * other.ax + bz * other.ay + cz * other.az + dz * other.aw;
        result.aw = aw * other.ax + bw * other.ay + cw * other.az + dw * other.aw;

        result.bx = ax * other.bx + bx * other.by + cx * other.bz + dx * other.bw;
        result.by = ay * other.bx + by * other.by + cy * other.bz + dy * other.bw;
        result.bz = az * other.bx + bz * other.by + cz * other.bz + dz * other.bw;
        result.bw = aw * other.bx + bw * other.by + cw * other.bz + dw * other.bw;

        result.cx = ax * other.cx + bx * other.cy + cx * other.cz + dx * other.cw;
        result.cy = ay * other.cx + by * other.cy + cy * other.cz + dy * other.cw;
        result.cz = az * other.cx + bz * other.cy + cz * other.cz + dz * other.cw;
        result.cw = aw * other.cx + bw * other.cy + cw * other.cz + dw * other.cw;

        result.dx = ax * other.dx + bx * other.dy + cx * other.dz + dx * other.dw;
        result.dy = ay * other.dx + by * other.dy + cy * other.dz + dy * other.dw;
        result.dz = az * other.dx + bz * other.dy + cz * other.dz + dz * other.dw;
        result.dw = aw * other.dx + bw * other.dy + cw * other.dz + dw * other.dw;

        return result;
    }

    Mat4 create_mat4(float initValue)
    {
        Mat4 mat = {};

        mat[0][0] = initValue;
        mat[1][1] = initValue;
        mat[2][2] = initValue;
        mat[3][3] = initValue;

        return mat;
    }

    Mat4 create_mat4(float *buffer)
    {
        return {
            *buffer,
            *(buffer + 1),
            *(buffer + 2),
            *(buffer + 3),
            *(buffer + 4),
            *(buffer + 5),
            *(buffer + 6),
            *(buffer + 7),
            *(buffer + 8),
            *(buffer + 9),
            *(buffer + 10),
            *(buffer + 11),
            *(buffer + 12),
            *(buffer + 13),
            *(buffer + 14),
            *(buffer + 15)};
    }

    Mat4 translate(Mat4 &m, Vec3 &v)
    {
        Mat4 result = create_mat4(1.0f);
        result[3] = m[0] * v[0] + m[1] * v[1] + m[2] * v[2] + m[3];
        return result;
    }

    Mat4 look_at(Vec3 &eye, Vec3 &target, Vec3 &up)
    {
        Vec3 zaxis = normalize(target - eye);
        Vec3 xaxis = normalize(cross(zaxis, up));
        Vec3 yaxis = cross(xaxis, zaxis);

        Mat4 result = create_mat4(1.0f);
        result[0][0] = xaxis.x;
        result[1][0] = xaxis.y;
        result[2][0] = xaxis.z;
        result[0][1] = yaxis.x;
        result[1][1] = yaxis.y;
        result[2][1] = yaxis.z;
        result[0][2] = -zaxis.x;
        result[1][2] = -zaxis.y;
        result[2][2] = -zaxis.z;
        result[3][0] = -dot(xaxis, eye);
        result[3][1] = -dot(yaxis, eye);
        result[3][2] = dot(zaxis, eye);

        return result;
    }

    bool point_in_rect(const Vec2 &point, const Rect &rect)
    {
        return (point.x >= rect.left &&
                point.x <= rect.left + rect.sizeX &&
                point.y >= rect.top &&
                point.y <= rect.top + rect.sizeY);
    }

    bool rect_collision(Rect &a, Rect &b)
    {
        return (point_in_rect(Vec2{a.left, a.top}, b) ||
                point_in_rect(Vec2{a.left + a.sizeX, a.top}, b) ||
                point_in_rect(Vec2{a.left, a.top + a.sizeY}, b) ||
                point_in_rect(Vec2{a.left + a.sizeX, a.top + a.sizeY}, b));
    }

    bool point_in_circle(Vec2 point, Vec2 origin, float r)
    {
        Vec2 pointToOrigen = origin - point;
        float lengthSquared = length_squared(pointToOrigen);
        return lengthSquared <= r * r;
    }

    bool circle_collision(Circle *circleA, Circle *circleB)
    {
        return circle_collision(circleA->radius, circleA->origin, circleB->radius, circleB->origin);
    }

    bool circle_collision(Circle circleA, Circle circleB)
    {
        return circle_collision(&circleA, &circleB);
    }

    bool circle_collision(float rA, Vec2 originA, float rB, Vec2 originB)
    {
        float r12Squared = (rA + rB) * (rA + rB);
        Vec2 origin1ToOrigin2 = originA - originB;

        float squaredLenght = length_squared(origin1ToOrigin2);

        if (squaredLenght > r12Squared)
        {
            return false;
        }

        return true;
    }

    bool circle_collision(float rA, Vec2 originA, Circle circle)
    {
        return circle_collision(rA, originA, circle.radius, circle.origin);
    }

    float square_root(float value)
    {
        float epsilon = 0.00001;

        float estimation = value;

        while ((estimation - (estimation + (value / estimation)) / 2) > epsilon)
        {
            estimation = (estimation + (value / estimation)) / 2;
        }

        return estimation;
    }

    float Q_rsqrt(float number)
    {
        long i;
        float x2, y;
        const float threehalfs = 1.5F;

        x2 = number * 0.5F;
        y = number;
        i = *(long *)&y;           // evil floating point bit level hacking
        i = 0x5f3759df - (i >> 1); // what the fuck?
        y = *(float *)&i;
        y = y * (threehalfs - (x2 * y * y)); // 1st iteration
                                             //	y  = y * ( threehalfs - ( x2 * y * y ) );   // 2nd iteration, this can be removed

        return y;
    }
} // namespace Cakez