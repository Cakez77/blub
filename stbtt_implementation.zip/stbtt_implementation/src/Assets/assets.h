#pragma once

#include "defines.h"
#include "memory.h"
#include "Renderer/render_types.h"
#include "Util/util.h"

namespace Cakez
{
    uint32_t constexpr MAX_TEXTURES = 100;
    uint32_t constexpr MAX_HEROES = 100;
    uint32_t constexpr MAX_ENEMIES = 100;

    struct Assets
    {
        //TODO: Counts will be removed?
        uint32_t animationCount;
        uint32_t spriteCount;
        uint32_t heroCount;
        uint32_t enemyCount;

        Texture sprites[MAX_TEXTURES];
        Asset assets[ASSET_COUNT];
        Entity heroes[MAX_HEROES];
        Entity enemies[MAX_ENEMIES];
    };

    Asset *get_asset(Assets *assets, AssetTypeID id);
    Texture *get_asset_textures(Assets *assets, AssetTypeID id);
    Entity *get_asset_entity(Assets *assets, AssetTypeID id);

    void reload_heroes(Assets* assets);
} // namespace Cakez
