#pragma once

#include <vulkan/vulkan.h>

#include "vk_types.h"
#include "vk_context.h"

namespace Cakez
{
    void vk_allocate_buffer(
        VkContext* vkcontext,
        VkBuffer *buffer,
        VkDeviceMemory *memory,
        const uint32_t size,
        const VkBufferUsageFlags bufferUsage,
        VkMemoryPropertyFlagBits memoryProperties,
        void *data = 0,
        void **mapped = 0);

    void vk_copy_to_buffer(
        VkContext* vkcontext,
        VkBuffer *buffer,
        VkDeviceMemory *memory,
        void *data,
        const uint32_t size,
        const uint32_t offset = 0);

    void vk_allocate_image(
        VkContext *vkcontext,
        VkImage *image,
        VkDeviceMemory *memory,
        VkFormat imageFormat,
        VkImageUsageFlags imageUsage,
        VkExtent3D extent,
        uint32_t levels = 1u,
        uint32_t layers = 1u);

    void vk_copy_to_image(
        VkContext *vkcontext,
        VkImage *image,
        VkImageLayout *layout,
        VkBufferImageCopy *pCopyRegions,
        uint32_t regionCount,
        const void *data,
        uint32_t size,
        uint32_t levels = 1u,
        uint32_t layers = 1u);

} // namespace Cakez
