#include "assets.h"

#include "defines.h"
#include "memory.h"
#include "platform.h"
#include "Util/util.h"
#include "Game/game_state.h"

#include "Renderer/Vulkan/vk_renderer.h"

namespace Cakez
{
    //##########################################################################
    //                      Internal data
    //##########################################################################

    //##########################################################################
    //                      Internal functions
    //##########################################################################
    internal Texture *debug_add_texture(VkContext *vkcontext, Assets *assets, const char *texturePath)
    {
        if (assets->spriteCount <= MAX_TEXTURES)
        {
            assets->sprites[assets->spriteCount] = vk_create_texture(vkcontext, texturePath);
            assets->spriteCount++;
            return &assets->sprites[assets->spriteCount - 1];
        }
        else
        {
            CAKEZ_ASSERT(false, "No more space for textures");
            return 0;
        }
    }

    internal Entity *debug_add_hero(Assets *assets)
    {
    }

    //TODO: Will be done elsewhere later
    internal bool load_assets(GameMemory *gameMemory, Assets *assets, VkContext *vkcontext)
    {
        // Adding the knight sprite
        {
            assets->assets[ASSET_KNIGHT].startingIndex = assets->spriteCount;
            assets->assets[ASSET_KNIGHT].count = 1;
            assets->assets[ASSET_KNIGHT].type = ASSET_TYPE_SPRITE;
            debug_add_texture(vkcontext, assets, "assets/textures/knight_idle_02.dds");
        }

        // Adding the heal Icon
        {
            assets->assets[ASSET_HEAL_ICON].startingIndex = assets->spriteCount;
            assets->assets[ASSET_HEAL_ICON].count = 1;
            assets->assets[ASSET_HEAL_ICON].type = ASSET_TYPE_SPRITE;
            debug_add_texture(vkcontext, assets, "assets/textures/heal_icon.dds");
        }

        // Adding the scroll sprite
        {
            assets->assets[ASSET_SCROLL].startingIndex = assets->spriteCount;
            assets->assets[ASSET_SCROLL].count = 1;
            assets->assets[ASSET_SCROLL].type = ASSET_TYPE_SPRITE;
            debug_add_texture(vkcontext, assets, "assets/textures/scroll.dds");
        }

        // Adding the bottom bar
        {
            assets->assets[ASSET_HERO_BAR].startingIndex = assets->spriteCount;
            assets->assets[ASSET_HERO_BAR].count = 1;
            assets->assets[ASSET_HERO_BAR].type = ASSET_TYPE_SPRITE;
            debug_add_texture(vkcontext, assets, "assets/textures/bottom_bar.dds");
        }

        //Adding button texture
        {
            assets->assets[ASSET_BUTTON_TEXTURE].type = ASSET_TYPE_SPRITE;
            assets->assets[ASSET_BUTTON_TEXTURE].count = 1;
            assets->assets[ASSET_BUTTON_TEXTURE].startingIndex = assets->spriteCount;

            debug_add_texture(vkcontext, assets, "assets/textures/button.dds");
        }

        // Adding the knight run animation
        {
            assets->assets[ASSET_KNIGHT_RUN].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_KNIGHT_RUN].startingIndex = assets->spriteCount;
            assets->assets[ASSET_KNIGHT_RUN].count = 5;

            debug_add_texture(vkcontext, assets, "assets/textures/knight_run_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/knight_run_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/knight_run_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/knight_run_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/knight_run_05.dds");
        }

        // Adding the knight idle animation
        {
            assets->assets[ASSET_KNIGHT_IDLE].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_KNIGHT_IDLE].startingIndex = assets->spriteCount;
            assets->assets[ASSET_KNIGHT_IDLE].count = 2;

            debug_add_texture(vkcontext, assets, "assets/textures/knight_idle_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/knight_idle_02.dds");
        }

        // Adding the knight attack animation
        {
            assets->assets[ASSET_KNIGHT_ATTACK].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_KNIGHT_ATTACK].startingIndex = assets->spriteCount;
            assets->assets[ASSET_KNIGHT_ATTACK].count = 1;

            debug_add_texture(vkcontext, assets, "assets/textures/knight_attack_01.dds");
        }

        // Adding the background image
        {

            assets->assets[ASSET_BACKGROUND].type = ASSET_TYPE_SPRITE;
            assets->assets[ASSET_BACKGROUND].startingIndex = assets->spriteCount;
            assets->assets[ASSET_BACKGROUND].count = 1;

            debug_add_texture(vkcontext, assets, "assets/textures/background.dds");
        }

        //Adding white rect
        {
            assets->assets[ASSET_WHITE].type = ASSET_TYPE_SPRITE;
            assets->assets[ASSET_WHITE].startingIndex = assets->spriteCount;
            assets->assets[ASSET_WHITE].count = 2;

            debug_add_texture(vkcontext, assets, "white");
            debug_add_texture(vkcontext, assets, "white");
        }

        //Adding ice shot
        {
            assets->assets[ASSET_ICE_SHOT].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_ICE_SHOT].startingIndex = assets->spriteCount;
            assets->assets[ASSET_ICE_SHOT].count = 4;

            debug_add_texture(vkcontext, assets, "assets/textures/ice_shot_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ice_shot_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ice_shot_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ice_shot_04.dds");
        }

        //Adding skelly Attack
        {
            assets->assets[ASSET_SKELLY_ATTACK].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_SKELLY_ATTACK].startingIndex = assets->spriteCount;
            assets->assets[ASSET_SKELLY_ATTACK].count = 3;

            debug_add_texture(vkcontext, assets, "assets/textures/skelly_attack_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_attack_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_attack_03.dds");
        }

        //Adding skelly Attack
        {
            assets->assets[ASSET_SKELLY_ATTACK].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_SKELLY_ATTACK].startingIndex = assets->spriteCount;
            assets->assets[ASSET_SKELLY_ATTACK].count = 2;

            debug_add_texture(vkcontext, assets, "assets/textures/skelly_attack_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_attack_02.dds");
        }

        //Adding skelly shield Attack
        {
            assets->assets[ASSET_SKELLY_SHIELD_ATTACK].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_SKELLY_SHIELD_ATTACK].startingIndex = assets->spriteCount;
            assets->assets[ASSET_SKELLY_SHIELD_ATTACK].count = 5;

            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_attack_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_attack_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_attack_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_attack_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_attack_05.dds");
        }

        //Adding skelly shield Attack
        {
            assets->assets[ASSET_SKELLY_SHIELD_WALK].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_SKELLY_SHIELD_WALK].startingIndex = assets->spriteCount;
            assets->assets[ASSET_SKELLY_SHIELD_WALK].count = 4;

            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_walk_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_walk_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_walk_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/skelly_shield_walk_04.dds");
        }

        //Adding ranger running
        {
            assets->assets[ASSET_RANGER_IDLE].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_RANGER_IDLE].startingIndex = assets->spriteCount;
            assets->assets[ASSET_RANGER_IDLE].count = 6;

            debug_add_texture(vkcontext, assets, "assets/textures/ranger_idle_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_idle_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_idle_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_idle_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_idle_05.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_idle_06.dds");
        }

        //Adding ranger running
        {
            assets->assets[ASSET_RANGER_RUN].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_RANGER_RUN].startingIndex = assets->spriteCount;
            assets->assets[ASSET_RANGER_RUN].count = 8;

            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_05.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_06.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_07.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_run_08.dds");
        }

        //Adding ranger attack
        {
            assets->assets[ASSET_RANGER_ATTACK].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_RANGER_ATTACK].startingIndex = assets->spriteCount;
            assets->assets[ASSET_RANGER_ATTACK].count = 7;

            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_05.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_06.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/ranger_attack_07.dds");
        }

        //Adding fire explosion
        {
            assets->assets[ASSET_EXPLOSION].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_EXPLOSION].startingIndex = assets->spriteCount;
            assets->assets[ASSET_EXPLOSION].count = 6;

            debug_add_texture(vkcontext, assets, "assets/textures/explosion_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/explosion_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/explosion_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/explosion_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/explosion_05.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/explosion_06.dds");
        }

        //Adding Healer Idle
        {
            assets->assets[ASSET_HEALER_IDLE].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_HEALER_IDLE].startingIndex = assets->spriteCount;
            assets->assets[ASSET_HEALER_IDLE].count = 6;

            debug_add_texture(vkcontext, assets, "assets/textures/healer_idle_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/healer_idle_02.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/healer_idle_03.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/healer_idle_04.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/healer_idle_05.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/healer_idle_06.dds");
        }

        //Adding Healer Heal
        {
            assets->assets[ASSET_HEALER_HEAL].type = ASSET_TYPE_ANIMATION;
            assets->assets[ASSET_HEALER_HEAL].startingIndex = assets->spriteCount;
            assets->assets[ASSET_HEALER_HEAL].count = 2;

            debug_add_texture(vkcontext, assets, "assets/textures/healer_heal_01.dds");
            debug_add_texture(vkcontext, assets, "assets/textures/healer_heal_02.dds");
        }
        

        // Loading the heroes
        {
            reload_heroes(assets);
        }

        return true;
    }

    //##########################################################################
    //                  Implementations of exposed asset functions
    //##########################################################################

    Asset *get_asset(Assets *assets, AssetTypeID id)
    {
        if (id)
        {
            return &assets->assets[id];
        }
        else
        {
            // CAKEZ_WARN("No asset with id %d found", id);
            return 0;
        }
    }

    Texture *get_asset_textures(Assets *assets, AssetTypeID id)
    {
        Texture *textures = 0;
        Asset *asset = get_asset(assets, id);
        if (asset)
        {
            textures = &assets->sprites[asset->startingIndex];
        }

        return textures;
    }

    Entity *get_asset_entity(Assets *assets, AssetTypeID id)
    {
        Entity *entity = 0;
        Asset *asset = get_asset(assets, id);
        if (asset)
        {
            if (asset->type == ASSET_TYPE_HERO ||
                asset->type == ASSET_TYPE_ENEMY)
            {
                entity = &assets->heroes[asset->startingIndex];
            }
            else
            {
                CAKEZ_ASSERT(0, "Asset type: %d, is neither of type: %d, or: %d",
                             id, ASSET_TYPE_HERO, ASSET_TYPE_ENEMY);
            }
        }

        return entity;
    }

    void reload_heroes(Assets *assets)
    {
        assets->heroCount = 0;
        char *fileName = "heroes.txt";
        if (platform_file_exists(fileName))
        {
            uint32_t bytesRead;
            Entity *heroes = (Entity *)platform_read_file(fileName, bytesRead);

            uint32_t heroCount = bytesRead / sizeof(Entity);

            if (heroes)
            {
                if (heroCount < MAX_HEROES)
                {
                    for (uint32_t i = 0; i < heroCount; i++)
                    {
                        uint32_t assetIdx = ASSET_HERO_KNIGHT + i;
                        assets->assets[assetIdx].type = ASSET_TYPE_HERO;
                        assets->assets[assetIdx].startingIndex = i;
                        assets->assets[assetIdx].count = 1;

                        assets->heroes[i] = heroes[i];
                        assets->heroCount++;
                    }
                }
                else
                {
                    CAKEZ_ASSERT(0, "Reached maximum amount of heroes");
                }
            }
            else
            {
                CAKEZ_ASSERT(0, "Could not read file %s", fileName);
            }
        }
    }

} // namespace Cakez
