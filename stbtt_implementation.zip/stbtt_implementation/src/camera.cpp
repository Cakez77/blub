#include "camera.h"

#include "my_math.h"

//TODO: Used for tan, write your own
#include <cmath>

namespace Cakez
{
    void calculate_inverse_projection_matrix(Camera *camera, float aspectRatio, float fov)
    {
        // Projection matrix data to create an infinite reverse projection matrix
        float const zNear = 0.1f;
        float const aspect = aspectRatio;
        float const range = tan(fov / 2.0f);
        float const left = -range * aspect;
        float const right = range * aspect;
        float const bottom = -range;
        float const top = range;

        camera->proj = create_mat4(0.0f);
        camera->proj[0][0] = 2.0f / (right - left);
        camera->proj[1][1] = 2.0f / (top - bottom);
        camera->proj[2][3] = -1.0f;
        camera->proj[3][2] = zNear;
        camera->proj[1][1] *= -1; // might not need it, this is vulkan specific, inverse y
    }

    void calculate_view_matrix(Camera *camera)
    {
        camera->view = look_at(
            camera->pos,
            camera->pos + camera->front,
            camera->up);
    }
} //namespace Cakez