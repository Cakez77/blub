#pragma once

#include "logger.h"

namespace Cakez
{
    class Instrumentor
    {
    public:
        Instrumentor(const char *msg);
        ~Instrumentor();

    private:
        const char *msg;
    };

#define PROFILE_FUNCTION(msg) Instrumentor i = (msg)
} // namespace Cakez
