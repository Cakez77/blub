#pragma once

#include "my_math.h"

namespace Cakez
{
    struct Camera
    {
        Vec3 pos;
        Vec3 up;
        Vec3 front;
        Mat4 view;
        Mat4 proj;
        Mat4 viewProj;
    };

    void calculate_inverse_projection_matrix(Camera *camera, float aspectRatio, float fov = 70.0f);
    void calculate_view_matrix(Camera *camera);

} // namespace Cakez