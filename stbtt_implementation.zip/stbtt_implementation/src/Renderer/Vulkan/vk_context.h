#pragma once

#include "vk_types.h"
#include "Assets/assets.h"
#include "Game/game_state.h"

namespace Cakez
{
    uint32_t constexpr MAX_RENDER_COMMANDS = 2000;
    uint32_t constexpr MAX_TRANSFORMS = MAX_RENDER_COMMANDS;
    uint32_t constexpr MAX_MATERIALS = 20;

    struct ProgramDescriptor
    {
        uint32_t programIdx;
        Buffer buffer;
        std::vector<SamplerToTexture> samplerNamesToTextures;
        std::vector<VkDescriptorSet> sets;
    };

    struct RenderCommand
    {
        uint32_t descriptorIdx;
        Mesh *mesh;
        PushData pushData;
        uint32_t layer;
        uint32_t instanceCount;
    };

    struct GlyphCache
    {
        uint32_t fontSize;
        int largestYOffset;
        uint32_t glyphPadding;
        std::vector<Glyph> glyphs;
        Texture glyphAtlas;
        Buffer glpyhUBO;
    };

    /**
     * The VkContext is all the data that a Vulkan renderer needs in order to
     * render. 
     */
    struct VkContext
    {
        //TODO: Add options structure
        bool vSync;

        VkInstance instance;
#ifdef DEBUG
        VkDebugUtilsMessengerEXT debugMessenger;
#endif //DEBUG

        VkSurfaceKHR surface;
        int graphicsIdx, transferIdx;

        VkDevice device;
        VkQueryPool queryPool;
        VkPhysicalDevice gpu;
        VkPhysicalDeviceProperties gpuProps;
        // TODO: Remove the graphics queue
        VkQueue graphicsQueue;
        VkQueue transferQueue;
        VkRenderPass renderPass;
        VkCommandPool commandPool;
        VkDescriptorPool descPool;

        VkSwapchainKHR swapchain;
        std::vector<VkImage> swapchainImages;
        std::vector<VkImageView> swapchainImageViews;
        Image depthImage;
        std::vector<VkFramebuffer> framebuffers;
        std::vector<CPUAndGPUSync> frameSync;

        // staging buffer used to transfer data to device local memory
        Buffer stagingBuffer;

        // Vertex and indexOffset into the Vertex and Index buffers
        uint32_t vertexOffset;
        uint32_t indexOffset;

        // Offset into the transformStorageBuffer

        // Buffers
        Buffer vertexStorageBuffer;
        Buffer indexStorageBuffer;
        Buffer transformStorageBuffer;
        Buffer glyphTransformStorageBuffer;
        Buffer globalUniformBuffer;

        // Default texture, white
        Texture white;
        Texture testGlyph;

        // Fullscreen quad, used for sprite rendering
        Mesh quad;

        // Stores font information for drawing glyphs, only one fontCache atm
        GlyphCache glyphCache;

        // List of allocated Image's (Textures)
        std::vector<Image> images;

        // Used by the render loop
        std::vector<Program> programs;
        std::vector<ProgramDescriptor> programDescriptors;
        uint32_t currentFrame;
        uint32_t imageIndex;

        uint32_t renderCommandCount;
        RenderCommand renderCommands[MAX_RENDER_COMMANDS];
        
        uint32_t glyphTransformCount;
        GlyphTransform glyphTransforms[MAX_GLYPHS];

        uint32_t transformCount;
        Transform transforms[MAX_TRANSFORMS];

        VkExtent2D screenSize;

        uint32_t materialCount;
        Material materials[MAX_MATERIALS];

        //TODO: Remove
        double frameGPUBegin;
        double frameGPUEnd;
        double renderLoopBegin;
        double renderLoopEnd;
        double gpuTime;
        float entityLoop;
        float glyphLoop;
        float sortingRenderCommands;
        float fenceWaiting;
        float setupRender;
        float renderLoop;
        float endCommandBuffer;
        float queueSubmit;
        float present;

        float resetFence;
        float acquireImage;
        float restCommandBuffer;
        float beginCommandBuffer;
        float beginRenderPass;
    };

} // namespace Cakez