#include "bitmap.h"

#include <string>
#include <fstream>
#include <iostream>

namespace Cakez
{
    namespace Util
    {

        Color::Color()
            : r(0), g(0), b(0) {}

        Color::Color(unsigned char r, unsigned char g, unsigned char b)
            : r(r), g(g), b(b) {}

        Color::~Color() {}

        Bitmap::Bitmap(int width, int height)
            : _width(width), _height(height), _colors(std::vector<Color>(width * height)) {}

        Bitmap::~Bitmap() {}

        Color Bitmap::get_color(const int x, const int y) const
        {
            return _colors[y * _width + x];
        }

        void Bitmap::set_color(const Color color, const int x, const int y)
        {
            // bmp images have inverted Y coordinate
            _colors[((_height -1) - y) * _width + x].r = color.r;
            _colors[((_height -1) - y) * _width + x].g = color.g;
            _colors[((_height -1) - y) * _width + x].b = color.b;

            // _colors[y * _width + x].r = color.r;
            // _colors[y * _width + x].g = color.g;
            // _colors[y * _width + x].b = color.b;
        }

        int Bitmap::get_width() const
        {
            return _width;
        }

        int Bitmap::get_height() const
        {
            return _height;
        }

        void Bitmap::export_bmp(const char *path) const
        {
            std::ofstream f;
            f.open(path, std::ios::out | std::ios::binary);

            if (!f.is_open())
            {
                std::cout << "Could not open file!\n";
                return;
            }

            unsigned char bmpPad[3] = {0, 0, 0};
            const int paddingAmount = ((4 - (_width * 3) % 4) % 4);

            const int fileHeaderSize = 14;
            const int informationHeaderSize = 40;
            const int fileSize = fileHeaderSize + informationHeaderSize + _width * _height * 3 + paddingAmount * _height;

            unsigned char fileHeader[fileHeaderSize];

            // File type
            fileHeader[0] = 'B';
            fileHeader[1] = 'M';

            //File size
            fileHeader[2] = fileSize;
            fileHeader[3] = fileSize >> 8;
            fileHeader[4] = fileSize >> 16;
            fileHeader[5] = fileSize >> 24;

            // Reserved 1 (not used)
            fileHeader[6] = 0;
            fileHeader[7] = 0;

            // Reserved 2 (not used)
            fileHeader[8] = 0;
            fileHeader[9] = 0;

            // Pixel date offset
            fileHeader[10] = fileHeaderSize + informationHeaderSize;
            fileHeader[11] = 0;
            fileHeader[12] = 0;
            fileHeader[13] = 0;

            unsigned char informationHeader[informationHeaderSize];

            // Header size
            informationHeader[0] = informationHeaderSize;
            informationHeader[1] = 0;
            informationHeader[2] = 0;
            informationHeader[3] = 0;

            // Image width
            informationHeader[4] = _width;
            informationHeader[5] = _width >> 8;
            informationHeader[6] = _width >> 16;
            informationHeader[7] = _width >> 24;

            // Image height
            informationHeader[8] = _height;
            informationHeader[9] = _height >> 8;
            informationHeader[10] = _height >> 16;
            informationHeader[11] = _height >> 24;

            //Planes
            informationHeader[12] = 1;
            informationHeader[13] = 0;

            // Bist per pixel (RGB)
            informationHeader[14] = 24;
            informationHeader[15] = 0;

            // Compression (No compression)
            informationHeader[16] = 0;
            informationHeader[17] = 0;
            informationHeader[18] = 0;
            informationHeader[19] = 0;

            // Image Size (No compression)
            informationHeader[20] = 0;
            informationHeader[21] = 0;
            informationHeader[22] = 0;
            informationHeader[23] = 0;

            // X pixels per meter (Not specified)
            informationHeader[24] = 0;
            informationHeader[25] = 0;
            informationHeader[26] = 0;
            informationHeader[27] = 0;

            // Y pixels per meter (Not specified)
            informationHeader[28] = 0;
            informationHeader[29] = 0;
            informationHeader[30] = 0;
            informationHeader[31] = 0;

            // Total color (Color palette not used)
            informationHeader[32] = 0;
            informationHeader[33] = 0;
            informationHeader[34] = 0;
            informationHeader[35] = 0;

            // Important color (Generally ignored)
            informationHeader[36] = 0;
            informationHeader[37] = 0;
            informationHeader[38] = 0;
            informationHeader[39] = 0;

            f.write(reinterpret_cast<char *>(fileHeader), fileHeaderSize);
            f.write(reinterpret_cast<char *>(informationHeader), informationHeaderSize);

            for (int y = 0; y < _height; y++)
            {
                for (int x = 0; x < _width; x++)
                {
                    unsigned char r = get_color(x, y).r;
                    unsigned char g = get_color(x, y).g;
                    unsigned char b = get_color(x, y).b;

                    unsigned char color[] = {b, g, r};

                    f.write(reinterpret_cast<char *>(color), 3);
                }
                f.write(reinterpret_cast<char *>(bmpPad), paddingAmount);
            }

            f.close();

            std::cout << "File was created\n";
        }

    } // namespace Util
} // namespace Cakez
