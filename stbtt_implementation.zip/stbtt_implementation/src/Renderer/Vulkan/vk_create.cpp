#include "vk_create.h"

#ifdef WINDOWS_BUILD
#include <windows.h>
#include <vulkan/vulkan_win32.h>
#elif CAKEZ_PLATFORM_LINUX
#endif

#include "logger.h"
#include "Renderer/shader_util.h"
#include "Util/util.h"
#include "vk_initializers.h"
#include "vk_util.h"

#include <string>


namespace Cakez
{
    internal VkPipelineVertexInputStateCreateInfo vertexInput =
        vkinit::vertex_input_state_create_info();
    internal VkPipelineInputAssemblyStateCreateInfo inputAssembly =
        vkinit::input_assembly_create_info(VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST);
    internal VkViewport viewport =
        vkinit::viewport({0, 0});
    internal VkRect2D scissor = vkinit::scissor({0, 0});
    internal VkPipelineViewportStateCreateInfo viewportInfo =
        vkinit::viewport_state_create_info(viewport, scissor);
    internal VkPipelineRasterizationStateCreateInfo rasterizationInfo =
        vkinit::rasterization_state_create_info(VK_POLYGON_MODE_FILL);
    internal VkPipelineMultisampleStateCreateInfo multisampleInfo =
        vkinit::multisampling_state_create_info();
    internal VkPipelineColorBlendAttachmentState colorBlending =
        vkinit::color_blend_attachment_state();
    internal VkPipelineColorBlendStateCreateInfo colorblendInfo =
        vkinit::color_blend_state_crate_info(1, &colorBlending);
    internal VkPipelineDepthStencilStateCreateInfo depthStencilInfo =
        vkinit::depth_stencil_create_info(true, true, VK_COMPARE_OP_GREATER);

    internal VkDynamicState dynamicStates[] = {VK_DYNAMIC_STATE_VIEWPORT,
                                               VK_DYNAMIC_STATE_SCISSOR};
    internal VkPipelineDynamicStateCreateInfo dynamicState =
        vkinit::dynamic_state_create_info(
            dynamicStates,
            sizeof(dynamicStates) / sizeof(dynamicStates[0]));

    internal VKAPI_ATTR VkBool32 VKAPI_CALL debug_callback(
        VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
        VkDebugUtilsMessageTypeFlagsEXT messageType,
        const VkDebugUtilsMessengerCallbackDataEXT *pCallbackData,
        void *pUserData)
    {
        // CAKEZ_ASSERT(false, pCallbackData->pMessage);
        CAKEZ_WARN(pCallbackData->pMessage);
        return VK_FALSE;
    }

    VkInstance create_instance()
    {
        //TODO: Use higher API Version
        VkApplicationInfo appInfo = vkinit::application_info();
        appInfo.apiVersion = VK_API_VERSION_1_2;

        VkInstanceCreateInfo createInfo = vkinit::instance_create_info(appInfo);

        std::vector<const char *> extensions = {
            VK_KHR_SURFACE_EXTENSION_NAME,
#ifdef WINDOWS_BUILD
            VK_KHR_WIN32_SURFACE_EXTENSION_NAME,
#elif CAKEZ_PLATFORM_LINUX
#endif
#ifdef DEBUG
            VK_EXT_DEBUG_UTILS_EXTENSION_NAME
#endif
        };

        createInfo.ppEnabledExtensionNames = extensions.data();
        createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());

#ifdef DEBUG
        const char *layerNames[]{"VK_LAYER_KHRONOS_validation"};
        createInfo.ppEnabledLayerNames = layerNames;
        createInfo.enabledLayerCount = 1;

        VkDebugUtilsMessengerCreateInfoEXT debugInfo = vkinit::debug_utils_create_info(
            debug_callback,
            VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT |
                VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT,
            VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT |
                VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT);

        createInfo.pNext = &debugInfo;
#endif // DEBUG

        VkInstance instance = 0;
        VK_CHECK(vkCreateInstance(&createInfo, 0, &instance));

        return instance;
    }

    VkDebugUtilsMessengerEXT create_debug_messenger(VkInstance instance)
    {
        auto vkCreateDebugUtilsMessengerEXT = (PFN_vkCreateDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT");

        CAKEZ_ASSERT(vkCreateDebugUtilsMessengerEXT != nullptr, "Failed to load function vkCreateDebugUtilsMessengerEXT");

        VkDebugUtilsMessengerCreateInfoEXT debugInfo = vkinit::debug_utils_create_info(
            debug_callback,
            VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT |
                VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT,
            VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT |
                VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT);

        VkDebugUtilsMessengerEXT debugMessenger = 0;
        vkCreateDebugUtilsMessengerEXT(instance, &debugInfo, nullptr, &debugMessenger);
        return debugMessenger;
    }

    VkSurfaceKHR create_surface(VkInstance instance, const void *window)
    {
        VkSurfaceKHR surface = 0;

#ifdef WINDOWS_BUILD
        VkWin32SurfaceCreateInfoKHR surfaceCreateInfo = {};
        surfaceCreateInfo.sType = VK_STRUCTURE_TYPE_WIN32_SURFACE_CREATE_INFO_KHR;

        surfaceCreateInfo.hwnd = *(HWND *)window;
        surfaceCreateInfo.hinstance = GetModuleHandle(0);

        VK_CHECK(vkCreateWin32SurfaceKHR(instance, &surfaceCreateInfo, 0, &surface));
#endif
        return surface;
    }

    VkPhysicalDevice pick_gpu(VkInstance instance, VkSurfaceKHR surface, int *outGraphicsIdx, int *outTransferIdx)
    {
        uint32_t gpuCount = 0;
        vkEnumeratePhysicalDevices(instance, &gpuCount, 0);
        std::vector<VkPhysicalDevice> gpus(gpuCount);
        vkEnumeratePhysicalDevices(instance, &gpuCount, gpus.data());

        uint32_t highScore = 0;
        VkPhysicalDevice chosenGPU = 0;
        int graphicsIdx;
        int transferIdx;

        VkPhysicalDeviceProperties gpuProps;
        for (const auto &gpu : gpus)
        {
            uint32_t score = 0;

            // Evaluate queue family properties
            {
                graphicsIdx = -1;
                transferIdx = -1;

                uint32_t queueCount = 0;
                vkGetPhysicalDeviceQueueFamilyProperties(gpu, &queueCount, nullptr);

                std::vector<VkQueueFamilyProperties> familyProps(queueCount);
                vkGetPhysicalDeviceQueueFamilyProperties(gpu, &queueCount, familyProps.data());

                for (size_t i = 0; i < familyProps.size(); i++)
                {
                    if (familyProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)
                    {
                        graphicsIdx = i;
                    }

                    if (familyProps[i].queueFlags & VK_QUEUE_TRANSFER_BIT)
                    {
                        transferIdx = i;
                    }
                }

                VkBool32 presentSupport = VK_FALSE;
                vkGetPhysicalDeviceSurfaceSupportKHR(gpu, graphicsIdx, surface, &presentSupport);

                if (!presentSupport)
                    continue;

                if (graphicsIdx != transferIdx)
                    score += 1000;
            }

            // Evaluate extension support
            if (!device_supports_extension(gpu, VK_KHR_SWAPCHAIN_EXTENSION_NAME))
                continue;

            // Evaluate properties to pick the best one based on limits and being a discrete GPU
            {
                vkGetPhysicalDeviceProperties(gpu, &gpuProps);
                score += gpuProps.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU ? 1000 : 0;
                score += gpuProps.limits.maxImageDimension2D;
            }

            if (score > highScore)
            {
                chosenGPU = gpu;
                highScore = score;
                *outGraphicsIdx = graphicsIdx;
                *outTransferIdx = transferIdx;
            }
        }

        CAKEZ_ASSERT(chosenGPU != 0, "No suitable GPU found!");

        return chosenGPU;
    }

    bool device_supports_extension(VkPhysicalDevice gpu, const char *extensionName)
    {
        uint32_t extensionCount = 0;
        vkEnumerateDeviceExtensionProperties(gpu, nullptr, &extensionCount, nullptr);

        std::vector<VkExtensionProperties> extensions(extensionCount);
        vkEnumerateDeviceExtensionProperties(gpu, nullptr, &extensionCount, extensions.data());

        for (const auto &extension : extensions)
        {
            if (str_cmp(extension.extensionName, extensionName))
            {
                return true;
            }
        }

        return false;
    }

    VkDevice create_device(
        VkPhysicalDevice gpu,
        uint32_t transferIdx,
        uint32_t graphicsIdx,
        std::vector<const char *> extensions)
    {
        VkDevice device = 0;

        float queuePriority = 1.0f;
        std::vector<VkDeviceQueueCreateInfo> queueInfos{
            vkinit::device_queue_create_info(
                graphicsIdx,
                queuePriority)};

        if (graphicsIdx != transferIdx)
            queueInfos.push_back(
                vkinit::device_queue_create_info(
                    transferIdx,
                    queuePriority));

        VkPhysicalDeviceFeatures features = vkinit::device_features();
        VkDeviceCreateInfo createInfo = vkinit::device_info(
            extensions.data(),
            static_cast<uint32_t>(extensions.size()),
            queueInfos.data(),
            static_cast<uint32_t>(queueInfos.size()),
            features);

        VK_CHECK(vkCreateDevice(gpu, &createInfo, nullptr, &device));
        return device;
    }

    VkQueryPool create_query_pool(
        VkDevice device,
        uint32_t queryCount,
        VkQueryType queryType)
    {
        VkQueryPool queryPool;

        VkQueryPoolCreateInfo createInfo = vkinit::query_pool_info(queryType, queryCount);

        vkCreateQueryPool(
            device,
            &createInfo,
            0,
            &queryPool);

        return queryPool;
    }

    VkSwapchainKHR create_swapchain(
        VkDevice device,
        VkPhysicalDevice gpu,
        VkSurfaceKHR surface,
        std::vector<VkImage> &images,
        std::vector<VkImageView> &imageViews,
        bool vSync)
    {

        VkSwapchainKHR swapchain = 0;

        uint32_t count;
        VkSurfaceCapabilitiesKHR surfaceCaps;
        std::vector<VkSurfaceFormatKHR> surfaceFormats;

        VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(gpu, surface, &surfaceCaps));
        VK_CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(gpu, surface, &count, nullptr));
        surfaceFormats.resize(count);
        VK_CHECK(vkGetPhysicalDeviceSurfaceFormatsKHR(gpu, surface, &count, surfaceFormats.data()));

        count = surfaceCaps.minImageCount + 1;
        count > surfaceCaps.maxImageCount ? count -= 1 : count;

        VkSwapchainCreateInfoKHR swapchainInfo = {};
        swapchainInfo.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
        swapchainInfo.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        swapchainInfo.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        swapchainInfo.presentMode = vSync ? VK_PRESENT_MODE_FIFO_KHR : VK_PRESENT_MODE_IMMEDIATE_KHR;
        swapchainInfo.surface = surface;
        swapchainInfo.imageArrayLayers = 1;
        swapchainInfo.minImageCount = count;
        swapchainInfo.imageExtent = surfaceCaps.currentExtent;
        swapchainInfo.preTransform = surfaceCaps.currentTransform;

        for (const auto format : surfaceFormats)
        {
            if (format.format == VK_FORMAT_B8G8R8A8_SRGB) // Hardcoded aswell, so it can be used in the render pass
            {
                swapchainInfo.imageFormat = format.format;
                swapchainInfo.imageColorSpace = format.colorSpace;
            }
        }

        VK_CHECK(vkCreateSwapchainKHR(device, &swapchainInfo, nullptr, &swapchain));

        VK_CHECK(vkGetSwapchainImagesKHR(device, swapchain, &count, nullptr));
        images.resize(count); // resize to swapchain image count
        imageViews.resize(count);
        VK_CHECK(vkGetSwapchainImagesKHR(device, swapchain, &count, images.data()));

        VkImageViewCreateInfo viewInfo = vkinit::image_view_create_info(); // Uses default format VK_FORMAT_B8G8R8A8_SRGB

        for (size_t i = 0; i < imageViews.size(); i++)
        {
            viewInfo.image = images[i];

            VK_CHECK(vkCreateImageView(device, &viewInfo, nullptr, &imageViews[i]));
        }

        return swapchain;
    }

    // TODO: Test what the default values are and use them
    VkPipeline create_pipeline(
        VkDevice device,
        VkRenderPass renderPass,
        VkPipelineLayout layout,
        VkPipelineShaderStageCreateInfo *pShaderStages,
        uint32_t stageCount,
        VkBool32 blendEnable,
        VkBlendOp colorBlendOp,
        VkBlendFactor srcColorBlendFactor,
        VkBlendFactor dstColorBlendFactor,
        VkBool32 depthWriteEnable,
        VkPrimitiveTopology topology)
    {
        VkPipeline pipeline = 0;

        // Topology
        {
            inputAssembly.topology = topology;
        }

        // Depth
        {
            depthStencilInfo.depthWriteEnable = depthWriteEnable;
        }

        // Color Blending
        {
            colorBlending.blendEnable = blendEnable;
            colorBlending.colorBlendOp = colorBlendOp;
            colorBlending.srcColorBlendFactor = srcColorBlendFactor;
            colorBlending.dstColorBlendFactor = dstColorBlendFactor;
            colorBlending.alphaBlendOp = colorBlendOp;
            colorBlending.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
            colorBlending.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;

            if (blendEnable)
                depthStencilInfo.depthWriteEnable = VK_FALSE;
        }

        VkGraphicsPipelineCreateInfo createInfo = {};
        createInfo.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
        createInfo.stageCount = stageCount;
        createInfo.pStages = pShaderStages;
        createInfo.pVertexInputState = &vertexInput;
        createInfo.pInputAssemblyState = &inputAssembly;
        createInfo.pViewportState = &viewportInfo;
        createInfo.pRasterizationState = &rasterizationInfo;
        createInfo.pMultisampleState = &multisampleInfo;
        createInfo.pColorBlendState = &colorblendInfo;
        createInfo.pDepthStencilState = &depthStencilInfo;
        createInfo.pDynamicState = &dynamicState;
        createInfo.layout = layout;
        createInfo.renderPass = renderPass;
        createInfo.subpass = 0;
        createInfo.basePipelineHandle = VK_NULL_HANDLE;

        VK_CHECK(vkCreateGraphicsPipelines(
            device,
            0,
            1,
            &createInfo,
            0,
            &pipeline));

        return pipeline;
    }

    VkShaderModule create_shader_module(
        VkDevice device,
        uint32_t *code,
        uint32_t size)
    {
        VkShaderModule module = 0;

        VkShaderModuleCreateInfo createInfo = {VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        createInfo.codeSize = sizeof(uint32_t) * size; // For some reason this is in bytes
        createInfo.pCode = code;

        VK_CHECK(vkCreateShaderModule(
            device,
            &createInfo,
            0,
            &module));

        return module;
    }
} // namespace Cakez
