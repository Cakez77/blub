#include "dds_loader.h"

#include "logger.h"
#include "platform.h"

namespace Cakez
{
    bool load_dds_file(const char *fileName, DDSFile &ddsFile)
    {
        uint32_t length = 0;
        ddsFile.data = platform_read_file(fileName, length);

        if (length == 0)
        {
            CAKEZ_ASSERT(length > 0, "Failed loading texture file %s", fileName);
            return false;
        }

        // Create DDSFile

        // Parse the header
        {
            uint32_t offset = 0;

            ddsFile.magic[0] = ddsFile.data[0];
            ddsFile.magic[1] = ddsFile.data[1];
            ddsFile.magic[2] = ddsFile.data[2];
            ddsFile.magic[3] = ddsFile.data[3];

            offset += 4;

            ddsFile.header = (DDSHeader *)(ddsFile.data + offset);

            CAKEZ_ASSERT(
                (ddsFile.header->Width & (ddsFile.header->Width - 1)) == 0,
                "Texture %s Width has to be a multiple of 2", fileName);

            CAKEZ_ASSERT(
                (ddsFile.header->Height & (ddsFile.header->Height - 1)) == 0,
                "Texture %s Height has to be a multiple of 2", fileName);

            offset += sizeof(DDSHeader);

            ddsFile.levels = new DDSMipLevel[ddsFile.header->MipLevelCount];

            uint32_t textureSize = 0;

            // Calculate the layers
            {
                for (size_t i = 0; i < ddsFile.header->MipLevelCount; i++)
                {
                    uint32_t width = ddsFile.header->Width >> i;
                    uint32_t height = ddsFile.header->Height >> i;
                    uint32_t blockWidth = (ddsFile.header->Width / 4) >> i;
                    uint32_t blockHeight = (ddsFile.header->Height / 4) >> i;

                    if (blockWidth < 1)
                        blockWidth = 1;

                    if (blockHeight < 1)
                        blockHeight = 1;

                    if (width < 1)
                        width = 1;

                    if (height < 1)
                        height = 1;

                    uint32_t byteOffset = textureSize;
                    uint32_t levelSize = blockWidth * blockHeight * 8;
                    textureSize += levelSize;

                    ddsFile.levels[i] = {width, height, byteOffset};
                }
            }

            if (textureSize + offset != length)
            {
                CAKEZ_ASSERT(textureSize + offset == length, "Size missmatch");
                return false;
            }

            ddsFile.textureSize = textureSize;
            ddsFile.textureData = (ddsFile.data + offset);
        }

        return true;
    }

    void delete_dds_file(DDSFile &ddsFile)
    {
        delete ddsFile.data;
    }
} // namespace Cakez
