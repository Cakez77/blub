#pragma once

#include "gltf.h"

#include "Renderer/render_types.h"

namespace Cakez
{
	namespace Util
	{
		GLTF_Metadata load_gltf_scene(const char *sceneName);
		GLTF_Metadata load_gltf_mesh(const char *meshPath);
		void save_gltf_scene(const char *scenePath);
		void load_mesh(
			char *meshPath,
			std::vector<Vertex> &vertices,
			std::vector<uint32_t> &indices);
	} // namespace Util
} // namespace Cakez