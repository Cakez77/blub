#pragma once

#include <vector>

namespace Cakez
{
    namespace Util
    {

        struct Color
        {
            unsigned char r, g, b;

            Color();
            Color(unsigned char r, unsigned char g, unsigned char b);
            ~Color();
        };

        class Bitmap
        {
        public:
            Bitmap(int width, int height);
            ~Bitmap();

            Color get_color(const int x, const int y) const;
            void set_color(const Color color, const int x, const int y);

            int get_width() const;
            int get_height() const;

            void export_bmp(const char *path) const;

        private:
            std::vector<Color> _colors;
            int _width;
            int _height;
        };
    } // namespace Util

} // namespace Cakez
