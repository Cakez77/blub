#include "vk_util.h"

#include "logger.h"
#include "vk_initializers.h"

namespace Cakez
{
    internal uint32_t vk_find_memory_type(
        VkPhysicalDevice gpu,
        uint32_t memoryTypeBits,
        VkMemoryPropertyFlags properties)
    {
        VkPhysicalDeviceMemoryProperties memProps;
        vkGetPhysicalDeviceMemoryProperties(gpu, &memProps);

        for (uint32_t i = 0; i < memProps.memoryTypeCount; i++)
        {
            if (memoryTypeBits & (1 << i) && (memProps.memoryTypes[i].propertyFlags & properties) == properties)
            {
                return i;
            }
        }

        CAKEZ_ASSERT(false, "Failed to find suitable memory tpye: %d", memoryTypeBits);
        return 0;
    }

    void vk_allocate_buffer(
        VkContext *vkcontext,
        VkBuffer *buffer,
        VkDeviceMemory *memory,
        const uint32_t size,
        const VkBufferUsageFlags bufferUsage,
        VkMemoryPropertyFlagBits memoryProperties,
        void *data,
        void **mapped)
    {
        VkBufferCreateInfo bufferInfo = vkinit::buffer_create_info(
            bufferUsage,
            size);

        vkCreateBuffer(
            vkcontext->device,
            &bufferInfo,
            0,
            buffer);

        VkMemoryRequirements memoryRequirements;
        vkGetBufferMemoryRequirements(
            vkcontext->device,
            *buffer,
            &memoryRequirements);

        // Allocate and bind buffer memory, will be done by the allocater later
        //TODO: This will be done by an allocater later and we will just get memory back
        {
            VkMemoryAllocateInfo allocInfo = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
            allocInfo.allocationSize = memoryRequirements.size;
            allocInfo.memoryTypeIndex = vk_find_memory_type(
                vkcontext->gpu,
                memoryRequirements.memoryTypeBits,
                memoryProperties);

            VK_CHECK(vkAllocateMemory(
                vkcontext->device, &allocInfo, 0, memory));

            VK_CHECK(vkBindBufferMemory(
                vkcontext->device, *buffer, *memory, 0));

            if (mapped && (memoryProperties & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT))
            {
                VK_CHECK(vkMapMemory(
                    vkcontext->device,
                    *memory,
                    0,
                    VK_WHOLE_SIZE,
                    0,
                    mapped));
            }
        }

        if (data == 0 || data == nullptr)
            return;

        vk_copy_to_buffer(vkcontext, buffer, memory, data, size);
    }

    void vk_copy_to_buffer(
        VkContext *vkcontext,
        VkBuffer *buffer,
        VkDeviceMemory *memory,
        void *data,
        const uint32_t size,
        const uint32_t offset)
    {
        CAKEZ_ASSERT(
            vkcontext->stagingBuffer.size > size,
            "Staging buffer is too small");

        memcpy(vkcontext->stagingBuffer.mapped, data, size);

        // Flush memory of the staging buffer
        {
            VkMappedMemoryRange memoryRange = {VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};
            memoryRange.size = VK_WHOLE_SIZE;
            memoryRange.offset = 0;
            memoryRange.memory = vkcontext->stagingBuffer.memory;

            vkFlushMappedMemoryRanges(
                vkcontext->device, 1, &memoryRange);
        }

        VkCommandBuffer copyCmd;

        VkCommandBufferAllocateInfo cmdAlloc = vkinit::command_buffer_allocate_info(
            vkcontext->commandPool);

        VK_CHECK(vkAllocateCommandBuffers(vkcontext->device,
                                          &cmdAlloc,
                                          &copyCmd));

        VkCommandBufferBeginInfo cmdBeginInfo = vkinit::command_buffer_begin_info(
            VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT);

        VK_CHECK(vkBeginCommandBuffer(copyCmd, &cmdBeginInfo));

        // Copy the data from the staging buffer to the vertex buffer
        // TODO: This copy can be done using the renderCMD if proper barriers are set
        {
            VkBufferCopy copyRegion = {};
            copyRegion.size = size;
            copyRegion.srcOffset = 0;
            copyRegion.dstOffset = offset;

            vkCmdCopyBuffer(copyCmd, vkcontext->stagingBuffer.vkBuffer, *buffer, 1, &copyRegion);

            // TODO: Optional barrier since I wait on the fence anyways?
            {
                VkBufferMemoryBarrier bufferMemoryBarrier = {VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER};
                bufferMemoryBarrier.srcAccessMask = VK_ACCESS_MEMORY_WRITE_BIT;
                // TODO: This could be VK_ACCESS_SHADER_READ_BIT, when using blindless
                bufferMemoryBarrier.dstAccessMask = VK_ACCESS_VERTEX_ATTRIBUTE_READ_BIT;
                bufferMemoryBarrier.buffer = *buffer;
                bufferMemoryBarrier.offset = 0;
                bufferMemoryBarrier.size = VK_WHOLE_SIZE;
                // TODO: This can be used by the transfer queue to transition to graphics queue
                bufferMemoryBarrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
                bufferMemoryBarrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;

                vkCmdPipelineBarrier(
                    copyCmd,
                    VK_PIPELINE_STAGE_TRANSFER_BIT,
                    VK_PIPELINE_STAGE_VERTEX_INPUT_BIT,
                    0,    // Dependency flags
                    0, 0, // No memory barriers
                    1, &bufferMemoryBarrier,
                    0, 0); // No image memory barrers
            }

            VK_CHECK(vkEndCommandBuffer(copyCmd));

            VkFence uploadFence;
            VkFenceCreateInfo fenceInfo = vkinit::fence_create_info();
            VK_CHECK(vkCreateFence(vkcontext->device, &fenceInfo, 0, &uploadFence));

            VkSubmitInfo submitInfo = vkinit::submit_info(copyCmd);
            VK_CHECK(vkQueueSubmit(vkcontext->graphicsQueue, 1, &submitInfo, uploadFence));

            VK_CHECK(vkWaitForFences(vkcontext->device, 1, &uploadFence, true, 9999999999));
            vkFreeCommandBuffers(vkcontext->device, vkcontext->commandPool, 1, &copyCmd);
            vkDestroyFence(vkcontext->device, uploadFence, 0);
        }
    }

    void vk_allocate_image(
        VkContext *vkcontext,
        VkImage *image,
        VkDeviceMemory *memory,
        VkFormat imageFormat,
        VkImageUsageFlags imageUsage,
        VkExtent3D extent,
        uint32_t levels,
        uint32_t layers)
    {

        VkImageCreateInfo imageInfo = vkinit::image_create_info(
            imageFormat,
            imageUsage,
            extent,
            levels,
            layers);

        VK_CHECK(vkCreateImage(
            vkcontext->device,
            &imageInfo,
            0,
            image));

        VkMemoryRequirements memoryRequirements;
        vkGetImageMemoryRequirements(
            vkcontext->device,
            *image,
            &memoryRequirements);

        VkMemoryAllocateInfo allocInfo = {};
        allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        allocInfo.allocationSize = memoryRequirements.size;
        allocInfo.memoryTypeIndex = vk_find_memory_type(
            vkcontext->gpu,
            memoryRequirements.memoryTypeBits,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

        VK_CHECK(vkAllocateMemory(
            vkcontext->device,
            &allocInfo,
            0,
            memory));

        VK_CHECK(vkBindImageMemory(
            vkcontext->device,
            *image,
            *memory,
            0));
    }

    void vk_copy_to_image(
        VkContext *vkcontext,
        VkImage *image,
        VkImageLayout *layout,
        VkBufferImageCopy *pCopyRegions,
        uint32_t regionCount,
        const void *data,
        uint32_t size,
        uint32_t levels,
        uint32_t layers)
    {
        // Copy the data to the staging buffer
        memcpy(vkcontext->stagingBuffer.mapped, data, size);

        VkCommandBuffer copyCmd;

        VkCommandBufferAllocateInfo cmdAlloc = vkinit::command_buffer_allocate_info(
            vkcontext->commandPool);

        VK_CHECK(vkAllocateCommandBuffers(
            vkcontext->device,
            &cmdAlloc,
            &copyCmd));

        VkCommandBufferBeginInfo cmdBeginInfo = vkinit::command_buffer_begin_info(
            VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT);

        vkBeginCommandBuffer(copyCmd, &cmdBeginInfo);

        // Copy the data from the staging buffer to the image
        {
            VkImageSubresourceRange range;
            range.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
            range.baseArrayLayer = 0;
            range.baseMipLevel = 0;
            range.layerCount = layers,
            range.levelCount = levels;

            VkImageMemoryBarrier imageMemoryBarrier = vkinit::image_memory_barrier();
            imageMemoryBarrier.image = *image;
            imageMemoryBarrier.subresourceRange = range;
            imageMemoryBarrier.srcAccessMask = 0;
            imageMemoryBarrier.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            imageMemoryBarrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
            imageMemoryBarrier.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;

            vkCmdPipelineBarrier(
                copyCmd,
                VK_PIPELINE_STAGE_HOST_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT,
                0,    // No Dependencies
                0, 0, // No memory barriers
                0, 0, // No bufer memory barriers
                1, &imageMemoryBarrier);

            vkCmdCopyBufferToImage(
                copyCmd,
                vkcontext->stagingBuffer.vkBuffer,
                *image,
                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                regionCount,
                pCopyRegions);

            imageMemoryBarrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
            imageMemoryBarrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
            imageMemoryBarrier.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
            imageMemoryBarrier.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

            *layout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;

            vkCmdPipelineBarrier(
                copyCmd,
                VK_PIPELINE_STAGE_TRANSFER_BIT,
                VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                0,
                0, 0,
                0, 0,
                1, &imageMemoryBarrier);
        }

        vkEndCommandBuffer(copyCmd);

        VkFence uploadFence;
        VkFenceCreateInfo fenceInfo = vkinit::fence_create_info();
        vkCreateFence(vkcontext->device, &fenceInfo, 0, &uploadFence);

        VkSubmitInfo submitInfo = vkinit::submit_info(copyCmd);
        vkQueueSubmit(vkcontext->graphicsQueue, 1, &submitInfo, uploadFence);

        vkWaitForFences(vkcontext->device, 1, &uploadFence, true, 9999999999);
        vkDestroyFence(vkcontext->device, uploadFence, 0);
    }
} // namespace Cakez
