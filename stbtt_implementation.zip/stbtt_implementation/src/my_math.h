#pragma once

namespace Cakez
{
    struct Vec2
    {
        float x;
        float y;

        Vec2 operator+(Vec2 &other);
        Vec2 &operator+=(Vec2 &other);
        Vec2 operator*(float scalar);
        Vec2 operator-(Vec2 other);
    };

    float length(Vec2 &v);
    Vec2 normalize(Vec2 &v);
    float length_squared(Vec2 &v);

    struct Vec3
    {
        union
        {
            float values[3];
            struct
            {
                float x;
                float y;
                float z;
            };
        };

        float operator[](int index);
        Vec3 operator+(Vec3 &other);
        Vec3 operator*(float value);
        Vec3 operator-(Vec3 &other);
    };

    Vec3 create_vec3(float *buffer);
    float length(Vec3 &v);
    Vec3 normalize(Vec3 &v);
    Vec3 cross(Vec3 &a, Vec3 &b);
    float dot(Vec3 &a, Vec3 &b);

    struct Vec4
    {
        union
        {
            float values[4];
            struct
            {
                float x;
                float y;
                float z;
                float w;
            };
        };

        bool operator==(Vec4 &other);
        Vec4 operator+(Vec4 &other);
        Vec4 operator*(float vlaue);
        float &operator[](int index);
    };

    Vec4 create_vec4(float *buffer);

    struct Quat
    {
        union
        {
            float values[4];
            struct
            {
                float x;
                float y;
                float z;
                float w;
            };
        };
    };

    Quat create_quat(float *buffer);

    struct Mat3
    {
        union
        {
            float values[9];
            Vec3 cols[3];
            struct
            {
                float ax;
                float ay;
                float az;

                float bx;
                float by;
                float bz;

                float cx;
                float cy;
                float cz;
            };
        };
    };

    struct Mat4
    {
        union
        {
            float values[16];
            Vec4 cols[4];
            struct
            {
                float ax;
                float ay;
                float az;
                float aw;

                float bx;
                float by;
                float bz;
                float bw;

                float cx;
                float cy;
                float cz;
                float cw;

                float dx;
                float dy;
                float dz;
                float dw;
            };
        };

        Vec4 &operator[](int col);
        Mat4 operator*(Mat4 &other);
    };

    Mat4 create_mat4(float initValue);
    Mat4 create_mat4(float *buffer);
    Mat4 translate(Mat4 &m, Vec3 &v);
    Mat4 look_at(Vec3 &eye, Vec3 &target, Vec3 &up);

    struct Rect
    {
        union
        {
            struct
            {
                Vec2 pos;
                Vec2 size;
            };

            // Note: To make comparisons easier, order matters
            struct
            {
                float left;
                float top;
                float sizeX;
                float sizeY;
            };
        };
    };

    bool point_in_rect(const Vec2 &point, const Rect &rect);
    bool rect_collision(Rect &a, Rect &b);

    struct Circle
    {
        float radius;
        Vec2 origin;
    };

    //TODO: Implement later
    struct CollisionInformation
    {
        bool colided;
        // Entity *collider;
        float penetrationDepth;
    };

    bool point_in_circle(Vec2 point, Vec2 origin, float r);
    bool circle_collision(Circle *circleA, Circle *circleB);
    bool circle_collision(Circle circleA, Circle circleB);
    bool circle_collision(float rA, Vec2 originA, float rB, Vec2 originB);
    bool circle_collision(float rA, Vec2 originA, Circle circle);

    float square_root(float value);
    float Q_rsqrt(float number);

    void sort(uint8_t *array, uint32_t elementSize, uint32_t length, bool (*fn)(void *a, void *b));
} // namespace Cakez
