#pragma once

#include "defines.h"

namespace Cakez
{
    void copy_to_buffer(
        const void *buffer,
        const void *data,
        const uint32_t size,
        const uint32_t offset = 0u);

    bool str_cmp(const char *a, const char *b);

    // Number to char conversion
    void convert_number_to_char(uint32_t number, char *buffer, int *length, int base);
    void convert_number_to_char(int number, char *buffer, int *length, int base = 10);

    uint32_t count_char(const char c, const char *hay);

    uint8_t pack_uint8(float value);

} // namespace Cakez
