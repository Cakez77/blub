#include "vk_initializers.h"

namespace vkinit
{
	VkApplicationInfo application_info()
	{
		VkApplicationInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
		info.pNext = nullptr;
		info.pApplicationName = "Gotha";
		info.pEngineName = "Berngine";
		info.applicationVersion = VK_MAKE_VERSION(0, 0, 1);
		info.engineVersion = VK_MAKE_VERSION(0, 0, 1);
		info.apiVersion = VK_API_VERSION_1_1;

		return info;
	}

	VkInstanceCreateInfo instance_create_info(const VkApplicationInfo &appInfo)
	{
		VkInstanceCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
		info.pApplicationInfo = &appInfo;

		return info;
	}

	VkDebugUtilsMessengerCreateInfoEXT debug_utils_create_info(
		const PFN_vkDebugUtilsMessengerCallbackEXT debug_callback,
		const VkDebugUtilsMessageSeverityFlagsEXT messageSeverity,
		const VkDebugUtilsMessageTypeFlagsEXT messageType)
	{
		VkDebugUtilsMessengerCreateInfoEXT info = {};
		info.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
		info.pNext = nullptr;
		info.pfnUserCallback = debug_callback;
		info.messageSeverity = messageSeverity;
		info.messageType = messageType;

		return info;
	}

	VkDeviceQueueCreateInfo device_queue_create_info(uint32_t index, float &priority)
	{
		VkDeviceQueueCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
		info.pNext = nullptr;
		info.queueCount = 1;
		info.queueFamilyIndex = index;
		info.pQueuePriorities = &priority;

		return info;
	}

	VkPhysicalDeviceFeatures device_features()
	{
		VkPhysicalDeviceFeatures features = {};
		features.textureCompressionBC = VK_TRUE;
		features.imageCubeArray = VK_TRUE;
		/*features.depthClamp = VK_TRUE;
	features.depthBiasClamp = VK_TRUE;
	features.fillModeNonSolid = VK_TRUE;*/

		return features;
	}

	VkDeviceCreateInfo device_info(
		const char *extensions[],
		uint32_t extensionCount,
		VkDeviceQueueCreateInfo *queueInfos,
		uint32_t queueCount,
		VkPhysicalDeviceFeatures& features)
	{
		VkDeviceCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
		info.pNext = nullptr;
		info.enabledExtensionCount = extensionCount;
		info.ppEnabledExtensionNames = extensions;
		info.queueCreateInfoCount = queueCount;
		info.pQueueCreateInfos = queueInfos;
		info.pEnabledFeatures = &features;

		return info;
	}

	VkQueryPoolCreateInfo query_pool_info(
		VkQueryType queryType,
		uint32_t queryCount)
	{
		VkQueryPoolCreateInfo info = {VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};
		info.queryCount = queryCount;
		info.queryType = queryType;

		//TODO: pipeline statistics
		// info.pipelineStatistics = VK_QUERY_PIPELINE_STATISTIC_CLIPPING_INVOCATIONS_BIT;

		return info;
	}

	VkImageCreateInfo image_create_info(
		VkFormat format,
		VkImageUsageFlags usage,
		VkExtent3D extent,
		uint32_t levels,
		uint32_t layers)
	{
		VkImageCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
		info.imageType = VK_IMAGE_TYPE_2D;
		info.format = format;
		info.extent = extent;
		info.mipLevels = levels;
		info.arrayLayers = layers;
		info.samples = VK_SAMPLE_COUNT_1_BIT;
		info.tiling = VK_IMAGE_TILING_OPTIMAL;
		info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
		info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
		info.usage = usage;

		return info;
	}

	VkImageViewCreateInfo image_view_create_info(VkImage image, VkFormat format, VkImageAspectFlags aspectFlags, VkImageViewType viewType, uint32_t levelCount, uint32_t layerCount)
	{
		VkImageViewCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
		info.pNext = nullptr;
		info.viewType = viewType;
		info.format = format;
		info.image = image;
		info.components.r = VK_COMPONENT_SWIZZLE_IDENTITY;
		info.components.g = VK_COMPONENT_SWIZZLE_IDENTITY;
		info.components.b = VK_COMPONENT_SWIZZLE_IDENTITY;
		info.components.a = VK_COMPONENT_SWIZZLE_IDENTITY;
		info.subresourceRange.aspectMask = aspectFlags;
		info.subresourceRange.baseMipLevel = 0;
		info.subresourceRange.levelCount = levelCount;
		info.subresourceRange.baseArrayLayer = 0;
		info.subresourceRange.layerCount = layerCount;

		return info;
	}

	VkAttachmentDescription attachment_description(VkImageLayout finalLayout, VkFormat format, VkAttachmentStoreOp storeOp)
	{
		VkAttachmentDescription desc = {};
		desc.format = format;
		desc.samples = VK_SAMPLE_COUNT_1_BIT;
		desc.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
		desc.storeOp = storeOp;
		desc.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
		desc.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
		desc.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
		desc.finalLayout = finalLayout;

		return desc;
	}

	VkPipelineShaderStageCreateInfo pipeline_shader_stage_create_info(VkShaderStageFlagBits stage, VkShaderModule shaderModule)
	{
		VkPipelineShaderStageCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
		info.stage = stage;
		info.module = shaderModule;
		info.pName = "main";

		return info;
	}

	VkPipelineVertexInputStateCreateInfo vertex_input_state_create_info()
	{
		VkPipelineVertexInputStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
		info.vertexBindingDescriptionCount = 0;
		info.vertexAttributeDescriptionCount = 0;

		return info;
	}

	VkPipelineVertexInputStateCreateInfo vertex_input_state_create_info(std::vector<VkVertexInputAttributeDescription> &attributes, std::vector<VkVertexInputBindingDescription> &bindings)
	{
		VkPipelineVertexInputStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
		info.vertexAttributeDescriptionCount = static_cast<uint32_t>(attributes.size());
		info.pVertexAttributeDescriptions = attributes.data();
		info.vertexBindingDescriptionCount = static_cast<uint32_t>(bindings.size());
		info.pVertexBindingDescriptions = bindings.data();

		return info;
	}

	VkVertexInputBindingDescription vertex_input_binding_description(uint32_t binding, uint32_t stride, VkVertexInputRate inputRate)
	{
		VkVertexInputBindingDescription desc{};
		desc.binding = binding;
		desc.stride = stride;
		desc.inputRate = inputRate;
		return desc;
	}

	VkVertexInputAttributeDescription vertex_input_attribute_description(uint32_t binding, uint32_t location, VkFormat format, uint32_t offset)
	{
		VkVertexInputAttributeDescription desc{};
		desc.binding = binding;
		desc.location = location;
		desc.format = format;
		desc.offset = offset;
		return desc;
	}

	VkPipelineInputAssemblyStateCreateInfo input_assembly_create_info(VkPrimitiveTopology topology, VkBool32 restartEnable)
	{
		VkPipelineInputAssemblyStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
		info.topology = topology;
		info.primitiveRestartEnable = restartEnable;

		return info;
	}

	VkViewport viewport(VkExtent2D extent)
	{
		VkViewport viewport = {};
		viewport.x = 0.0f;
		viewport.y = 0.0f;
		viewport.width = extent.width;
		viewport.height = extent.height;
		viewport.minDepth = 0.0f;
		viewport.maxDepth = 1.0f;

		return viewport;
	}

	VkRect2D scissor(VkExtent2D extent)
	{
		VkRect2D scissor = {};
		scissor.offset = {0, 0};
		scissor.extent = extent;

		return scissor;
	}

	VkPipelineViewportStateCreateInfo viewport_state_create_info(VkViewport &viewport, VkRect2D &scissor)
	{
		VkPipelineViewportStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
		info.viewportCount = 1;
		info.pViewports = &viewport;
		info.scissorCount = 1;
		info.pScissors = &scissor;

		return info;
	}

	VkPipelineRasterizationStateCreateInfo rasterization_state_create_info(VkPolygonMode polygonMode)
	{
		VkPipelineRasterizationStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
		info.depthClampEnable = VK_FALSE;
		info.rasterizerDiscardEnable = VK_FALSE; // rasterizer discard allows objects with holes, default to no
		info.polygonMode = polygonMode;
		info.lineWidth = 1.0f;
		info.cullMode = VK_CULL_MODE_FRONT_BIT;
		info.frontFace = VK_FRONT_FACE_CLOCKWISE;
		info.depthBiasEnable = VK_FALSE;
		info.depthBiasConstantFactor = 0.0f;
		info.depthBiasClamp = 0.0f;
		info.depthBiasSlopeFactor = 0.0f;

		return info;
	}

	VkPipelineMultisampleStateCreateInfo multisampling_state_create_info()
	{
		VkPipelineMultisampleStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
		info.sampleShadingEnable = VK_FALSE;
		info.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT; // multisampling defaulted to no multisampling (1 sample per pixel)
		info.minSampleShading = 1.0f;
		info.pSampleMask = nullptr;
		info.alphaToCoverageEnable = VK_FALSE;
		info.alphaToOneEnable = VK_FALSE;

		return info;
	}

	VkPipelineColorBlendStateCreateInfo color_blend_state_crate_info(uint32_t attachmentcount, VkPipelineColorBlendAttachmentState *attachment)
	{
		VkPipelineColorBlendStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
		info.pNext = nullptr;
		info.attachmentCount = attachmentcount;
		info.pAttachments = attachment;

		return info;
	}

	VkPipelineColorBlendAttachmentState color_blend_attachment_state()
	{
		VkPipelineColorBlendAttachmentState colorBlendAttachment = {};
		colorBlendAttachment.colorWriteMask =
			VK_COLOR_COMPONENT_R_BIT |
			VK_COLOR_COMPONENT_G_BIT |
			VK_COLOR_COMPONENT_B_BIT |
			VK_COLOR_COMPONENT_A_BIT;

		colorBlendAttachment.blendEnable = VK_FALSE;

		return colorBlendAttachment;
	}

	VkPipelineDepthStencilStateCreateInfo depth_stencil_create_info(bool bDepthTest, bool bDepthWrite, VkCompareOp compareOp)
	{
		VkPipelineDepthStencilStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
		info.depthTestEnable = bDepthTest ? VK_TRUE : VK_FALSE;
		info.depthWriteEnable = bDepthWrite ? VK_TRUE : VK_FALSE;
		info.depthCompareOp = bDepthTest ? compareOp : VK_COMPARE_OP_ALWAYS;
		info.depthBoundsTestEnable = VK_FALSE;
		info.minDepthBounds = 1.0f; // Optional
		info.maxDepthBounds = 0.0f; // Optional
		info.stencilTestEnable = VK_FALSE;

		return info;
	}

	VkPipelineDynamicStateCreateInfo dynamic_state_create_info(
		VkDynamicState dynamicStates[],
		uint32_t dynamicStateCount)
	{
		VkPipelineDynamicStateCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
		info.pDynamicStates = dynamicStates;
		info.dynamicStateCount = dynamicStateCount;

		return info;
	}

	VkPipelineLayoutCreateInfo pipeline_layout_create_info(VkDescriptorSetLayout &setLayout)
	{
		VkPipelineLayoutCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
		info.flags = 0;
		info.setLayoutCount = 1; // the more layouts increases the number set=# in the shader, max 4, I think
		info.pSetLayouts = &setLayout;
		info.pushConstantRangeCount = 0;
		info.pPushConstantRanges = nullptr;

		return info;
	}

	VkPipelineLayoutCreateInfo pipeline_layout_create_info(
		std::vector<VkDescriptorSetLayout> &setLayouts)
	{
		VkPipelineLayoutCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
		info.flags = 0;
		info.setLayoutCount = static_cast<uint32_t>(setLayouts.size());
		info.pSetLayouts = setLayouts.data();
		info.pushConstantRangeCount = 0;
		info.pPushConstantRanges = nullptr;

		return info;
	}

	VkComputePipelineCreateInfo compute_pipeline_create_info(VkPipelineShaderStageCreateInfo stageInfo, VkPipelineLayout layout)
	{
		VkComputePipelineCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
		info.stage = stageInfo;
		info.layout = layout;

		return info;
	}

	VkPushConstantRange push_constant_range(VkShaderStageFlags flags, uint32_t size, uint32_t offset)
	{
		VkPushConstantRange range = {};
		range.stageFlags = flags;
		range.size = size;
		range.offset = offset;

		return range;
	}

	VkSpecializationMapEntry specialization_map_entry(uint32_t id, uint32_t offset, size_t size)
	{
		VkSpecializationMapEntry specMapEntry{};
		specMapEntry.constantID = id;
		specMapEntry.offset = offset;
		specMapEntry.size = size;

		return specMapEntry;
	}

	VkSpecializationInfo specialization_info(const std::vector<VkSpecializationMapEntry> &entries, size_t size, const void *data)
	{
		VkSpecializationInfo info{};
		info.mapEntryCount = static_cast<uint32_t>(entries.size());
		info.pMapEntries = entries.data();
		info.dataSize = size;
		info.pData = data;

		return info;
	}

	VkSamplerCreateInfo sampler_create_info(float maxLod, VkSamplerAddressMode addressMode, VkCompareOp compareOpeartion)
	{
		VkSamplerCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO;
		info.magFilter = VK_FILTER_LINEAR;
		info.minFilter = VK_FILTER_LINEAR;
		info.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
		info.addressModeU = addressMode;
		info.addressModeV = addressMode;
		info.addressModeW = addressMode;
		info.mipLodBias = 0.0f;
		info.compareOp = compareOpeartion;
		info.minLod = 0.0f;
		info.maxLod = maxLod;
		info.maxAnisotropy = 1.0f;
		info.anisotropyEnable = VK_FALSE;
		info.borderColor = VK_BORDER_COLOR_FLOAT_OPAQUE_BLACK;

		return info;
	}

	VkCommandPoolCreateInfo command_pool_create_info(uint32_t queueFamilyIdx, VkCommandPoolResetFlags flags)
	{
		VkCommandPoolCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
		info.queueFamilyIndex = queueFamilyIdx;
		info.flags = flags;

		return info;
	}

	VkDescriptorSetLayoutBinding descriptorset_layout_binding(VkDescriptorType type, VkShaderStageFlags stageFlags, uint32_t binding, uint32_t descCount)
	{
		VkDescriptorSetLayoutBinding bind = {};
		bind.descriptorType = type;
		bind.stageFlags = stageFlags;
		bind.binding = binding;
		bind.descriptorCount = descCount;

		return bind;
	}

	VkDescriptorSetLayoutCreateInfo descriptorset_layout_create_info(uint32_t bindingCount, VkDescriptorSetLayoutBinding *bindings)
	{
		VkDescriptorSetLayoutCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
		info.bindingCount = bindingCount;
		info.pBindings = bindings;

		return info;
	}

	VkDescriptorPoolSize desc_pool_size(VkDescriptorType type, uint32_t descCount)
	{
		VkDescriptorPoolSize pSize = {};
		pSize.descriptorCount = descCount;
		pSize.type = type;

		return pSize;
	}

	VkDescriptorPoolCreateInfo desc_pool_create_info(uint32_t maxSets, const std::vector<VkDescriptorPoolSize> &poolSizes)
	{
		VkDescriptorPoolCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
		info.maxSets = maxSets;
		info.poolSizeCount = static_cast<uint32_t>(poolSizes.size());
		info.pPoolSizes = poolSizes.data();

		return info;
	}

	VkDescriptorSetAllocateInfo descriptorset_allocate_info(VkDescriptorPool pool, uint32_t descCount, VkDescriptorSetLayout *layout)
	{
		VkDescriptorSetAllocateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
		info.descriptorPool = pool;
		info.descriptorSetCount = descCount;
		info.pSetLayouts = layout;

		return info;
	}

	VkDescriptorBufferInfo descriptor_buffer_info(VkBuffer buffer, VkDeviceSize range, VkDeviceSize offset)
	{
		VkDescriptorBufferInfo info = {};
		info.buffer = buffer;
		info.offset = offset;
		info.range = range;

		return info;
	}

	VkDescriptorImageInfo descriptor_image_info(VkImageView view, VkSampler sampler)
	{
		VkDescriptorImageInfo info = {};
		info.imageLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
		info.imageView = view;
		info.sampler = sampler;

		return info;
	}

	VkWriteDescriptorSet write_descriptor_set(
		VkDescriptorType type,
		VkDescriptorSet set,
		uint32_t binding,
		Cakez::DescriptorInfo *descInfos,
		uint32_t count)
	{
		VkWriteDescriptorSet write = {};
		write.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
		write.descriptorType = type;
		write.descriptorCount = count;
		write.dstBinding = binding;
		write.dstSet = set;
		write.pBufferInfo = &descInfos->bufferInfo;
		write.pImageInfo = &descInfos->imageInfo;

		return write;
	}

	VkCommandBufferAllocateInfo command_buffer_allocate_info(VkCommandPool pool, uint32_t count, VkCommandBufferLevel level)
	{
		VkCommandBufferAllocateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
		info.commandPool = pool;
		info.commandBufferCount = count;
		info.level = level;

		return info;
	}

	VkCommandBufferBeginInfo command_buffer_begin_info(VkCommandBufferUsageFlags flags)
	{
		VkCommandBufferBeginInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
		info.flags = flags;

		return info;
	}

	VkSubmitInfo submit_info(VkCommandBuffer &cmd)
	{
		VkSubmitInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
		info.commandBufferCount = 1;
		info.pCommandBuffers = &cmd;
		info.waitSemaphoreCount = 0;
		info.pWaitSemaphores = nullptr;
		info.signalSemaphoreCount = 0;
		info.pSignalSemaphores = nullptr;
		info.pWaitDstStageMask = nullptr;

		return info;
	}

	VkFenceCreateInfo fence_create_info(VkFenceCreateFlags flags)
	{
		VkFenceCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
		info.pNext = nullptr;
		info.flags = flags;

		return info;
	}

	VkSemaphoreCreateInfo semaphore_create_info()
	{
		VkSemaphoreCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
		info.pNext = nullptr;
		info.flags = 0;

		return info;
	}

	VkBufferCreateInfo buffer_create_info(VkBufferUsageFlags flags, VkDeviceSize size)
	{
		VkBufferCreateInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
		info.pNext = nullptr;
		info.size = size;
		info.usage = flags;

		return info;
	}

	VkImageMemoryBarrier image_memory_barrier()
	{
		VkImageMemoryBarrier barrier = {};
		barrier.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;

		return barrier;
	}

	VkRenderPassBeginInfo renderpass_begin_info(VkRenderPass renderPass, VkExtent2D extent, VkFramebuffer frameBuffer)
	{
		VkRenderPassBeginInfo info = {};
		info.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
		info.renderPass = renderPass;
		info.renderArea.offset = {0, 0};
		info.renderArea.extent = extent;
		info.framebuffer = frameBuffer;

		return info;
	}

} // namespace vkinit