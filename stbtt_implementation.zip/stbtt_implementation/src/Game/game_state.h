#pragma once

#include "camera.h"
#include "defines.h"
#include "my_math.h"
#include "ui.h"
#include "game_assets.h"

namespace Cakez
{
    global_variable float constexpr BASE_ANIMATION_DURATION = 1.0f;

    global_variable uint32_t constexpr MAX_ENTITIES = 1000;
    global_variable uint32_t constexpr MAX_WAYPOINTS = 10;
    global_variable uint32_t constexpr MAX_TEAM_MEMBERS = 10;

    global_variable char *ruleTypeStrings[] = {
        "Health Threshold",
        "Stay on Target",
        "Highest Max HP",
        "Lowest Max HP",
        "Highest HP",
        "Lowest HP"};

    global_variable char *actionStrings[] = {
        "Attack",
        "Heal",
        "Passive"};

    enum Components
    {
        NONE_COMPONENT = 0,
        MESH_COMPONENT = BIT(1),
        SPRITE_COMPONENT = BIT(2),
        PHYSICS_COMPONENT = BIT(3),
        PROJECTILE_COMPONENT = BIT(4),
        ENEMY_COMPONENT = BIT(5),
        HERO_COMPONENT = BIT(6),
        DEATH_COMPONENT = BIT(7),
        ANIMATION_COMPONENT = BIT(8),
        EXPLOSION_COMPONENT = BIT(9),

        // TODO: Not implemented yet
        TRIGGER_ENTITY_COMPONENT = BIT(10),

    };

    enum EntityClass
    {
        CLASS_MELEE = BIT(1),
        CLASS_RANGED = BIT(2),
        CLASS_HEAL = BIT(3)
    };

    struct Team
    {
        uint32_t heroCount;
        Entity heroes[MAX_TEAM_MEMBERS];
    };

    enum GameStates{
        GAME_STATE_MAIN_MENU,
        GAME_STATE_EDIT_RULES,
        GAME_STATE_RUNNING_LEVEL  
    };

    struct GameState
    {
        uint32_t entityCount;
        Entity entities[MAX_ENTITIES];

        GameStates gameState;

        uint32_t heroIdx;
        Team team;

        //TODO: Remove
        char value[10];
        size_t activeDropDown;
        Vec2 containerPos;
        float debugSpawnTimer;

        float transitionDuration;

        // in seconds
        float gameTime;
        Entity *selectedEntity;

        //Waypoints
        uint16_t waypointCount;
        Vec2 waypoints[MAX_WAYPOINTS];
    };

} // namespace Cakez
